package train.client.render.models;

import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelHeavySteamLoco extends ModelBase {

	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box100;
	public ModelRendererTurbo box101;
	public ModelRendererTurbo box102;
	public ModelRendererTurbo box103;
	public ModelRendererTurbo box104;
	public ModelRendererTurbo box105;
	public ModelRendererTurbo box106;
	public ModelRendererTurbo box107;
	public ModelRendererTurbo box108;
	public ModelRendererTurbo box109;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box110;
	public ModelRendererTurbo box111;
	public ModelRendererTurbo box112;
	public ModelRendererTurbo box113;
	public ModelRendererTurbo box114;
	public ModelRendererTurbo box115;
	public ModelRendererTurbo box116;
	public ModelRendererTurbo box117;
	public ModelRendererTurbo box118;
	public ModelRendererTurbo box119;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box80;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box83;
	public ModelRendererTurbo box84;
	public ModelRendererTurbo box85;
	public ModelRendererTurbo box86;
	public ModelRendererTurbo box87;
	public ModelRendererTurbo box88;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;
	public ModelRendererTurbo box90;
	public ModelRendererTurbo box91;
	public ModelRendererTurbo box92;
	public ModelRendererTurbo box93;
	public ModelRendererTurbo box94;
	public ModelRendererTurbo box95;
	public ModelRendererTurbo box96;
	public ModelRendererTurbo box97;
	public ModelRendererTurbo box98;
	public ModelRendererTurbo box99;

	public ModelHeavySteamLoco() {
		box = new ModelRendererTurbo(this, 22, 54, 256, 256);
		box.addBox(0F, 0F, 0F, 1, 5, 12);
		box.setPosition(7F, 27F, -6F);

		box0 = new ModelRendererTurbo(this, 180, 25, 256, 256);
		box0.addBox(0F, 0F, 0F, 2, 10, 10);
		box0.setPosition(-60F, 19F, -5F);

		box1 = new ModelRendererTurbo(this, 0, 117, 256, 256);
		box1.addBox(0F, 0F, 0F, 12, 11, 1);
		box1.setPosition(7F, 12F, 9F);

		box10 = new ModelRendererTurbo(this, 0, 2, 256, 256);
		box10.addBox(0F, -1F, -5F, 17, 1, 5);
		box10.setPosition(24F, 28F, 10F);
		box10.rotateAngleX = -3.857177646907468F;
		box10.rotateAngleY = -3.141592653589793F;

		box100 = new ModelRendererTurbo(this, 239, 167, 256, 256);
		box100.addBox(0F, 0F, 0F, 4, 1, 4);
		box100.setPosition(16F, 19F, -9F);

		box101 = new ModelRendererTurbo(this, 245, 157, 256, 256);
		box101.addBox(0F, 0F, 0F, 1, 5, 4);
		box101.setPosition(19F, 20F, -9F);

		box102 = new ModelRendererTurbo(this, 239, 167, 256, 256);
		box102.addBox(0F, 0F, 0F, 4, 1, 4);
		box102.setPosition(16F, 19F, 5F);

		box103 = new ModelRendererTurbo(this, 245, 157, 256, 256);
		box103.addBox(0F, 0F, 0F, 1, 5, 4);
		box103.setPosition(19F, 20F, 5F);

		box104 = new ModelRendererTurbo(this, 1, 195, 256, 256);
		box104.addBox(0F, 0F, 0F, 40, 11, 18);
		box104.setPosition(-23F, 5F, 9F);
		box104.rotateAngleY = -3.141592653589793F;

		box105 = new ModelRendererTurbo(this, 47, 26, 256, 256);
		box105.addBox(0F, 0F, 0F, 36, 2, 1);
		box105.setPosition(-4F, 5F, -6F);
		box105.rotateAngleY = -3.141592653589793F;

		box106 = new ModelRendererTurbo(this, 42, 17, 256, 256);
		box106.addBox(0F, 0F, 0F, 20, 2, 1);
		box106.setPosition(-23F, 5F, -7F);
		box106.rotateAngleY = -3.141592653589793F;
		box106.rotateAngleZ = -6.178465552059927F;

		box107 = new ModelRendererTurbo(this, 125, 195, 256, 256);
		box107.addBox(0F, 0F, 0F, 8, 8, 0);
		box107.setPosition(-49F, 0F, -5F);
		box107.rotateAngleY = -3.141592653589793F;
		box107.rotateAngleZ = -6.283185307179586F;

		box108 = new ModelRendererTurbo(this, 125, 195, 256, 256);
		box108.addBox(0F, 0F, 0F, 8, 8, 0);
		box108.setPosition(-59F, 0F, -5F);
		box108.rotateAngleY = -3.141592653589793F;
		box108.rotateAngleZ = -6.283185307179586F;

		box109 = new ModelRendererTurbo(this, 124, 169, 256, 256);
		box109.addBox(0F, 0F, 0F, 16, 16, 0);
		box109.setPosition(-32F, 0F, -5F);
		box109.rotateAngleY = -3.141592653589793F;
		box109.rotateAngleZ = -6.283185307179586F;

		box11 = new ModelRendererTurbo(this, 125, 133, 256, 256);
		box11.addBox(0F, 0F, 0F, 59, 16, 6);
		box11.setPosition(-59F, 21F, 8F);
		box11.rotateAngleX = -1.5707963267948966F;

		box110 = new ModelRendererTurbo(this, 124, 169, 256, 256);
		box110.addBox(0F, 0F, 0F, 16, 16, 0);
		box110.setPosition(2F, 0F, -5F);
		box110.rotateAngleY = -3.141592653589793F;
		box110.rotateAngleZ = -6.283185307179586F;

		box111 = new ModelRendererTurbo(this, 124, 169, 256, 256);
		box111.addBox(0F, 0F, 0F, 16, 16, 0);
		box111.setPosition(-15F, 0F, -5F);
		box111.rotateAngleY = -3.141592653589793F;
		box111.rotateAngleZ = -6.283185307179586F;

		box112 = new ModelRendererTurbo(this, 125, 195, 256, 256);
		box112.addBox(0F, 0F, 0F, 8, 8, 0);
		box112.setPosition(17F, 0F, -5F);
		box112.rotateAngleY = -3.141592653589793F;
		box112.rotateAngleZ = -6.283185307179586F;

		box113 = new ModelRendererTurbo(this, 47, 2, 256, 256);
		box113.addBox(0F, 0F, 0F, 18, 2, 1);
		box113.setPosition(-42F, 7F, -7F);
		box113.rotateAngleY = -3.141592653589793F;

		box114 = new ModelRendererTurbo(this, 240, 244, 256, 256);
		box114.addBox(0F, 0F, 0F, 3, 1, 3);
		box114.setPosition(-66F, 7F, -10F);

		box115 = new ModelRendererTurbo(this, 225, 244, 256, 256);
		box115.addBox(0F, 0F, 0F, 2, 1, 3);
		box115.setPosition(-66F, 3F, -10F);

		box116 = new ModelRendererTurbo(this, 225, 244, 256, 256);
		box116.addBox(0F, 0F, 0F, 2, 1, 3);
		box116.setPosition(-66F, 3F, 7F);

		box117 = new ModelRendererTurbo(this, 240, 244, 256, 256);
		box117.addBox(0F, 0F, 0F, 3, 1, 3);
		box117.setPosition(-66F, 7F, 7F);

		box118 = new ModelRendererTurbo(this, 240, 234, 256, 256);
		box118.addBox(0F, 0F, 0F, 3, 8, 0);
		box118.setPosition(-66F, 3F, -7F);

		box119 = new ModelRendererTurbo(this, 240, 234, 256, 256);
		box119.addBox(0F, 0F, 0F, 3, 8, 0);
		box119.setPosition(-66F, 3F, 7F);

		box12 = new ModelRendererTurbo(this, 69, 69, 256, 256);
		box12.addBox(0F, 0F, 0F, 16, 6, 1);
		box12.setPosition(-62F, 22F, -11F);
		box12.rotateAngleX = -6.19591884457987F;

		box13 = new ModelRendererTurbo(this, 25, 30, 256, 256);
		box13.addBox(0F, 0F, 0F, 6, 2, 20);
		box13.setPosition(-53F, 11F, 10F);
		box13.rotateAngleY = -3.141592653589793F;
		box13.rotateAngleZ = -6.283185307179586F;

		box14 = new ModelRendererTurbo(this, 1, 171, 256, 256);
		box14.addBox(0F, 0F, 0F, 42, 1, 22);
		box14.setPosition(-44F, 15F, -11F);

		box15 = new ModelRendererTurbo(this, 0, 17, 256, 256);
		box15.addBox(0F, -1F, -5F, 17, 1, 5);
		box15.setPosition(7F, 28F, -10F);
		box15.rotateAngleX = -3.857177646907468F;

		box16 = new ModelRendererTurbo(this, 193, 234, 256, 256);
		box16.addBox(0F, 0F, 0F, 1, 3, 3);
		box16.setPosition(-68F, 7F, 5F);

		box17 = new ModelRendererTurbo(this, 0, 31, 256, 256);
		box17.addBox(0F, -1F, 0F, 17, 1, 5);
		box17.setPosition(7F, 33F, 2F);
		box17.rotateAngleX = -6.09119908946021F;

		box18 = new ModelRendererTurbo(this, 91, 41, 256, 256);
		box18.addBox(0F, 0F, 0F, 2, 8, 5);
		box18.setPosition(-56F, 12F, 4F);
		box18.rotateAngleX = -0.22689280275926285F;

		box19 = new ModelRendererTurbo(this, 142, 227, 256, 256);
		box19.addBox(0F, 0F, 0F, 13, 1, 20);
		box19.setPosition(-45F, 14F, 10F);
		box19.rotateAngleY = -3.141592653589793F;
		box19.rotateAngleZ = -6.283185307179586F;

		box2 = new ModelRendererTurbo(this, 1, 24, 256, 256);
		box2.addBox(0F, 0F, 0F, 17, 1, 4);
		box2.setPosition(7F, 32F, -2F);

		box20 = new ModelRendererTurbo(this, 91, 41, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 8, 5);
		box20.setPosition(-54F, 12F, -4F);
		box20.rotateAngleX = -0.22689280275926285F;
		box20.rotateAngleY = -3.141592653589793F;

		box21 = new ModelRendererTurbo(this, 153, 1, 256, 256);
		box21.addBox(0F, -1F, 0F, 7, 1, 22);
		box21.setPosition(-2F, 16F, -11F);
		box21.rotateAngleZ = -0.6457718232379019F;

		box22 = new ModelRendererTurbo(this, 0, 249, 256, 256);
		box22.addBox(0F, 0F, 0F, 92, 3, 4);
		box22.setPosition(-69F, 6F, -2F);

		box23 = new ModelRendererTurbo(this, 81, 78, 256, 256);
		box23.addBox(0F, 0F, 0F, 3, 14, 12);
		box23.setPosition(8F, 14F, -6F);
		box23.rotateAngleZ = -6.126105674500097F;

		box24 = new ModelRendererTurbo(this, 176, 165, 256, 256);
		box24.addBox(0F, 0F, 0F, 13, 3, 4);
		box24.setPosition(8F, 14F, 5F);

		box25 = new ModelRendererTurbo(this, 176, 157, 256, 256);
		box25.addBox(0F, 0F, 0F, 13, 3, 4);
		box25.setPosition(8F, 14F, -9F);

		box26 = new ModelRendererTurbo(this, 0, 68, 256, 256);
		box26.addBox(0F, 0F, 0F, 1, 15, 18);
		box26.setPosition(7F, 12F, -9F);

		box27 = new ModelRendererTurbo(this, 7, 147, 256, 256);
		box27.addBox(0F, 0F, 0F, 16, 1, 22);
		box27.setPosition(-63F, 13F, -11F);

		box28 = new ModelRendererTurbo(this, 193, 157, 256, 256);
		box28.addBox(0F, 0F, 0F, 13, 2, 18);
		box28.setPosition(8F, 12F, -9F);

		box29 = new ModelRendererTurbo(this, 47, 26, 256, 256);
		box29.addBox(0F, 0F, 0F, 36, 2, 1);
		box29.setPosition(-4F, 5F, 7F);
		box29.rotateAngleY = -3.141592653589793F;

		box3 = new ModelRendererTurbo(this, 110, 63, 256, 256);
		box3.addBox(0F, 0F, 0F, 66, 7, 7);
		box3.setPosition(7F, 27F, 2F);
		box3.rotateAngleX = -5.497787143782138F;
		box3.rotateAngleY = -3.141592653589793F;

		box30 = new ModelRendererTurbo(this, 42, 17, 256, 256);
		box30.addBox(0F, 0F, 0F, 20, 2, 1);
		box30.setPosition(-23F, 5F, 8F);
		box30.rotateAngleY = -3.141592653589793F;
		box30.rotateAngleZ = -6.178465552059927F;

		box31 = new ModelRendererTurbo(this, 0, 104, 256, 256);
		box31.addBox(0F, 0F, 0F, 12, 11, 1);
		box31.setPosition(7F, 12F, -10F);

		box32 = new ModelRendererTurbo(this, 137, 31, 256, 256);
		box32.addBox(0F, 0F, 0F, 13, 6, 8);
		box32.setPosition(-33F, 27F, -4F);

		box33 = new ModelRendererTurbo(this, 112, 108, 256, 256);
		box33.addBox(0F, 0F, 0F, 66, 16, 6);
		box33.setPosition(-59F, 16F, -3F);

		box34 = new ModelRendererTurbo(this, 9, 63, 256, 256);
		box34.addBox(-1F, 0F, 0F, 1, 13, 3);
		box34.setPosition(19F, 11F, -10F);
		box34.rotateAngleY = -5.270894341022875F;

		box35 = new ModelRendererTurbo(this, 206, 20, 256, 256);
		box35.addBox(0F, -15F, 0F, 3, 15, 8);
		box35.setPosition(0F, 27F, 8F);
		box35.rotateAngleX = -6.161012259539984F;
		box35.rotateAngleY = -3.12413936106985F;
		box35.rotateAngleZ = 0.24434609527920614F;

		box36 = new ModelRendererTurbo(this, 111, 48, 256, 256);
		box36.addBox(0F, 0F, 0F, 66, 7, 7);
		box36.setPosition(7F, 27F, 8F);
		box36.rotateAngleX = -5.497787143782138F;
		box36.rotateAngleY = -3.141592653589793F;

		box37 = new ModelRendererTurbo(this, 112, 78, 256, 256);
		box37.addBox(0F, 0F, 0F, 59, 7, 7);
		box37.setPosition(0F, 21F, 8F);
		box37.rotateAngleX = -5.497787143782138F;
		box37.rotateAngleY = -3.141592653589793F;

		box38 = new ModelRendererTurbo(this, 112, 93, 256, 256);
		box38.addBox(0F, 0F, 0F, 59, 7, 7);
		box38.setPosition(-59F, 21F, -8F);
		box38.rotateAngleX = -5.497787143782138F;

		box39 = new ModelRendererTurbo(this, 232, 225, 256, 256);
		box39.addBox(0F, 0F, 0F, 8, 3, 4);
		box39.setPosition(-57F, 30F, -2F);

		box4 = new ModelRendererTurbo(this, 0, 9, 256, 256);
		box4.addBox(0F, -1F, 0F, 17, 1, 5);
		box4.setPosition(24F, 33F, -2F);
		box4.rotateAngleX = -6.09119908946021F;
		box4.rotateAngleY = -3.141592653589793F;

		box40 = new ModelRendererTurbo(this, 231, 20, 256, 256);
		box40.addBox(-3F, -15F, 0F, 3, 15, 8);
		box40.setPosition(0F, 27F, -8F);
		box40.rotateAngleX = -6.161012259539984F;
		box40.rotateAngleY = -0.017453292519943295F;
		box40.rotateAngleZ = -6.03883921190038F;

		box41 = new ModelRendererTurbo(this, 0, 63, 256, 256);
		box41.addBox(-1F, 0F, -3F, 1, 12, 3);
		box41.setPosition(19F, 12F, 10F);
		box41.rotateAngleY = -1.0122909661567112F;

		box42 = new ModelRendererTurbo(this, 65, 1, 256, 256);
		box42.addBox(0F, 1F, 0F, 19, 1, 22);
		box42.setPosition(3F, 10F, -11F);

		box43 = new ModelRendererTurbo(this, 223, 0, 256, 256);
		box43.addBox(0F, -15F, 0F, 7, 15, 4);
		box43.setPosition(0F, 27F, -8F);
		box43.rotateAngleX = -6.161012259539984F;

		box44 = new ModelRendererTurbo(this, 127, 0, 256, 256);
		box44.addBox(0F, 0F, 0F, 2, 1, 20);
		box44.setPosition(-67F, 10F, -10F);

		box45 = new ModelRendererTurbo(this, 43, 77, 256, 256);
		box45.addBox(0F, 0F, 0F, 1, 3, 2);
		box45.setPosition(8F, 27F, 8F);
		box45.rotateAngleX = -5.497787143782138F;
		box45.rotateAngleY = -3.141592653589793F;

		box46 = new ModelRendererTurbo(this, 36, 77, 256, 256);
		box46.addBox(-1F, 0F, 0F, 1, 3, 2);
		box46.setPosition(8F, 27F, -8F);
		box46.rotateAngleX = -5.497787143782138F;

		box47 = new ModelRendererTurbo(this, 87, 171, 256, 256);
		box47.addBox(0F, -1F, 0F, 4, 1, 22);
		box47.setPosition(-44F, 16F, 11F);
		box47.rotateAngleY = -3.141592653589793F;
		box47.rotateAngleZ = 0.5410520681182421F;

		box48 = new ModelRendererTurbo(this, 152, 195, 256, 256);
		box48.addBox(0F, 0F, 0F, 8, 8, 0);
		box48.setPosition(17F, 0F, 5F);
		box48.rotateAngleY = -3.141592653589793F;
		box48.rotateAngleZ = -6.283185307179586F;

		box49 = new ModelRendererTurbo(this, 187, 205, 256, 256);
		box49.addBox(0F, 0F, 0F, 1, 2, 20);
		box49.setPosition(21F, 9F, -10F);

		box5 = new ModelRendererTurbo(this, 152, 195, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 8, 0);
		box5.setPosition(-59F, 0F, 5F);
		box5.rotateAngleY = -3.141592653589793F;
		box5.rotateAngleZ = -6.283185307179586F;

		box50 = new ModelRendererTurbo(this, 71, 106, 256, 256);
		box50.addBox(0F, 0F, 0F, 4, 5, 16);
		box50.setPosition(15F, 2F, 8F);
		box50.rotateAngleY = -3.141592653589793F;
		box50.rotateAngleZ = -6.283185307179586F;

		box51 = new ModelRendererTurbo(this, 175, 178, 256, 256);
		box51.addBox(0F, 0F, 0F, 16, 16, 0);
		box51.setPosition(2F, 0F, 5F);
		box51.rotateAngleY = -3.141592653589793F;
		box51.rotateAngleZ = -6.283185307179586F;

		box52 = new ModelRendererTurbo(this, 175, 178, 256, 256);
		box52.addBox(0F, 0F, 0F, 16, 16, 0);
		box52.setPosition(-15F, 0F, 5F);
		box52.rotateAngleY = -3.141592653589793F;
		box52.rotateAngleZ = -6.283185307179586F;

		box53 = new ModelRendererTurbo(this, 175, 178, 256, 256);
		box53.addBox(0F, 0F, 0F, 16, 16, 0);
		box53.setPosition(-32F, 0F, 5F);
		box53.rotateAngleY = -3.141592653589793F;
		box53.rotateAngleZ = -6.283185307179586F;

		box54 = new ModelRendererTurbo(this, 152, 195, 256, 256);
		box54.addBox(0F, 0F, 0F, 8, 8, 0);
		box54.setPosition(-49F, 0F, 5F);
		box54.rotateAngleY = -3.141592653589793F;
		box54.rotateAngleZ = -6.283185307179586F;

		box55 = new ModelRendererTurbo(this, 159, 0, 256, 256);
		box55.addBox(0F, 0F, 0F, 1, 3, 2);
		box55.setPosition(-67F, 11F, -8F);

		box56 = new ModelRendererTurbo(this, 99, 173, 256, 256);
		box56.addBox(0F, 0F, 0F, 2, 1, 20);
		box56.setPosition(-65F, 10F, -10F);
		box56.rotateAngleZ = -5.82939970166106F;

		box57 = new ModelRendererTurbo(this, 47, 2, 256, 256);
		box57.addBox(0F, 0F, 0F, 18, 2, 1);
		box57.setPosition(-42F, 7F, 8F);
		box57.rotateAngleY = -3.141592653589793F;

		box58 = new ModelRendererTurbo(this, 0, 149, 256, 256);
		box58.addBox(-3F, -1F, 0F, 3, 1, 20);
		box58.setPosition(-63F, 14F, -10F);
		box58.rotateAngleZ = -5.096361415823442F;

		box59 = new ModelRendererTurbo(this, 75, 145, 256, 256);
		box59.addBox(0F, 0F, 0F, 15, 9, 14);
		box59.setPosition(22F, 2F, 7F);
		box59.rotateAngleY = -3.141592653589793F;

		box6 = new ModelRendererTurbo(this, 0, 225, 256, 256);
		box6.addBox(0F, 0F, 0F, 62, 16, 8);
		box6.setPosition(4F, 2F, 4F);
		box6.rotateAngleY = -3.141592653589793F;

		box60 = new ModelRendererTurbo(this, 196, 0, 256, 256);
		box60.addBox(0F, -15F, 0F, 7, 15, 4);
		box60.setPosition(7F, 27F, 8F);
		box60.rotateAngleX = -6.161012259539984F;
		box60.rotateAngleY = -3.141592653589793F;

		box61 = new ModelRendererTurbo(this, 150, 157, 256, 256);
		box61.addBox(0F, 0F, 0F, 5, 9, 2);
		box61.setPosition(7F, 2F, 7F);
		box61.rotateAngleY = -3.8048177693476384F;

		box62 = new ModelRendererTurbo(this, 0, 42, 256, 256);
		box62.addBox(0F, 0F, 0F, 4, 4, 12);
		box62.setPosition(-4F, 6F, 6F);
		box62.rotateAngleY = -3.141592653589793F;
		box62.rotateAngleZ = -6.283185307179586F;

		box63 = new ModelRendererTurbo(this, 0, 42, 256, 256);
		box63.addBox(0F, 0F, 0F, 4, 4, 12);
		box63.setPosition(-21F, 6F, 6F);
		box63.rotateAngleY = -3.141592653589793F;
		box63.rotateAngleZ = -6.283185307179586F;

		box64 = new ModelRendererTurbo(this, 0, 42, 256, 256);
		box64.addBox(0F, 0F, 0F, 4, 4, 12);
		box64.setPosition(-38F, 6F, 6F);
		box64.rotateAngleY = -3.141592653589793F;
		box64.rotateAngleZ = -6.283185307179586F;

		box65 = new ModelRendererTurbo(this, 88, 138, 256, 256);
		box65.addBox(0F, 0F, 0F, 5, 5, 1);
		box65.setPosition(-58F, 10F, 4F);
		box65.rotateAngleY = -3.141592653589793F;

		box66 = new ModelRendererTurbo(this, 88, 128, 256, 256);
		box66.addBox(-6F, -5F, 0F, 6, 5, 1);
		box66.setPosition(-63F, 15F, 3F);
		box66.rotateAngleZ = -5.410520681182422F;

		box67 = new ModelRendererTurbo(this, 55, 38, 256, 256);
		box67.addBox(0F, 0F, 0F, 6, 6, 22);
		box67.setPosition(-53F, 5F, 11F);
		box67.rotateAngleY = -3.141592653589793F;
		box67.rotateAngleZ = -6.283185307179586F;

		box68 = new ModelRendererTurbo(this, 88, 138, 256, 256);
		box68.addBox(0F, 0F, 0F, 5, 5, 1);
		box68.setPosition(-58F, 10F, -3F);
		box68.rotateAngleY = -3.141592653589793F;

		box69 = new ModelRendererTurbo(this, 88, 128, 256, 256);
		box69.addBox(-6F, -5F, 0F, 6, 5, 1);
		box69.setPosition(-63F, 15F, -4F);
		box69.rotateAngleZ = -5.410520681182422F;

		box7 = new ModelRendererTurbo(this, 218, 234, 256, 256);
		box7.addBox(0F, 0F, 0F, 1, 4, 18);
		box7.setPosition(-67F, 6F, -9F);

		box70 = new ModelRendererTurbo(this, 101, 136, 256, 256);
		box70.addBox(0F, 0F, 0F, 8, 7, 1);
		box70.setPosition(-58F, 3F, -3F);
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new ModelRendererTurbo(this, 101, 136, 256, 256);
		box71.addBox(0F, 0F, 0F, 8, 7, 1);
		box71.setPosition(-58F, 3F, 4F);
		box71.rotateAngleY = -3.141592653589793F;

		box72 = new ModelRendererTurbo(this, 106, 31, 256, 256);
		box72.addBox(0F, 0F, 0F, 2, 2, 12);
		box72.setPosition(-52F, 3F, 6F);
		box72.rotateAngleY = -3.141592653589793F;
		box72.rotateAngleZ = -6.283185307179586F;

		box73 = new ModelRendererTurbo(this, 106, 31, 256, 256);
		box73.addBox(0F, 0F, 0F, 2, 2, 12);
		box73.setPosition(-62F, 3F, 6F);
		box73.rotateAngleY = -3.141592653589793F;
		box73.rotateAngleZ = -6.283185307179586F;

		box74 = new ModelRendererTurbo(this, 130, 10, 256, 256);
		box74.addBox(0F, 0F, 0F, 5, 3, 2);
		box74.setPosition(-1F, 30F, -1F);

		box75 = new ModelRendererTurbo(this, 34, 124, 256, 256);
		box75.addBox(0F, 0F, 0F, 10, 4, 16);
		box75.setPosition(18F, 7F, 8F);
		box75.rotateAngleY = -3.141592653589793F;
		box75.rotateAngleZ = -6.283185307179586F;

		box76 = new ModelRendererTurbo(this, 209, 203, 256, 256);
		box76.addBox(0F, 0F, 0F, 3, 1, 20);
		box76.setPosition(19F, 3F, -10F);

		box77 = new ModelRendererTurbo(this, 209, 203, 256, 256);
		box77.addBox(0F, 0F, 0F, 3, 1, 20);
		box77.setPosition(19F, 7F, -10F);

		box78 = new ModelRendererTurbo(this, 135, 157, 256, 256);
		box78.addBox(-5F, 0F, 0F, 5, 9, 2);
		box78.setPosition(7F, 2F, -7F);
		box78.rotateAngleY = -5.619960191421741F;

		box79 = new ModelRendererTurbo(this, 196, 183, 256, 256);
		box79.addBox(0F, -1F, 0F, 4, 2, 14);
		box79.setPosition(-4F, 17F, 7F);
		box79.rotateAngleY = -3.141592653589793F;
		box79.rotateAngleZ = -6.283185307179586F;

		box8 = new ModelRendererTurbo(this, 69, 69, 256, 256);
		box8.addBox(0F, 0F, 0F, 16, 6, 1);
		box8.setPosition(-46F, 22F, 11F);
		box8.rotateAngleX = -6.19591884457987F;
		box8.rotateAngleY = -3.141592653589793F;

		box80 = new ModelRendererTurbo(this, 219, 186, 256, 256);
		box80.addBox(0F, -2F, 0F, 4, 2, 14);
		box80.setPosition(-8F, 18F, 7F);
		box80.rotateAngleY = -3.141592653589793F;
		box80.rotateAngleZ = 0.5235987755982988F;

		box81 = new ModelRendererTurbo(this, 169, 205, 256, 256);
		box81.addBox(0F, -2F, 0F, 4, 2, 14);
		box81.setPosition(-4F, 18F, -7F);
		box81.rotateAngleZ = -0.5235987755982988F;

		box82 = new ModelRendererTurbo(this, 142, 209, 256, 256);
		box82.addBox(-4F, -2F, 0F, 4, 2, 14);
		box82.setPosition(2F, 13F, -7F);
		box82.rotateAngleZ = -0.8552113334772214F;

		box83 = new ModelRendererTurbo(this, 196, 183, 256, 256);
		box83.addBox(0F, -1F, 0F, 4, 2, 14);
		box83.setPosition(-21F, 17F, 7F);
		box83.rotateAngleY = -3.141592653589793F;
		box83.rotateAngleZ = -6.283185307179586F;

		box84 = new ModelRendererTurbo(this, 219, 186, 256, 256);
		box84.addBox(0F, -2F, 0F, 4, 2, 14);
		box84.setPosition(-25F, 18F, 7F);
		box84.rotateAngleY = -3.141592653589793F;
		box84.rotateAngleZ = 0.5235987755982988F;

		box85 = new ModelRendererTurbo(this, 219, 186, 256, 256);
		box85.addBox(0F, -2F, 0F, 4, 2, 14);
		box85.setPosition(-21F, 18F, -7F);
		box85.rotateAngleZ = -0.5235987755982988F;

		box86 = new ModelRendererTurbo(this, 196, 183, 256, 256);
		box86.addBox(0F, -1F, 0F, 4, 2, 14);
		box86.setPosition(-38F, 17F, 7F);
		box86.rotateAngleY = -3.141592653589793F;
		box86.rotateAngleZ = -6.283185307179586F;

		box87 = new ModelRendererTurbo(this, 219, 186, 256, 256);
		box87.addBox(0F, -2F, 0F, 4, 2, 14);
		box87.setPosition(-42F, 18F, 7F);
		box87.rotateAngleY = -3.141592653589793F;
		box87.rotateAngleZ = 0.5235987755982988F;

		box88 = new ModelRendererTurbo(this, 219, 186, 256, 256);
		box88.addBox(0F, -2F, 0F, 4, 2, 14);
		box88.setPosition(-38F, 18F, -7F);
		box88.rotateAngleZ = -0.5235987755982988F;

		box89 = new ModelRendererTurbo(this, 119, 207, 256, 256);
		box89.addBox(-4F, -2F, 0F, 4, 2, 14);
		box89.setPosition(-48F, 13F, 7F);
		box89.rotateAngleY = -3.141592653589793F;
		box89.rotateAngleZ = -0.8552113334772214F;

		box9 = new ModelRendererTurbo(this, 193, 234, 256, 256);
		box9.addBox(0F, 0F, 0F, 1, 3, 3);
		box9.setPosition(-68F, 7F, -8F);

		box90 = new ModelRendererTurbo(this, 39, 86, 256, 256);
		box90.addBox(0F, 0F, 0F, 12, 1, 1);
		box90.setPosition(7F, 28F, 9F);

		box91 = new ModelRendererTurbo(this, 52, 103, 256, 256);
		box91.addBox(0F, 0F, 0F, 2, 5, 1);
		box91.setPosition(7F, 23F, 9F);

		box92 = new ModelRendererTurbo(this, 42, 103, 256, 256);
		box92.addBox(0F, 0F, 0F, 1, 5, 1);
		box92.setPosition(18F, 23F, 9F);

		box93 = new ModelRendererTurbo(this, 47, 103, 256, 256);
		box93.addBox(0F, 0F, 0F, 1, 5, 1);
		box93.setPosition(13F, 23F, 9F);

		box94 = new ModelRendererTurbo(this, 39, 89, 256, 256);
		box94.addBox(0F, 0F, 0F, 12, 1, 1);
		box94.setPosition(7F, 28F, -10F);

		box95 = new ModelRendererTurbo(this, 159, 0, 256, 256);
		box95.addBox(0F, 0F, 0F, 1, 3, 2);
		box95.setPosition(-67F, 11F, 6F);

		box96 = new ModelRendererTurbo(this, 52, 95, 256, 256);
		box96.addBox(0F, 0F, 0F, 2, 5, 1);
		box96.setPosition(7F, 23F, -10F);

		box97 = new ModelRendererTurbo(this, 47, 95, 256, 256);
		box97.addBox(0F, 0F, 0F, 1, 5, 1);
		box97.setPosition(13F, 23F, -10F);

		box98 = new ModelRendererTurbo(this, 190, 230, 256, 256);
		box98.addBox(0F, 0F, 0F, 2, 1, 20);
		box98.setPosition(-56F, 24F, -10F);

		box99 = new ModelRendererTurbo(this, 42, 95, 256, 256);
		box99.addBox(0F, 0F, 0F, 1, 5, 1);
		box99.setPosition(18F, 23F, -10F);
	}
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box2.render(f5);
		box3.render(f5);
		box4.render(f5);
		box5.render(f5);
		box6.render(f5);
		box7.render(f5);
		box8.render(f5);
		box9.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box30.render(f5);

		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);

		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box90.render(f5);
		box91.render(f5);
		box92.render(f5);
		box93.render(f5);
		box94.render(f5);
		box95.render(f5);
		box96.render(f5);
		box97.render(f5);
		box98.render(f5);
		box99.render(f5);
		box100.render(f5);
		box101.render(f5);
		box102.render(f5);
		box103.render(f5);
		box104.render(f5);
		box105.render(f5);
		box106.render(f5);
		box107.render(f5);
		box108.render(f5);
		box109.render(f5);
		box110.render(f5);
		box111.render(f5);
		box112.render(f5);
		box113.render(f5);
		box114.render(f5);
		box115.render(f5);
		box116.render(f5);
		box117.render(f5);
		box118.render(f5);
		box119.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
