package train.client.render.models;

import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;
import tmt.ModelBase;
import train.client.core.ClientProxy;
import train.client.render.ModelRendererTurbo;

public class ModelPassenger6 extends ModelBase {
	
	//private ModelLights lights;

	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box80;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box83;
	public ModelRendererTurbo box84;
	public ModelRendererTurbo box85;
	public ModelRendererTurbo box86;
	public ModelRendererTurbo box87;
	public ModelRendererTurbo box88;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;
	public ModelRendererTurbo box90;
	public ModelRendererTurbo box91;
	public ModelRendererTurbo box92;
	public ModelRendererTurbo box93;
	public ModelRendererTurbo box94;

	public ModelPassenger6() {
		
		//lights = new ModelLights();
		
		box = new ModelRendererTurbo(this, 158, 245, 256, 256);
		box.addBox(0F, 0F, 0F, 10, 4, 4);
		box.setPosition(-9F, 2F, 4F);

		box0 = new ModelRendererTurbo(this, 136, 0, 256, 256);
		box0.addBox(0F, 0F, 0F, 6, 1, 14);
		box0.setPosition(-31F, 4F, -7F);

		box1 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-20F, 0F, 5F);

		box10 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box10.addBox(0F, 0F, 0F, 5, 2, 15);
		box10.setPosition(-26F, 11F, -5F);
		box10.rotateAngleZ = -6.230825429619756F;

		box11 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box11.addBox(0F, 0F, 0F, 1, 10, 15);
		box11.setPosition(-11F, 11F, 10F);
		box11.rotateAngleY = -3.141592653589793F;
		box11.rotateAngleZ = 6.161012259539984F;

		box12 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box12.addBox(0F, 0F, 0F, 5, 2, 15);
		box12.setPosition(-11F, 11F, 10F);
		box12.rotateAngleY = -3.141592653589793F;
		box12.rotateAngleZ = -6.230825429619756F;

		box13 = new ModelRendererTurbo(this, 1, 79, 256, 256);
		box13.addBox(0F, 0F, 0F, 66, 4, 1);
		box13.setPosition(33F, 14F, -10F);
		box13.rotateAngleY = -3.141592653589793F;

		box14 = new ModelRendererTurbo(this, 1, 86, 256, 256);
		box14.addBox(0F, -6F, -1F, 66, 6, 1);
		box14.setPosition(33F, 14F, -11F);
		box14.rotateAngleX = -6.19591884457987F;
		box14.rotateAngleY = -3.141592653589793F;

		box15 = new ModelRendererTurbo(this, 1, 67, 256, 256);
		box15.addBox(0F, 0F, -1F, 66, 9, 1);
		box15.setPosition(33F, 18F, -11F);
		box15.rotateAngleX = -0.03490658503988659F;
		box15.rotateAngleY = -3.141592653589793F;

		box16 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-32F, 0F, -5F);

		box17 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 2, 14);
		box17.setPosition(-29F, 2F, -7F);

		box18 = new ModelRendererTurbo(this, 136, 0, 256, 256);
		box18.addBox(0F, 0F, 0F, 6, 1, 14);
		box18.setPosition(-19F, 4F, -7F);

		box19 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(24F, 0F, -5F);

		box2 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 14);
		box2.setPosition(15F, 2F, -7F);

		box20 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 14);
		box20.setPosition(27F, 2F, -7F);

		box21 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(24F, 0F, 5F);

		box22 = new ModelRendererTurbo(this, 136, 0, 256, 256);
		box22.addBox(0F, 0F, 0F, 6, 1, 14);
		box22.setPosition(13F, 4F, -7F);

		box23 = new ModelRendererTurbo(this, 209, 111, 256, 256);
		box23.addBox(3F, 0F, 0F, 22, 3, 1);
		box23.setPosition(-36F, 1F, 5F);

		box24 = new ModelRendererTurbo(this, 181, 93, 256, 256);
		box24.addBox(0F, 0F, 0F, 22, 2, 12);
		box24.setPosition(11F, 4F, -6F);

		box25 = new ModelRendererTurbo(this, 181, 93, 256, 256);
		box25.addBox(0F, 0F, 0F, 22, 2, 12);
		box25.setPosition(-33F, 4F, -6F);

		box26 = new ModelRendererTurbo(this, 187, 246, 256, 256);
		box26.addBox(0F, 0F, 0F, 10, 3, 4);
		box26.setPosition(-5F, 3F, -2F);

		box27 = new ModelRendererTurbo(this, 188, 239, 256, 256);
		box27.addBox(0F, 0F, 0F, 8, 1, 4);
		box27.setPosition(5F, 3F, -2F);
		box27.rotateAngleZ = -5.846852994181004F;

		box28 = new ModelRendererTurbo(this, 217, 246, 256, 256);
		box28.addBox(0F, 0F, 0F, 8, 4, 3);
		box28.setPosition(1F, 2F, -8F);

		//
		box29 = new ModelRendererTurbo(this, 188, 239, 256, 256);
		box29.addBox(0F, 0F, 0F, 8, 1, 4);
		box29.setPosition(-5F, 3F, 2F);
		box29.rotateAngleY = -3.141592653589793F;
		box29.rotateAngleZ = 5.846852994181004F;

		box3 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 14);
		box3.setPosition(-17F, 2F, -7F);

		box30 = new ModelRendererTurbo(this, 2, 191, 256, 256);
		box30.addBox(0F, 0F, 0F, 54, 21, 0);
		box30.setPosition(-27F, 9F, -5F);

		box31 = new ModelRendererTurbo(this, 182, 209, 256, 256);
		box31.addBox(0F, 0F, 0F, 1, 17, 2);
		box31.setPosition(-35F, 11F, -6F);

		box32 = new ModelRendererTurbo(this, 182, 209, 256, 256);
		box32.addBox(0F, 0F, 0F, 1, 17, 2);
		box32.setPosition(-35F, 11F, 4F);

		box33 = new ModelRendererTurbo(this, 189, 210, 256, 256);
		box33.addBox(0F, 0F, 0F, 1, 4, 8);
		box33.setPosition(-35F, 25F, -4F);

		box34 = new ModelRendererTurbo(this, 209, 55, 256, 256);
		box34.addBox(0F, 0F, 0F, 2, 0, 8);
		box34.setPosition(-34F, 9F, 4F);
		box34.rotateAngleY = -3.141592653589793F;
		box34.rotateAngleZ = 6.178465552059927F;

		box35 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(12F, 0F, 5F);

		box36 = new ModelRendererTurbo(this, 215, 209, 256, 256);
		box36.addBox(0F, 0F, 0F, 1, 17, 2);
		box36.setPosition(34F, 11F, -6F);

		box37 = new ModelRendererTurbo(this, 215, 209, 256, 256);
		box37.addBox(0F, 0F, 0F, 1, 17, 2);
		box37.setPosition(34F, 11F, 4F);

		box38 = new ModelRendererTurbo(this, 222, 209, 256, 256);
		box38.addBox(0F, 0F, 0F, 1, 4, 8);
		box38.setPosition(34F, 25F, -4F);

		box39 = new ModelRendererTurbo(this, 209, 55, 256, 256);
		box39.addBox(0F, 0F, 0F, 2, 0, 8);
		box39.setPosition(34F, 9F, -4F);
		box39.rotateAngleZ = -6.178465552059927F;

		box4 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box4.addBox(0F, 0F, 0F, 8, 7, 0);
		box4.setPosition(-32F, 0F, 5F);

		box40 = new ModelRendererTurbo(this, 200, 0, 256, 256);
		box40.addBox(0F, 0F, 0F, 6, 1, 22);
		box40.setPosition(27F, 6F, -11F);

		box41 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box41.addBox(0F, 0F, 0F, 5, 2, 15);
		box41.setPosition(-8F, 11F, -5F);
		box41.rotateAngleZ = -6.230825429619756F;

		box42 = new ModelRendererTurbo(this, 200, 0, 256, 256);
		box42.addBox(0F, 0F, 0F, 6, 1, 22);
		box42.setPosition(-33F, 6F, -11F);

		box43 = new ModelRendererTurbo(this, 209, 73, 256, 256);
		box43.addBox(0F, 0F, 0F, 5, 1, 3);
		box43.setPosition(-21F, 15F, 7F);

		box44 = new ModelRendererTurbo(this, 208, 78, 256, 256);
		box44.addBox(0F, 0F, 0F, 6, 1, 3);
		box44.setPosition(-3F, 15F, 7F);

		box45 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box45.addBox(0F, 0F, 0F, 1, 10, 15);
		box45.setPosition(26F, 11F, 10F);
		box45.rotateAngleY = -3.141592653589793F;
		box45.rotateAngleZ = 6.19591884457987F;

		box46 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box46.addBox(0F, 0F, 0F, 5, 2, 15);
		box46.setPosition(11F, 11F, -5F);
		box46.rotateAngleZ = -6.230825429619756F;

		box47 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box47.addBox(0F, 0F, 0F, 5, 2, 15);
		box47.setPosition(26F, 11F, 10F);
		box47.rotateAngleY = -3.141592653589793F;
		box47.rotateAngleZ = -6.230825429619756F;

		box48 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box48.addBox(0F, 0F, 0F, 1, 10, 15);
		box48.setPosition(11F, 11F, -5F);
		box48.rotateAngleZ = -6.161012259539984F;

		box49 = new ModelRendererTurbo(this, 209, 73, 256, 256);
		box49.addBox(0F, 0F, 0F, 5, 1, 3);
		box49.setPosition(16F, 15F, 7F);

		box5 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(12F, 0F, -5F);

		box50 = new ModelRendererTurbo(this, 209, 116, 256, 256);
		box50.addBox(3F, 0F, 0F, 22, 3, 1);
		box50.setPosition(-36F, 1F, -6F);

		box51 = new ModelRendererTurbo(this, 136, 0, 256, 256);
		box51.addBox(0F, 0F, 0F, 6, 1, 14);
		box51.setPosition(25F, 4F, -7F);

		box52 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box52.addBox(0F, 0F, 0F, 4, 1, 15);
		box52.setPosition(-27F, 26F, -5F);
		box52.rotateAngleZ = -6.213372137099813F;

		box53 = new ModelRendererTurbo(this, 141, 172, 256, 256);
		box53.addBox(0F, -6F, -1F, 1, 6, 1);
		box53.setPosition(-34F, 14F, 11F);
		box53.rotateAngleX = -6.19591884457987F;

		box54 = new ModelRendererTurbo(this, 141, 165, 256, 256);
		box54.addBox(0F, 0F, 0F, 1, 4, 1);
		box54.setPosition(-34F, 14F, 10F);

		box55 = new ModelRendererTurbo(this, 141, 153, 256, 256);
		box55.addBox(0F, 0F, -1F, 1, 9, 1);
		box55.setPosition(-34F, 18F, 11F);
		box55.rotateAngleX = -0.03490658503988659F;

		box56 = new ModelRendererTurbo(this, 136, 153, 256, 256);
		box56.addBox(0F, 0F, -1F, 1, 9, 1);
		box56.setPosition(33F, 18F, 11F);
		box56.rotateAngleX = -0.03490658503988659F;

		box57 = new ModelRendererTurbo(this, 136, 165, 256, 256);
		box57.addBox(0F, 0F, 0F, 1, 4, 1);
		box57.setPosition(33F, 14F, 10F);

		box58 = new ModelRendererTurbo(this, 136, 172, 256, 256);
		box58.addBox(0F, -6F, -1F, 1, 6, 1);
		box58.setPosition(33F, 14F, 11F);
		box58.rotateAngleX = -6.19591884457987F;

		box59 = new ModelRendererTurbo(this, 140, 79, 256, 256);
		box59.addBox(0F, 0F, 0F, 1, 4, 1);
		box59.setPosition(34F, 14F, -10F);
		box59.rotateAngleY = -3.141592653589793F;

		box6 = new ModelRendererTurbo(this, 209, 116, 256, 256);
		box6.addBox(3F, 0F, 0F, 22, 3, 1);
		box6.setPosition(8F, 1F, -6F);

		box60 = new ModelRendererTurbo(this, 140, 86, 256, 256);
		box60.addBox(0F, -6F, -1F, 1, 6, 1);
		box60.setPosition(34F, 14F, -11F);
		box60.rotateAngleX = -6.19591884457987F;
		box60.rotateAngleY = -3.141592653589793F;

		box61 = new ModelRendererTurbo(this, 140, 67, 256, 256);
		box61.addBox(0F, 0F, -1F, 1, 9, 1);
		box61.setPosition(34F, 18F, -11F);
		box61.rotateAngleX = -0.03490658503988659F;
		box61.rotateAngleY = -3.141592653589793F;

		box62 = new ModelRendererTurbo(this, 145, 67, 256, 256);
		box62.addBox(0F, 0F, -1F, 1, 9, 1);
		box62.setPosition(-33F, 18F, -11F);
		box62.rotateAngleX = -0.03490658503988659F;
		box62.rotateAngleY = -3.141592653589793F;

		box63 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-20F, 0F, -5F);

		box64 = new ModelRendererTurbo(this, 213, 165, 256, 256);
		box64.addBox(0F, 0F, 0F, 0, 22, 20);
		box64.setPosition(-34F, 8F, -10F);

		box65 = new ModelRendererTurbo(this, 0, 215, 256, 256);
		box65.addBox(0F, 0F, 0F, 68, 2, 18);
		box65.setPosition(-34F, 6F, -9F);

		box66 = new ModelRendererTurbo(this, 152, 35, 256, 256);
		box66.addBox(0F, 0F, 0F, 2, 3, 4);
		box66.setPosition(-36F, 6F, -2F);

		box67 = new ModelRendererTurbo(this, 153, 44, 256, 256);
		box67.addBox(0F, 0F, 0F, 1, 3, 3);
		box67.setPosition(-35F, 7F, 5F);

		box68 = new ModelRendererTurbo(this, 153, 44, 256, 256);
		box68.addBox(0F, 0F, 0F, 1, 3, 3);
		box68.setPosition(-35F, 7F, -8F);

		box69 = new ModelRendererTurbo(this, 0, 46, 256, 256);
		box69.addBox(0F, -2F, 0F, 68, 2, 6);
		box69.setPosition(-34F, 32F, -3F);

		box7 = new ModelRendererTurbo(this, 1, 153, 256, 256);
		box7.addBox(0F, 0F, -1F, 66, 9, 1);
		box7.setPosition(-33F, 18F, 11F);
		box7.rotateAngleX = -0.03490658503988659F;

		box70 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box70.addBox(0F, -2F, 0F, 68, 2, 5);
		box70.setPosition(34F, 32F, -3F);
		box70.rotateAngleX = -6.09119908946021F;
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new ModelRendererTurbo(this, 1, 38, 256, 256);
		box71.addBox(0F, -2F, 0F, 68, 2, 5);
		box71.setPosition(34F, 31F, -8F);
		box71.rotateAngleX = -5.340707511102648F;
		box71.rotateAngleY = -3.141592653589793F;

		box72 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box72.addBox(0F, -2F, 0F, 68, 2, 5);
		box72.setPosition(-34F, 32F, 3F);
		box72.rotateAngleX = -6.09119908946021F;

		box73 = new ModelRendererTurbo(this, 1, 38, 256, 256);
		box73.addBox(0F, -2F, 0F, 68, 2, 5);
		box73.setPosition(-34F, 31F, 8F);
		box73.rotateAngleX = -5.305800926062762F;

		box74 = new ModelRendererTurbo(this, 0, 235, 256, 256);
		box74.addBox(0F, 0F, 0F, 68, 1, 20);
		box74.setPosition(-34F, 8F, -10F);

		box75 = new ModelRendererTurbo(this, 171, 165, 256, 256);
		box75.addBox(0F, 0F, 0F, 0, 22, 20);
		box75.setPosition(34F, 8F, -10F);

		box76 = new ModelRendererTurbo(this, 163, 44, 256, 256);
		box76.addBox(0F, 0F, 0F, 1, 3, 3);
		box76.setPosition(34F, 7F, -8F);

		box77 = new ModelRendererTurbo(this, 163, 44, 256, 256);
		box77.addBox(0F, 0F, 0F, 1, 3, 3);
		box77.setPosition(34F, 7F, 5F);

		box78 = new ModelRendererTurbo(this, 165, 35, 256, 256);
		box78.addBox(0F, 0F, 0F, 2, 3, 4);
		box78.setPosition(34F, 6F, -2F);

		box79 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box79.addBox(0F, 0F, 0F, 1, 10, 15);
		box79.setPosition(-8F, 11F, -5F);
		box79.rotateAngleZ = -6.161012259539984F;

		box8 = new ModelRendererTurbo(this, 209, 111, 256, 256);
		box8.addBox(3F, 0F, 0F, 22, 3, 1);
		box8.setPosition(8F, 1F, 5F);

		box80 = new ModelRendererTurbo(this, 145, 79, 256, 256);
		box80.addBox(0F, 0F, 0F, 1, 4, 1);
		box80.setPosition(-33F, 14F, -10F);
		box80.rotateAngleY = -3.141592653589793F;

		//chair
		box81 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box81.addBox(0F, 0F, 0F, 1, 10, 15);
		box81.setPosition(8F, 11F, 10F);
		box81.rotateAngleY = -3.141592653589793F;
		box81.rotateAngleZ = 6.161012259539984F;

		box82 = new ModelRendererTurbo(this, 215, 51, 256, 256);
		box82.addBox(0F, 0F, 0F, 5, 2, 15);
		box82.setPosition(8F, 11F, 10F);
		box82.rotateAngleY = -3.141592653589793F;
		box82.rotateAngleZ = -6.230825429619756F;

		box83 = new ModelRendererTurbo(this, 199, 122, 256, 256);
		box83.addBox(0F, 0F, 0F, 1, 21, 15);
		box83.setPosition(-10F, 9F, -5F);

		box84 = new ModelRendererTurbo(this, 199, 122, 256, 256);
		box84.addBox(0F, 0F, 0F, 1, 21, 15);
		box84.setPosition(9F, 9F, -5F);

		box85 = new ModelRendererTurbo(this, 169, 140, 256, 256);
		box85.addBox(0F, 0F, 0F, 0, 21, 20);
		box85.setPosition(-27F, 9F, -10F);

		box86 = new ModelRendererTurbo(this, 145, 86, 256, 256);
		box86.addBox(0F, -6F, -1F, 1, 6, 1);
		box86.setPosition(-33F, 14F, -11F);
		box86.rotateAngleX = -6.19591884457987F;
		box86.rotateAngleY = -3.141592653589793F;

		box87 = new ModelRendererTurbo(this, 213, 140, 256, 256);
		box87.addBox(0F, 0F, 0F, 0, 21, 20);
		box87.setPosition(27F, 9F, -10F);

		box88 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box88.addBox(0F, 0F, 0F, 4, 1, 15);
		box88.setPosition(-10F, 26F, 10F);
		box88.rotateAngleY = -3.141592653589793F;
		box88.rotateAngleZ = 6.213372137099813F;

		box89 = new ModelRendererTurbo(this, 1, 165, 256, 256);
		box89.addBox(0F, 0F, 0F, 66, 4, 1);
		box89.setPosition(-33F, 14F, 10F);

		box9 = new ModelRendererTurbo(this, 223, 25, 256, 256);
		box9.addBox(0F, 0F, 0F, 1, 10, 15);
		box9.setPosition(-26F, 11F, -5F);
		box9.rotateAngleZ = -6.19591884457987F;

		box90 = new ModelRendererTurbo(this, 1, 172, 256, 256);
		box90.addBox(0F, -6F, -1F, 66, 6, 1);
		box90.setPosition(-33F, 14F, 11F);
		box90.rotateAngleX = -6.19591884457987F;

		box91 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box91.addBox(0F, 0F, 0F, 4, 1, 15);
		box91.setPosition(-9F, 26F, -5F);
		box91.rotateAngleZ = -6.213372137099813F;

		box92 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box92.addBox(0F, 0F, 0F, 4, 1, 15);
		box92.setPosition(9F, 26F, 10F);
		box92.rotateAngleY = -3.141592653589793F;
		box92.rotateAngleZ = 6.213372137099813F;

		box93 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box93.addBox(0F, 0F, 0F, 4, 1, 15);
		box93.setPosition(10F, 26F, -5F);
		box93.rotateAngleZ = -6.213372137099813F;

		box94 = new ModelRendererTurbo(this, 217, 71, 256, 256);
		box94.addBox(0F, 0F, 0F, 4, 1, 15);
		box94.setPosition(27F, 26F, 10F);
		box94.rotateAngleY = -3.141592653589793F;
		box94.rotateAngleZ = 6.213372137099813F;
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		box90.render(f5);
		box91.render(f5);
		box92.render(f5);
		box93.render(f5);
		box94.render(f5);
		
		if (ClientProxy.isHoliday()) {
			GL11.glPushMatrix();
			GL11.glTranslatef(-1.12f, 0.8f, -0.72f);
			//lights.render(5);
			GL11.glPopMatrix();
			
			GL11.glPushMatrix();
			GL11.glTranslatef(0, 0.8f, -0.72f);
			//lights.render(5);
			GL11.glPopMatrix();
			
			GL11.glPushMatrix();
			GL11.glTranslatef(1.12f, 0.8f, -0.72f);
			//lights.render(5);
			GL11.glPopMatrix();
			
			GL11.glPushMatrix();
			GL11.glTranslatef(-1.12f, 0.8f, 0.72f);
			GL11.glRotatef(-180f, 0, 1, 0);
			//lights.render(5);
			GL11.glPopMatrix();
			
			GL11.glPushMatrix();
			GL11.glTranslatef(0, 0.8f, 0.72f);
			GL11.glRotatef(-180f, 0, 1, 0);
			//lights.render(5);
			GL11.glPopMatrix();
			
			GL11.glPushMatrix();
			GL11.glTranslatef(1.12f, 0.8f, 0.72f);
			GL11.glRotatef(-180f, 0, 1, 0);
			//lights.render(5);
			GL11.glPopMatrix();
		}
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
