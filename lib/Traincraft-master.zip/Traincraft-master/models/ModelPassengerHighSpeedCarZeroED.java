package train.client.render.models;

import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelPassengerHighSpeedCarZeroED extends ModelBase {
	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box80;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box83;
	public ModelRendererTurbo box84;
	public ModelRendererTurbo box85;
	public ModelRendererTurbo box86;
	public ModelRendererTurbo box87;
	public ModelRendererTurbo box88;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;
	public ModelRendererTurbo box90;
	public ModelRendererTurbo box91;
	public ModelRendererTurbo box92;
	
	public ModelPassengerHighSpeedCarZeroED() {

		box = new ModelRendererTurbo(this, 4, 115, 256, 128);
		box.addBox(0F, -5F, 0F, 4, 5, 1);
		box.setPosition(-33F, 6F, -11F);
		box.rotateAngleX = -0.33161255787892263F;

		box0 = new ModelRendererTurbo(this, 63, 38, 256, 128);
		box0.addBox(0F, 0F, 0F, 66, 2, 18);
		box0.setPosition(-33F, 29F, -9F);

		box1 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-18F, 0F, 5F);

		box10 = new ModelRendererTurbo(this, 98, 122, 256, 128);
		box10.addBox(0F, -5F, -1F, 22, 5, 1);
		box10.setPosition(-11F, 6F, 11F);
		box10.rotateAngleX = -5.951572749300664F;

		box11 = new ModelRendererTurbo(this, 153, 65, 256, 128);
		box11.addBox(0F, 0F, 0F, 1, 20, 20);
		box11.setPosition(-33F, 9F, -10F);

		box12 = new ModelRendererTurbo(this, 84, 70, 256, 128);
		box12.addBox(0F, 0F, 0F, 0, 20, 20);
		box12.setPosition(-27F, 9F, -10F);

		box13 = new ModelRendererTurbo(this, 132, 96, 256, 128);
		box13.addBox(-2F, 0F, 0F, 1, 8, 13);
		box13.setPosition(2F, 12F, 10F);
		box13.rotateAngleY = 3.141592653589793F;
		box13.rotateAngleZ = 6.161012259539984F;

		box14 = new ModelRendererTurbo(this, 1, 6, 256, 128);
		box14.addBox(0F, 0F, 0F, 66, 18, 1);
		box14.setPosition(33F, 6F, -10F);
		box14.rotateAngleY = -3.141592653589793F;

		box15 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box15.addBox(0F, -2F, 0F, 5, 1, 1);
		box15.setPosition(4F, 17F, 4F);
		box15.rotateAngleY = -3.141592653589793F;

		box16 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-30F, 0F, -5F);

		box17 = new ModelRendererTurbo(this, 199, 14, 256, 128);
		box17.addBox(0F, 0F, 0F, 2, 2, 14);
		box17.setPosition(-27F, 2F, -7F);

		box18 = new ModelRendererTurbo(this, 201, 64, 256, 128);
		box18.addBox(-2F, -1F, 0F, 6, 2, 13);
		box18.setPosition(2F, 12F, 10F);
		box18.rotateAngleY = -3.141592653589793F;
		box18.rotateAngleZ = 6.213372137099813F;

		box19 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(22F, 0F, -5F);

		box2 = new ModelRendererTurbo(this, 199, 14, 256, 128);
		box2.addBox(0F, 0F, 0F, 2, 2, 14);
		box2.setPosition(13F, 2F, -7F);

		box20 = new ModelRendererTurbo(this, 199, 14, 256, 128);
		box20.addBox(0F, 0F, 0F, 2, 2, 14);
		box20.setPosition(25F, 2F, -7F);

		box21 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(22F, 0F, 5F);

		box22 = new ModelRendererTurbo(this, 145, 5, 256, 128);
		box22.addBox(0F, 0F, 0F, 8, 4, 16);
		box22.setPosition(16F, 1F, -8F);

		box23 = new ModelRendererTurbo(this, 145, 5, 256, 128);
		box23.addBox(0F, 0F, 0F, 8, 4, 16);
		box23.setPosition(-24F, 1F, -8F);

		box24 = new ModelRendererTurbo(this, 121, 1, 256, 128);
		box24.addBox(0F, 0F, 0F, 16, 3, 1);
		box24.setPosition(-28F, 3F, -6F);

		box25 = new ModelRendererTurbo(this, 132, 96, 256, 128);
		box25.addBox(-2F, 0F, 0F, 1, 8, 13);
		box25.setPosition(-9F, 12F, 10F);
		box25.rotateAngleY = 3.141592653589793F;
		box25.rotateAngleZ = 6.161012259539984F;

		box26 = new ModelRendererTurbo(this, 0, 39, 256, 128);
		box26.addBox(0F, 0F, 0F, 17, 5, 14);
		box26.setPosition(-9F, 1F, -6F);

		box27 = new ModelRendererTurbo(this, 201, 64, 256, 128);
		box27.addBox(-2F, -1F, 0F, 6, 2, 13);
		box27.setPosition(-9F, 12F, 10F);
		box27.rotateAngleY = -3.141592653589793F;
		box27.rotateAngleZ = 6.213372137099813F;

		box28 = new ModelRendererTurbo(this, 201, 64, 256, 128);
		box28.addBox(-2F, -1F, 0F, 6, 2, 13);
		box28.setPosition(-20F, 12F, 10F);
		box28.rotateAngleY = -3.141592653589793F;
		box28.rotateAngleZ = 6.213372137099813F;

		box29 = new ModelRendererTurbo(this, 132, 96, 256, 128);
		box29.addBox(-2F, 0F, 0F, 1, 8, 13);
		box29.setPosition(-20F, 12F, 10F);
		box29.rotateAngleY = 3.141592653589793F;
		box29.rotateAngleZ = 6.161012259539984F;

		box3 = new ModelRendererTurbo(this, 199, 14, 256, 128);
		box3.addBox(0F, 0F, 0F, 2, 2, 14);
		box3.setPosition(-15F, 2F, -7F);

		box30 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box30.addBox(0F, -2F, 0F, 5, 1, 1);
		box30.setPosition(-7F, 17F, 10F);
		box30.rotateAngleY = -3.141592653589793F;

		box31 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box31.addBox(0F, -2F, 0F, 5, 1, 1);
		box31.setPosition(-7F, 17F, 4F);
		box31.rotateAngleY = -3.141592653589793F;

		box32 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box32.addBox(0F, -2F, 0F, 5, 1, 1);
		box32.setPosition(-18F, 17F, 4F);
		box32.rotateAngleY = -3.141592653589793F;

		box33 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box33.addBox(0F, -2F, 0F, 5, 1, 1);
		box33.setPosition(-18F, 17F, 10F);
		box33.rotateAngleY = -3.141592653589793F;

		box34 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box34.addBox(0F, -2F, 0F, 5, 1, 1);
		box34.setPosition(-18F, 17F, -2F);
		box34.rotateAngleY = -3.141592653589793F;

		box35 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(10F, 0F, 5F);

		box36 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box36.addBox(0F, -2F, 0F, 5, 1, 1);
		box36.setPosition(-7F, 17F, -2F);
		box36.rotateAngleY = -3.141592653589793F;

		box37 = new ModelRendererTurbo(this, 201, 64, 256, 128);
		box37.addBox(-2F, -1F, 0F, 6, 2, 13);
		box37.setPosition(13F, 12F, 10F);
		box37.rotateAngleY = -3.141592653589793F;
		box37.rotateAngleZ = 6.213372137099813F;

		box38 = new ModelRendererTurbo(this, 201, 64, 256, 128);
		box38.addBox(-2F, -1F, 0F, 6, 2, 13);
		box38.setPosition(24F, 12F, 10F);
		box38.rotateAngleY = -3.141592653589793F;
		box38.rotateAngleZ = 6.213372137099813F;

		box39 = new ModelRendererTurbo(this, 132, 96, 256, 128);
		box39.addBox(-2F, 0F, 0F, 1, 8, 13);
		box39.setPosition(13F, 12F, 10F);
		box39.rotateAngleY = 3.141592653589793F;
		box39.rotateAngleZ = 6.161012259539984F;

		box4 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box4.addBox(0F, 0F, 0F, 8, 7, 0);
		box4.setPosition(-30F, 0F, 5F);

		box40 = new ModelRendererTurbo(this, 132, 96, 256, 128);
		box40.addBox(-2F, 0F, 0F, 1, 8, 13);
		box40.setPosition(24F, 12F, 10F);
		box40.rotateAngleY = 3.141592653589793F;
		box40.rotateAngleZ = 6.161012259539984F;

		box41 = new ModelRendererTurbo(this, 149, 122, 256, 128);
		box41.addBox(0F, -5F, 0F, 22, 5, 1);
		box41.setPosition(-11F, 6F, -11F);
		box41.rotateAngleX = -0.33161255787892263F;

		box42 = new ModelRendererTurbo(this, 4, 115, 256, 128);
		box42.addBox(0F, -5F, 0F, 4, 5, 1);
		box42.setPosition(29F, 6F, -11F);
		box42.rotateAngleX = -0.33161255787892263F;

		box43 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box43.addBox(0F, -2F, 0F, 5, 1, 1);
		box43.setPosition(15F, 17F, -2F);
		box43.rotateAngleY = -3.141592653589793F;

		box44 = new ModelRendererTurbo(this, 153, 65, 256, 128);
		box44.addBox(0F, 0F, 0F, 1, 20, 20);
		box44.setPosition(33F, 9F, 10F);
		box44.rotateAngleY = -3.141592653589793F;

		box45 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box45.addBox(0F, -2F, 0F, 5, 1, 1);
		box45.setPosition(26F, 17F, -2F);
		box45.rotateAngleY = -3.141592653589793F;

		box46 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box46.addBox(0F, -2F, 0F, 5, 1, 1);
		box46.setPosition(15F, 17F, 4F);
		box46.rotateAngleY = -3.141592653589793F;

		box47 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box47.addBox(0F, -2F, 0F, 5, 1, 1);
		box47.setPosition(26F, 17F, 10F);
		box47.rotateAngleY = -3.141592653589793F;

		box48 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box48.addBox(0F, -2F, 0F, 5, 1, 1);
		box48.setPosition(15F, 17F, 10F);
		box48.rotateAngleY = -3.141592653589793F;

		box49 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box49.addBox(0F, -2F, 0F, 5, 1, 1);
		box49.setPosition(26F, 17F, 4F);
		box49.rotateAngleY = -3.141592653589793F;

		box5 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(10F, 0F, -5F);

		box50 = new ModelRendererTurbo(this, 179, 60, 256, 128);
		box50.addBox(-2F, -1F, 0F, 4, 3, 12);
		box50.setPosition(23F, 10F, 10F);
		box50.rotateAngleY = -3.141592653589793F;

		box51 = new ModelRendererTurbo(this, 179, 60, 256, 128);
		box51.addBox(-2F, -1F, 0F, 4, 3, 12);
		box51.setPosition(12F, 10F, 10F);
		box51.rotateAngleY = -3.141592653589793F;

		box52 = new ModelRendererTurbo(this, 179, 60, 256, 128);
		box52.addBox(-2F, -1F, 0F, 4, 3, 12);
		box52.setPosition(1F, 10F, 10F);
		box52.rotateAngleY = -3.141592653589793F;

		box53 = new ModelRendererTurbo(this, 179, 60, 256, 128);
		box53.addBox(-2F, -1F, 0F, 4, 3, 12);
		box53.setPosition(-10F, 10F, 10F);
		box53.rotateAngleY = -3.141592653589793F;

		box54 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box54.addBox(0F, -2F, 0F, 5, 1, 1);
		box54.setPosition(4F, 17F, 10F);
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new ModelRendererTurbo(this, 201, 122, 256, 128);
		box55.addBox(0F, -2F, 0F, 5, 1, 1);
		box55.setPosition(4F, 17F, -2F);
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new ModelRendererTurbo(this, 179, 60, 256, 128);
		box56.addBox(-2F, -1F, 0F, 4, 3, 12);
		box56.setPosition(-21F, 10F, 10F);
		box56.rotateAngleY = -3.141592653589793F;

		box57 = new ModelRendererTurbo(this, 28, 112, 256, 128);
		box57.addBox(0F, 0F, 0F, 24, 1, 10);
		box57.setPosition(-28F, 31F, -5F);

		box58 = new ModelRendererTurbo(this, 1, 85, 256, 128);
		box58.addBox(0F, 0F, 0F, 11, 1, 8);
		box58.setPosition(16F, 31F, -5F);

		box59 = new ModelRendererTurbo(this, 1, 27, 256, 128);
		box59.addBox(0F, 0F, -1F, 66, 8, 1);
		box59.setPosition(-33F, 24F, 11F);
		box59.rotateAngleX = -0.22689280275926285F;

		box6 = new ModelRendererTurbo(this, 40, 70, 256, 128);
		box6.addBox(0F, 0F, 0F, 0, 20, 20);
		box6.setPosition(27F, 9F, 10F);
		box6.rotateAngleY = -3.141592653589793F;

		box60 = new ModelRendererTurbo(this, 17, 115, 256, 128);
		box60.addBox(0F, -5F, -1F, 4, 5, 1);
		box60.setPosition(-33F, 6F, 11F);
		box60.rotateAngleX = -5.951572749300664F;

		box61 = new ModelRendererTurbo(this, 248, 86, 256, 128);
		box61.addBox(0F, 0F, 0F, 1, 16, 2);
		box61.setPosition(-34F, 10F, 3F);

		box62 = new ModelRendererTurbo(this, 248, 86, 256, 128);
		box62.addBox(0F, 0F, 0F, 1, 16, 2);
		box62.setPosition(-34F, 10F, -5F);

		box63 = new ModelRendererTurbo(this, 195, 4, 256, 128);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-18F, 0F, -5F);

		box64 = new ModelRendererTurbo(this, 216, 85, 256, 128);
		box64.addBox(0F, 0F, 0F, 1, 2, 8);
		box64.setPosition(-34F, 26F, -4F);

		box65 = new ModelRendererTurbo(this, 213, 96, 256, 128);
		box65.addBox(0F, 0F, 0F, 2, 0, 8);
		box65.setPosition(-33F, 9F, 4F);
		box65.rotateAngleY = -3.141592653589793F;
		box65.rotateAngleZ = -6.230825429619756F;

		box66 = new ModelRendererTurbo(this, 242, 78, 256, 128);
		box66.addBox(0F, 0F, 0F, 2, 3, 4);
		box66.setPosition(-35F, 6F, -2F);

		box67 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box67.addBox(-2F, -1F, 0F, 1, 4, 5);
		box67.setPosition(-19F, 20F, 9F);
		box67.rotateAngleY = -3.141592653589793F;

		box68 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box68.addBox(-2F, -1F, 0F, 1, 4, 5);
		box68.setPosition(-19F, 20F, 3F);
		box68.rotateAngleY = -3.141592653589793F;

		box69 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box69.addBox(-2F, -1F, 0F, 1, 4, 5);
		box69.setPosition(-8F, 20F, 9F);
		box69.rotateAngleY = -3.141592653589793F;

		box7 = new ModelRendererTurbo(this, 138, 31, 256, 128);
		box7.addBox(0F, 0F, -1F, 54, 0, 4);
		box7.setPosition(-27F, 25F, 7F);
		box7.rotateAngleX = 6.19591884457987F;

		box70 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box70.addBox(-2F, -1F, 0F, 1, 4, 5);
		box70.setPosition(3F, 20F, 9F);
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new ModelRendererTurbo(this, 248, 86, 256, 128);
		box71.addBox(0F, 0F, 0F, 1, 16, 2);
		box71.setPosition(33F, 10F, -5F);

		box72 = new ModelRendererTurbo(this, 248, 86, 256, 128);
		box72.addBox(0F, 0F, 0F, 1, 16, 2);
		box72.setPosition(33F, 10F, 3F);

		box73 = new ModelRendererTurbo(this, 216, 85, 256, 128);
		box73.addBox(0F, 0F, 0F, 1, 2, 8);
		box73.setPosition(33F, 26F, -4F);

		box74 = new ModelRendererTurbo(this, 0, 60, 256, 128);
		box74.addBox(0F, 0F, 0F, 66, 3, 20);
		box74.setPosition(-33F, 6F, -10F);

		box75 = new ModelRendererTurbo(this, 213, 96, 256, 128);
		box75.addBox(0F, 0F, 0F, 2, 0, 8);
		box75.setPosition(33F, 9F, -4F);
		box75.rotateAngleZ = 6.230825429619756F;

		box76 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box76.addBox(-2F, -1F, 0F, 1, 4, 5);
		box76.setPosition(14F, 20F, 9F);
		box76.rotateAngleY = -3.141592653589793F;

		box77 = new ModelRendererTurbo(this, 217, 110, 256, 128);
		box77.addBox(-2F, -1F, 0F, 1, 4, 5);
		box77.setPosition(25F, 20F, 9F);
		box77.rotateAngleY = -3.141592653589793F;

		box78 = new ModelRendererTurbo(this, 242, 78, 256, 128);
		box78.addBox(0F, 0F, 0F, 2, 3, 4);
		box78.setPosition(33F, 6F, -2F);

		box79 = new ModelRendererTurbo(this, 217, 110, 256, 128);
		box79.addBox(-2F, -1F, 0F, 1, 4, 5);
		box79.setPosition(25F, 20F, 3F);
		box79.rotateAngleY = -3.141592653589793F;

		box8 = new ModelRendererTurbo(this, 121, 1, 256, 128);
		box8.addBox(0F, 0F, 0F, 16, 3, 1);
		box8.setPosition(-28F, 3F, 5F);

		box80 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box80.addBox(-2F, -1F, 0F, 1, 4, 5);
		box80.setPosition(14F, 20F, 3F);
		box80.rotateAngleY = -3.141592653589793F;

		box81 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box81.addBox(-2F, -1F, 0F, 1, 4, 5);
		box81.setPosition(3F, 20F, 3F);
		box81.rotateAngleY = -3.141592653589793F;

		box82 = new ModelRendererTurbo(this, 200, 103, 256, 128);
		box82.addBox(-2F, -1F, 0F, 1, 4, 5);
		box82.setPosition(-8F, 20F, 3F);
		box82.rotateAngleY = -3.141592653589793F;

		box83 = new ModelRendererTurbo(this, 1, 27, 256, 128);
		box83.addBox(0F, 0F, -1F, 66, 8, 1);
		box83.setPosition(33F, 24F, -11F);
		box83.rotateAngleX = -0.22689280275926285F;
		box83.rotateAngleY = -3.141592653589793F;

		box84 = new ModelRendererTurbo(this, 121, 1, 256, 128);
		box84.addBox(0F, 0F, 0F, 16, 3, 1);
		box84.setPosition(12F, 3F, 5F);

		box85 = new ModelRendererTurbo(this, 121, 1, 256, 128);
		box85.addBox(0F, 0F, 0F, 16, 3, 1);
		box85.setPosition(12F, 3F, -6F);

		box86 = new ModelRendererTurbo(this, 224, 5, 256, 128);
		box86.addBox(0F, 0F, 0F, 6, 4, 6);
		box86.setPosition(17F, 2F, -3F);

		box87 = new ModelRendererTurbo(this, 224, 5, 256, 128);
		box87.addBox(0F, 0F, 0F, 6, 4, 6);
		box87.setPosition(-23F, 2F, -3F);

		box88 = new ModelRendererTurbo(this, 53, 38, 256, 128);
		box88.addBox(0F, 0F, -2F, 1, 8, 1);
		box88.setPosition(33F, 24F, -11F);
		box88.rotateAngleX = -0.22689280275926285F;
		box88.rotateAngleY = -3.141592653589793F;

		box89 = new ModelRendererTurbo(this, 1, 6, 256, 128);
		box89.addBox(0F, 0F, 0F, 66, 18, 1);
		box89.setPosition(-33F, 6F, 10F);

		box9 = new ModelRendererTurbo(this, 17, 115, 256, 128);
		box9.addBox(0F, -5F, -1F, 4, 5, 1);
		box9.setPosition(29F, 6F, 11F);
		box9.rotateAngleX = -5.951572749300664F;

		box90 = new ModelRendererTurbo(this, 58, 38, 256, 128);
		box90.addBox(0F, 0F, -2F, 1, 8, 1);
		box90.setPosition(-32F, 24F, -11F);
		box90.rotateAngleX = -0.22689280275926285F;
		box90.rotateAngleY = 3.141592653589793F;

		box91 = new ModelRendererTurbo(this, 53, 38, 256, 128);
		box91.addBox(0F, 0F, -2F, 1, 8, 1);
		box91.setPosition(-33F, 24F, 11F);
		box91.rotateAngleX = -0.22689280275926285F;

		box92 = new ModelRendererTurbo(this, 58, 38, 256, 128);
		box92.addBox(0F, 0F, -2F, 1, 8, 1);
		box92.setPosition(32F, 24F, 11F);
		box92.rotateAngleX = -0.22689280275926285F;


	}
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		/*if (ConfigHandler.FLICKERING) {
			super.render(entity, f, f1, f2, f3, f4, f5);
		}*/
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		box90.render(f5);
		box91.render(f5);
		box92.render(f5);


	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
