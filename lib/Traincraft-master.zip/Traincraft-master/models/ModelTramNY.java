package train.client.render.models;

import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelTramNY extends ModelBase {

	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box100;
	public ModelRendererTurbo box101;
	public ModelRendererTurbo box102;
	public ModelRendererTurbo box103;
	public ModelRendererTurbo box104;
	public ModelRendererTurbo box105;
	public ModelRendererTurbo box106;
	public ModelRendererTurbo box107;
	public ModelRendererTurbo box108;
	public ModelRendererTurbo box109;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box110;
	public ModelRendererTurbo box111;
	public ModelRendererTurbo box112;
	public ModelRendererTurbo box113;
	public ModelRendererTurbo box114;
	public ModelRendererTurbo box115;
	public ModelRendererTurbo box116;
	public ModelRendererTurbo box117;
	public ModelRendererTurbo box118;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box80;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box83;
	public ModelRendererTurbo box84;
	public ModelRendererTurbo box85;
	public ModelRendererTurbo box86;
	public ModelRendererTurbo box87;
	public ModelRendererTurbo box88;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;
	public ModelRendererTurbo box90;
	public ModelRendererTurbo box91;
	public ModelRendererTurbo box92;
	public ModelRendererTurbo box93;
	public ModelRendererTurbo box94;
	public ModelRendererTurbo box95;
	public ModelRendererTurbo box96;
	public ModelRendererTurbo box97;
	public ModelRendererTurbo box98;
	public ModelRendererTurbo box99;


	public ModelTramNY() {
		box = new ModelRendererTurbo(this, 59, 14, 256, 256);
		box.addBox(0F, 0F, 0F, 15, 4, 4);
		box.setPosition(-8F, 3F, 5F);

		box0 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box0.addBox(0F, 0F, 0F, 8, 7, 0);
		box0.setPosition(-31F, 0F, 5F);

		box1 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-17F, 0F, 5F);

		box10 = new ModelRendererTurbo(this, 0, 38, 256, 256);
		box10.addBox(0F, -2F, 0F, 68, 2, 1);
		box10.setPosition(-34F, 32F, -4F);

		box100 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box100.addBox(0F, 0F, 0F, 0, 22, 6);
		box100.setPosition(-6F, 8F, -10F);

		box101 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box101.addBox(0F, 0F, 0F, 0, 22, 6);
		box101.setPosition(3F, 8F, -10F);

		box102 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box102.addBox(0F, 0F, 0F, 0, 22, 6);
		box102.setPosition(14F, 8F, -10F);

		box103 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box103.addBox(0F, 0F, 0F, 0, 22, 6);
		box103.setPosition(23F, 8F, -10F);

		box104 = new ModelRendererTurbo(this, 0, 227, 256, 256);
		box104.addBox(0F, 0F, 0F, 0, 22, 6);
		box104.setPosition(-12F, 8F, 4F);

		box105 = new ModelRendererTurbo(this, 0, 227, 256, 256);
		box105.addBox(0F, 0F, 0F, 0, 22, 6);
		box105.setPosition(-1F, 8F, 4F);

		box106 = new ModelRendererTurbo(this, 0, 227, 256, 256);
		box106.addBox(0F, 0F, 0F, 0, 22, 6);
		box106.setPosition(8F, 8F, 4F);

		box107 = new ModelRendererTurbo(this, 0, 227, 256, 256);
		box107.addBox(0F, 0F, 0F, 0, 22, 6);
		box107.setPosition(19F, 8F, 4F);

		box108 = new ModelRendererTurbo(this, 159, 193, 256, 256);
		box108.addBox(0F, 0F, 0F, 0, 11, 5);
		box108.setPosition(-34F, 8F, 5F);
		box108.rotateAngleY = -0.17453292519943295F;

		box109 = new ModelRendererTurbo(this, 173, 193, 256, 256);
		box109.addBox(0F, 0F, 0F, 0, 11, 5);
		box109.setPosition(-34F, 8F, -5F);
		box109.rotateAngleY = -2.9670597283903604F;

		box11 = new ModelRendererTurbo(this, 20, 184, 256, 256);
		box11.addBox(0F, 0F, 0F, 2, 22, 1);
		box11.setPosition(-34F, 8F, 3F);

		box110 = new ModelRendererTurbo(this, 173, 193, 256, 256);
		box110.addBox(0F, 0F, 0F, 0, 11, 5);
		box110.setPosition(34F, 8F, 5F);
		box110.rotateAngleY = -6.1086523819801535F;

		box111 = new ModelRendererTurbo(this, 159, 193, 256, 256);
		box111.addBox(0F, 0F, 0F, 0, 11, 5);
		box111.setPosition(34F, 8F, -5F);
		box111.rotateAngleY = -3.3161255787892263F;

		box112 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box112.addBox(0F, 0F, 0F, 7, 9, 0);
		box112.setPosition(-18F, 17F, -10F);
		box112.rotateAngleX = -0.06981317007977318F;
		box112.rotateAngleY = -3.141592653589793F;

		box113 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box113.addBox(0F, 0F, 0F, 7, 9, 0);
		box113.setPosition(2F, 17F, -10F);
		box113.rotateAngleX = -0.06981317007977318F;
		box113.rotateAngleY = -3.141592653589793F;

		box114 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box114.addBox(0F, 0F, 0F, 7, 9, 0);
		box114.setPosition(22F, 17F, -10F);
		box114.rotateAngleX = -0.06981317007977318F;
		box114.rotateAngleY = -3.141592653589793F;

		box115 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box115.addBox(0F, -9F, 0F, 7, 9, 0);
		box115.setPosition(2F, 17F, -10F);
		box115.rotateAngleX = -6.178465552059927F;
		box115.rotateAngleY = -3.141592653589793F;

		box116 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box116.addBox(0F, -9F, 0F, 7, 9, 0);
		box116.setPosition(22F, 17F, -10F);
		box116.rotateAngleX = -6.178465552059927F;
		box116.rotateAngleY = -3.141592653589793F;

		box117 = new ModelRendererTurbo(this, 45, 208, 256, 256);
		box117.addBox(0F, 0F, 0F, 1, 8, 1);
		box117.setPosition(-34F, 18F, -5F);

		box118 = new ModelRendererTurbo(this, 20, 208, 256, 256);
		box118.addBox(0F, 0F, 0F, 1, 8, 1);
		box118.setPosition(-34F, 18F, 4F);

		box12 = new ModelRendererTurbo(this, 3, 193, 256, 256);
		box12.addBox(0F, 0F, 0F, 1, 10, 6);
		box12.setPosition(-34F, 8F, 4F);

		box13 = new ModelRendererTurbo(this, 54, 193, 256, 256);
		box13.addBox(0F, 0F, 0F, 1, 10, 6);
		box13.setPosition(-34F, 8F, -10F);

		box14 = new ModelRendererTurbo(this, 45, 184, 256, 256);
		box14.addBox(0F, 0F, 0F, 2, 22, 1);
		box14.setPosition(-34F, 8F, -4F);

		box15 = new ModelRendererTurbo(this, 3, 180, 256, 256);
		box15.addBox(0F, 0F, 0F, 1, 4, 6);
		box15.setPosition(-34F, 26F, 4F);

		box16 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-31F, 0F, -5F);

		box17 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 2, 12);
		box17.setPosition(-28F, 2F, -6F);

		box18 = new ModelRendererTurbo(this, 55, 180, 256, 256);
		box18.addBox(0F, 0F, 0F, 1, 4, 6);
		box18.setPosition(-34F, 26F, -10F);

		box19 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(23F, 0F, -5F);

		box2 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 12);
		box2.setPosition(12F, 2F, -6F);

		box20 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 12);
		box20.setPosition(26F, 2F, -6F);

		box21 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(23F, 0F, 5F);

		box22 = new ModelRendererTurbo(this, 127, 144, 256, 256);
		box22.addBox(0F, 0F, -1F, 13, 1, 1);
		box22.setPosition(-13F, 17F, 11F);
		box22.rotateAngleX = -0.06981317007977318F;

		box23 = new ModelRendererTurbo(this, 150, 133, 256, 256);
		box23.addBox(0F, 1F, -1F, 3, 8, 1);
		box23.setPosition(-13F, 17F, 11F);
		box23.rotateAngleX = -0.06981317007977318F;

		box24 = new ModelRendererTurbo(this, 33, 226, 256, 256);
		box24.addBox(0F, 0F, 0F, 1, 22, 7);
		box24.setPosition(-27F, 8F, 3F);

		box25 = new ModelRendererTurbo(this, 0, 1, 256, 256);
		box25.addBox(0F, 0F, 0F, 6, 4, 14);
		box25.setPosition(-23F, 2F, -7F);

		box26 = new ModelRendererTurbo(this, 50, 231, 256, 256);
		box26.addBox(0F, 0F, 0F, 5, 22, 0);
		box26.setPosition(-32F, 8F, 3F);

		box27 = new ModelRendererTurbo(this, 140, 133, 256, 256);
		box27.addBox(0F, 1F, -1F, 3, 8, 1);
		box27.setPosition(-3F, 17F, 11F);
		box27.rotateAngleX = -0.06981317007977318F;

		box28 = new ModelRendererTurbo(this, 70, 25, 256, 256);
		box28.addBox(0F, 0F, 0F, 10, 4, 7);
		box28.setPosition(-2F, 3F, -9F);

		box29 = new ModelRendererTurbo(this, 150, 133, 256, 256);
		box29.addBox(0F, 1F, -1F, 3, 8, 1);
		box29.setPosition(7F, 17F, 11F);
		box29.rotateAngleX = -0.06981317007977318F;

		box3 = new ModelRendererTurbo(this, 4, 169, 256, 256);
		box3.addBox(0F, 0F, 0F, 4, 4, 6);
		box3.setPosition(-33F, 27F, -3F);

		box30 = new ModelRendererTurbo(this, 127, 144, 256, 256);
		box30.addBox(0F, 0F, -1F, 13, 1, 1);
		box30.setPosition(7F, 17F, 11F);
		box30.rotateAngleX = -0.06981317007977318F;

		box31 = new ModelRendererTurbo(this, 140, 133, 256, 256);
		box31.addBox(0F, 1F, -1F, 3, 8, 1);
		box31.setPosition(17F, 17F, 11F);
		box31.rotateAngleX = -0.06981317007977318F;

		box32 = new ModelRendererTurbo(this, 122, 133, 256, 256);
		box32.addBox(0F, 1F, -1F, 7, 8, 1);
		box32.setPosition(27F, 17F, 11F);
		box32.rotateAngleX = -0.06981317007977318F;

		box33 = new ModelRendererTurbo(this, 0, 89, 256, 256);
		box33.addBox(0F, 0F, 0F, 2, 2, 10);
		box33.setPosition(33F, 7F, -5F);

		box34 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box34.addBox(0F, -9F, 0F, 7, 9, 0);
		box34.setPosition(20F, 17F, 10F);
		box34.rotateAngleX = -6.178465552059927F;

		box35 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(9F, 0F, 5F);

		box36 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box36.addBox(0F, 0F, 0F, 7, 9, 0);
		box36.setPosition(20F, 17F, 10F);
		box36.rotateAngleX = -0.06981317007977318F;

		box37 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box37.addBox(0F, 0F, 0F, 7, 9, 0);
		box37.setPosition(0F, 17F, 10F);
		box37.rotateAngleX = -0.06981317007977318F;

		box38 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box38.addBox(0F, -9F, 0F, 7, 9, 0);
		box38.setPosition(0F, 17F, 10F);
		box38.rotateAngleX = -6.178465552059927F;

		box39 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box39.addBox(0F, -9F, 0F, 7, 9, 0);
		box39.setPosition(-20F, 17F, 10F);
		box39.rotateAngleX = -6.178465552059927F;

		box4 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box4.addBox(0F, 0F, 0F, 2, 2, 12);
		box4.setPosition(-14F, 2F, -6F);

		box40 = new ModelRendererTurbo(this, 34, 133, 256, 256);
		box40.addBox(0F, -9F, -1F, 13, 9, 1);
		box40.setPosition(-13F, 17F, 11F);
		box40.rotateAngleX = -6.178465552059927F;

		box41 = new ModelRendererTurbo(this, 34, 133, 256, 256);
		box41.addBox(0F, -9F, -1F, 13, 9, 1);
		box41.setPosition(7F, 17F, 11F);
		box41.rotateAngleX = -6.178465552059927F;

		box42 = new ModelRendererTurbo(this, 16, 133, 256, 256);
		box42.addBox(0F, -9F, -1F, 7, 9, 1);
		box42.setPosition(27F, 17F, 11F);
		box42.rotateAngleX = -6.178465552059927F;

		box43 = new ModelRendererTurbo(this, 109, 144, 256, 256);
		box43.addBox(0F, 0F, -1F, 7, 1, 1);
		box43.setPosition(27F, 17F, 11F);
		box43.rotateAngleX = -0.06981317007977318F;

		box44 = new ModelRendererTurbo(this, 48, 127, 256, 256);
		box44.addBox(0F, 9F, -1F, 68, 3, 1);
		box44.setPosition(-34F, 17F, 11F);
		box44.rotateAngleX = -0.06981317007977318F;

		box45 = new ModelRendererTurbo(this, 180, 133, 256, 256);
		box45.addBox(0F, 1F, -1F, 2, 8, 1);
		box45.setPosition(-34F, 17F, 11F);
		box45.rotateAngleX = -0.06981317007977318F;

		box46 = new ModelRendererTurbo(this, 160, 133, 256, 256);
		box46.addBox(0F, 1F, -1F, 8, 8, 1);
		box46.setPosition(-28F, 17F, 11F);
		box46.rotateAngleX = -0.06981317007977318F;

		box47 = new ModelRendererTurbo(this, 81, 186, 256, 256);
		box47.addBox(0F, 0F, 0F, 7, 9, 0);
		box47.setPosition(-20F, 17F, 10F);
		box47.rotateAngleX = -0.06981317007977318F;

		box48 = new ModelRendererTurbo(this, 121, 186, 256, 256);
		box48.addBox(0F, 0F, 0F, 2, 22, 1);
		box48.setPosition(32F, 8F, -4F);

		box49 = new ModelRendererTurbo(this, 129, 186, 256, 256);
		box49.addBox(0F, 0F, 0F, 2, 22, 1);
		box49.setPosition(32F, 8F, 3F);

		box5 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(9F, 0F, -5F);

		box50 = new ModelRendererTurbo(this, 29, 181, 256, 256);
		box50.addBox(0F, 0F, 0F, 0, 18, 6);
		box50.setPosition(32F, 9F, 3F);
		box50.rotateAngleY = -3.141592653589793F;

		box51 = new ModelRendererTurbo(this, 119, 176, 256, 256);
		box51.addBox(0F, 0F, 0F, 2, 3, 6);
		box51.setPosition(32F, 27F, -3F);

		box52 = new ModelRendererTurbo(this, 137, 181, 256, 256);
		box52.addBox(0F, 0F, 0F, 1, 22, 6);
		box52.setPosition(33F, 8F, 4F);

		box53 = new ModelRendererTurbo(this, 105, 181, 256, 256);
		box53.addBox(0F, 0F, 0F, 1, 22, 6);
		box53.setPosition(33F, 8F, -10F);

		box54 = new ModelRendererTurbo(this, 64, 145, 256, 256);
		box54.addBox(0F, -9F, -1F, 9, 9, 1);
		box54.setPosition(-25F, 17F, -11F);
		box54.rotateAngleX = -6.178465552059927F;
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new ModelRendererTurbo(this, 90, 164, 256, 256);
		box55.addBox(0F, 0F, -1F, 12, 1, 1);
		box55.setPosition(34F, 17F, -11F);
		box55.rotateAngleX = -0.06981317007977318F;
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new ModelRendererTurbo(this, 146, 164, 256, 256);
		box56.addBox(0F, 0F, -1F, 9, 1, 1);
		box56.setPosition(-25F, 17F, -11F);
		box56.rotateAngleX = -0.06981317007977318F;
		box56.rotateAngleY = -3.141592653589793F;

		box57 = new ModelRendererTurbo(this, 81, 199, 256, 256);
		box57.addBox(0F, -9F, 0F, 7, 9, 0);
		box57.setPosition(-18F, 17F, -10F);
		box57.rotateAngleX = -6.178465552059927F;
		box57.rotateAngleY = -3.141592653589793F;

		box58 = new ModelRendererTurbo(this, 48, 168, 256, 256);
		box58.addBox(0F, 9F, -1F, 68, 3, 1);
		box58.setPosition(34F, 17F, -11F);
		box58.rotateAngleX = -0.06981317007977318F;
		box58.rotateAngleY = -3.141592653589793F;

		box59 = new ModelRendererTurbo(this, 134, 152, 256, 256);
		box59.addBox(0F, 1F, -1F, 2, 8, 1);
		box59.setPosition(-32F, 17F, -11F);
		box59.rotateAngleX = -0.06981317007977318F;
		box59.rotateAngleY = -3.141592653589793F;

		box6 = new ModelRendererTurbo(this, 3, 27, 256, 256);
		box6.addBox(0F, 0F, 0F, 18, 4, 6);
		box6.setPosition(-29F, 3F, -3F);

		box60 = new ModelRendererTurbo(this, 124, 152, 256, 256);
		box60.addBox(0F, 1F, -1F, 3, 8, 1);
		box60.setPosition(-25F, 17F, -11F);
		box60.rotateAngleX = -0.06981317007977318F;
		box60.rotateAngleY = -3.141592653589793F;

		box61 = new ModelRendererTurbo(this, 34, 145, 256, 256);
		box61.addBox(0F, -9F, -1F, 13, 9, 1);
		box61.setPosition(-5F, 17F, -11F);
		box61.rotateAngleX = -6.178465552059927F;
		box61.rotateAngleY = -3.141592653589793F;

		box62 = new ModelRendererTurbo(this, 0, 1, 256, 256);
		box62.addBox(0F, 0F, 0F, 6, 4, 14);
		box62.setPosition(17F, 2F, -7F);

		box63 = new ModelRendererTurbo(this, 188, 11, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-17F, 0F, -5F);

		box64 = new ModelRendererTurbo(this, 29, 181, 256, 256);
		box64.addBox(0F, 0F, 0F, 0, 18, 6);
		box64.setPosition(-32F, 9F, -3F);

		box65 = new ModelRendererTurbo(this, 0, 89, 256, 256);
		box65.addBox(0F, 0F, 0F, 2, 2, 10);
		box65.setPosition(-35F, 7F, -5F);

		box66 = new ModelRendererTurbo(this, 65, 247, 256, 256);
		box66.addBox(0F, 0F, 0F, 72, 3, 4);
		box66.setPosition(-36F, 4F, -2F);

		box67 = new ModelRendererTurbo(this, 34, 145, 256, 256);
		box67.addBox(0F, -9F, -1F, 13, 9, 1);
		box67.setPosition(15F, 17F, -11F);
		box67.rotateAngleX = -6.178465552059927F;
		box67.rotateAngleY = -3.141592653589793F;

		box68 = new ModelRendererTurbo(this, 5, 145, 256, 256);
		box68.addBox(0F, -9F, -1F, 12, 9, 1);
		box68.setPosition(34F, 17F, -11F);
		box68.rotateAngleX = -6.178465552059927F;
		box68.rotateAngleY = -3.141592653589793F;

		box69 = new ModelRendererTurbo(this, 0, 46, 256, 256);
		box69.addBox(0F, -2F, 0F, 63, 2, 6);
		box69.setPosition(-29F, 32F, -3F);

		box7 = new ModelRendererTurbo(this, 157, 144, 256, 256);
		box7.addBox(0F, 0F, -1F, 14, 1, 1);
		box7.setPosition(-34F, 17F, 11F);
		box7.rotateAngleX = -0.06981317007977318F;

		box70 = new ModelRendererTurbo(this, 117, 164, 256, 256);
		box70.addBox(0F, 0F, -1F, 13, 1, 1);
		box70.setPosition(15F, 17F, -11F);
		box70.rotateAngleX = -0.06981317007977318F;
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new ModelRendererTurbo(this, 117, 164, 256, 256);
		box71.addBox(0F, 0F, -1F, 13, 1, 1);
		box71.setPosition(-5F, 17F, -11F);
		box71.rotateAngleX = -0.06981317007977318F;
		box71.rotateAngleY = -3.141592653589793F;

		box72 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box72.addBox(0F, -2F, 0F, 68, 2, 7);
		box72.setPosition(-34F, 32F, 4F);
		box72.rotateAngleX = -5.82939970166106F;

		box73 = new ModelRendererTurbo(this, 114, 152, 256, 256);
		box73.addBox(0F, 1F, -1F, 3, 8, 1);
		box73.setPosition(-15F, 17F, -11F);
		box73.rotateAngleX = -0.06981317007977318F;
		box73.rotateAngleY = -3.141592653589793F;

		box74 = new ModelRendererTurbo(this, 0, 65, 256, 256);
		box74.addBox(0F, 0F, 0F, 66, 2, 20);
		box74.setPosition(-33F, 7F, -10F);

		box75 = new ModelRendererTurbo(this, 124, 152, 256, 256);
		box75.addBox(0F, 1F, -1F, 3, 8, 1);
		box75.setPosition(-5F, 17F, -11F);
		box75.rotateAngleX = -0.06981317007977318F;
		box75.rotateAngleY = -3.141592653589793F;

		box76 = new ModelRendererTurbo(this, 114, 152, 256, 256);
		box76.addBox(0F, 1F, -1F, 3, 8, 1);
		box76.setPosition(5F, 17F, -11F);
		box76.rotateAngleX = -0.06981317007977318F;
		box76.rotateAngleY = -3.141592653589793F;

		box77 = new ModelRendererTurbo(this, 124, 152, 256, 256);
		box77.addBox(0F, 1F, -1F, 3, 8, 1);
		box77.setPosition(15F, 17F, -11F);
		box77.rotateAngleX = -0.06981317007977318F;
		box77.rotateAngleY = -3.141592653589793F;

		box78 = new ModelRendererTurbo(this, 3, 27, 256, 256);
		box78.addBox(0F, 0F, 0F, 18, 4, 6);
		box78.setPosition(11F, 3F, -3F);

		box79 = new ModelRendererTurbo(this, 90, 152, 256, 256);
		box79.addBox(0F, 1F, -1F, 2, 8, 1);
		box79.setPosition(34F, 17F, -11F);
		box79.rotateAngleX = -0.06981317007977318F;
		box79.rotateAngleY = -3.141592653589793F;

		box8 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box8.addBox(0F, -2F, 0F, 68, 2, 7);
		box8.setPosition(34F, 32F, -4F);
		box8.rotateAngleX = -5.846852994181004F;
		box8.rotateAngleY = -3.141592653589793F;

		box80 = new ModelRendererTurbo(this, 98, 152, 256, 256);
		box80.addBox(0F, 1F, -1F, 6, 8, 1);
		box80.setPosition(28F, 17F, -11F);
		box80.rotateAngleX = -0.06981317007977318F;
		box80.rotateAngleY = -3.141592653589793F;

		box81 = new ModelRendererTurbo(this, 84, 223, 256, 256);
		box81.addBox(0F, 0F, -5F, 11, 2, 5);
		box81.setPosition(-6F, 11F, -10F);
		box81.rotateAngleX = -6.213372137099813F;
		box81.rotateAngleY = -3.141592653589793F;

		box82 = new ModelRendererTurbo(this, 84, 216, 256, 256);
		box82.addBox(0F, 3F, 1F, 11, 5, 1);
		box82.setPosition(-6F, 10F, -7F);
		box82.rotateAngleX = -6.09119908946021F;
		box82.rotateAngleY = -3.141592653589793F;

		box83 = new ModelRendererTurbo(this, 84, 223, 256, 256);
		box83.addBox(0F, 0F, -5F, 11, 2, 5);
		box83.setPosition(8F, 11F, 10F);
		box83.rotateAngleX = -6.213372137099813F;

		box84 = new ModelRendererTurbo(this, 84, 216, 256, 256);
		box84.addBox(0F, 3F, 1F, 11, 5, 1);
		box84.setPosition(14F, 10F, -7F);
		box84.rotateAngleX = -6.09119908946021F;
		box84.rotateAngleY = -3.141592653589793F;

		box85 = new ModelRendererTurbo(this, 118, 216, 256, 256);
		box85.addBox(0F, 3F, 1F, 6, 5, 1);
		box85.setPosition(-26F, 10F, -7F);
		box85.rotateAngleX = -6.09119908946021F;
		box85.rotateAngleY = -3.141592653589793F;

		box86 = new ModelRendererTurbo(this, 118, 223, 256, 256);
		box86.addBox(0F, 0F, -5F, 6, 2, 5);
		box86.setPosition(-26F, 11F, -10F);
		box86.rotateAngleX = -6.213372137099813F;
		box86.rotateAngleY = -3.141592653589793F;

		box87 = new ModelRendererTurbo(this, 142, 223, 256, 256);
		box87.addBox(0F, 0F, -5F, 5, 2, 5);
		box87.setPosition(28F, 11F, -10F);
		box87.rotateAngleX = -6.213372137099813F;
		box87.rotateAngleY = -3.141592653589793F;

		box88 = new ModelRendererTurbo(this, 143, 216, 256, 256);
		box88.addBox(0F, 3F, 1F, 5, 5, 1);
		box88.setPosition(28F, 10F, -7F);
		box88.rotateAngleX = -6.09119908946021F;
		box88.rotateAngleY = -3.141592653589793F;

		box89 = new ModelRendererTurbo(this, 84, 216, 256, 256);
		box89.addBox(0F, 3F, 1F, 11, 5, 1);
		box89.setPosition(8F, 10F, 7F);
		box89.rotateAngleX = -6.09119908946021F;

		box9 = new ModelRendererTurbo(this, 0, 42, 256, 256);
		box9.addBox(0F, -2F, 0F, 68, 2, 1);
		box9.setPosition(-34F, 32F, 3F);

		box90 = new ModelRendererTurbo(this, 64, 133, 256, 256);
		box90.addBox(0F, -9F, -1F, 14, 9, 1);
		box90.setPosition(-34F, 17F, 11F);
		box90.rotateAngleX = -6.178465552059927F;

		box91 = new ModelRendererTurbo(this, 84, 223, 256, 256);
		box91.addBox(0F, 0F, -5F, 11, 2, 5);
		box91.setPosition(14F, 11F, -10F);
		box91.rotateAngleX = -6.213372137099813F;
		box91.rotateAngleY = -3.141592653589793F;

		box92 = new ModelRendererTurbo(this, 84, 223, 256, 256);
		box92.addBox(0F, 0F, -5F, 11, 2, 5);
		box92.setPosition(-12F, 11F, 10F);
		box92.rotateAngleX = -6.213372137099813F;

		box93 = new ModelRendererTurbo(this, 84, 216, 256, 256);
		box93.addBox(0F, 3F, 1F, 11, 5, 1);
		box93.setPosition(-12F, 10F, 7F);
		box93.rotateAngleX = -6.09119908946021F;

		box94 = new ModelRendererTurbo(this, 143, 216, 256, 256);
		box94.addBox(0F, 3F, 1F, 5, 5, 1);
		box94.setPosition(-26F, 10F, 7F);
		box94.rotateAngleX = -6.09119908946021F;

		box95 = new ModelRendererTurbo(this, 142, 223, 256, 256);
		box95.addBox(0F, 0F, -5F, 5, 2, 5);
		box95.setPosition(-26F, 11F, 10F);
		box95.rotateAngleX = -6.213372137099813F;

		box96 = new ModelRendererTurbo(this, 64, 233, 256, 256);
		box96.addBox(0F, 0F, 0F, 2, 2, 6);
		box96.setPosition(-33F, 15F, 4F);

		box97 = new ModelRendererTurbo(this, 0, 227, 256, 256);
		box97.addBox(0F, 0F, 0F, 0, 22, 6);
		box97.setPosition(-21F, 8F, 4F);

		box98 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box98.addBox(0F, 0F, 0F, 0, 22, 6);
		box98.setPosition(-26F, 8F, -10F);

		box99 = new ModelRendererTurbo(this, 17, 227, 256, 256);
		box99.addBox(0F, 0F, 0F, 0, 22, 6);
		box99.setPosition(-17F, 8F, -10F);

	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		/*if (ConfigHandler.FLICKERING) {
			super.render(entity, f, f1, f2, f3, f4, f5);
		}*/
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box100.render(f5);
		box101.render(f5);
		box102.render(f5);
		box103.render(f5);
		box104.render(f5);
		box105.render(f5);
		box106.render(f5);
		box107.render(f5);
		box108.render(f5);
		box109.render(f5);
		box11.render(f5);
		box110.render(f5);
		box111.render(f5);
		box112.render(f5);
		box113.render(f5);
		box114.render(f5);
		box115.render(f5);
		box116.render(f5);
		box117.render(f5);
		box118.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		box90.render(f5);
		box91.render(f5);
		box92.render(f5);
		box93.render(f5);
		box94.render(f5);
		box95.render(f5);
		box96.render(f5);
		box97.render(f5);
		box98.render(f5);
		box99.render(f5);

	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
