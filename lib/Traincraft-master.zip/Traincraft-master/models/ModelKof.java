package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelKof extends ModelBase {
	
	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box9;

	public ModelKof() {
		box = new ModelRendererTurbo(this, 0, 65, 256, 128);
		box.addBox(0F, 0F, 0F, 19, 1, 18);
		box.setPosition(5F, 2F, -9F);

		box0 = new ModelRendererTurbo(this, 156, 72, 256, 128);
		box0.addBox(0F, 0F, 0F, 19, 1, 4);
		box0.setPosition(-14F, 3F, 6F);

		box1 = new ModelRendererTurbo(this, 213, 94, 256, 128);
		box1.addBox(0F, 0F, 0F, 1, 12, 20);
		box1.setPosition(5F, 3F, -10F);

		box10 = new ModelRendererTurbo(this, 2, 37, 256, 128);
		box10.addBox(0F, -1F, 0F, 20, 1, 7);
		box10.setPosition(24F, 25F, -3F);
		box10.rotateAngleX = -6.14355896702004F;
		box10.rotateAngleY = -3.141592653589793F;

		box11 = new ModelRendererTurbo(this, 152, 35, 256, 128);
		box11.addBox(0F, 0F, 0F, 2, 3, 4);
		box11.setPosition(24F, 6F, -2F);

		box12 = new ModelRendererTurbo(this, 183, 40, 256, 128);
		box12.addBox(0F, 0F, 0F, 1, 2, 20);
		box12.setPosition(5F, 22F, -10F);

		box13 = new ModelRendererTurbo(this, 3, 29, 256, 128);
		box13.addBox(0F, 0F, 0F, 20, 1, 6);
		box13.setPosition(4F, 24F, -3F);

		box14 = new ModelRendererTurbo(this, 159, 85, 256, 128);
		box14.addBox(0F, 0F, 0F, 4, 9, 1);
		box14.setPosition(5F, 14F, 10F);

		box15 = new ModelRendererTurbo(this, 0, 0, 256, 128);
		box15.addBox(0F, 0F, 0F, 24, 20, 8);
		box15.setPosition(-19F, 2F, -4F);

		box16 = new ModelRendererTurbo(this, 210, 79, 256, 128);
		box16.addBox(0F, 0F, 0F, 1, 7, 10);
		box16.setPosition(5F, 15F, -5F);

		box17 = new ModelRendererTurbo(this, 135, 98, 256, 128);
		box17.addBox(0F, 0F, 0F, 11, 10, 1);
		box17.setPosition(5F, 4F, 10F);

		box18 = new ModelRendererTurbo(this, 240, 83, 256, 128);
		box18.addBox(0F, 0F, 0F, 2, 19, 1);
		box18.setPosition(21F, 4F, -11F);

		box19 = new ModelRendererTurbo(this, 171, 85, 256, 128);
		box19.addBox(0F, 0F, 0F, 4, 9, 1);
		box19.setPosition(5F, 14F, -11F);

		box2 = new ModelRendererTurbo(this, 185, 22, 256, 128);
		box2.addBox(0F, 0F, 0F, 1, 1, 10);
		box2.setPosition(10F, 15F, -5F);

		box20 = new ModelRendererTurbo(this, 193, 112, 256, 128);
		box20.addBox(0F, 0F, 0F, 1, 1, 3);
		box20.setPosition(-19F, 4F, 11F);
		box20.rotateAngleX = -5.497787143782138F;
		box20.rotateAngleY = -3.141592653589793F;

		box21 = new ModelRendererTurbo(this, 58, 112, 256, 128);
		box21.addBox(0F, 0F, 0F, 1, 1, 3);
		box21.setPosition(-20F, 4F, -11F);
		box21.rotateAngleX = -5.497787143782138F;

		box22 = new ModelRendererTurbo(this, 187, 78, 256, 128);
		box22.addBox(0F, 0F, 0F, 1, 12, 20);
		box22.setPosition(22F, 3F, -10F);

		box23 = new ModelRendererTurbo(this, 184, 79, 256, 128);
		box23.addBox(0F, 0F, 0F, 1, 7, 10);
		box23.setPosition(22F, 15F, -5F);

		box24 = new ModelRendererTurbo(this, 163, 112, 256, 128);
		box24.addBox(0F, 0F, 0F, 11, 1, 3);
		box24.setPosition(16F, 4F, 11F);
		box24.rotateAngleX = -5.497787143782138F;
		box24.rotateAngleY = -3.141592653589793F;

		box25 = new ModelRendererTurbo(this, 141, 61, 256, 128);
		box25.addBox(0F, 0F, 0F, 1, 3, 3);
		box25.setPosition(24F, 7F, -7F);

		box26 = new ModelRendererTurbo(this, 247, 83, 256, 128);
		box26.addBox(0F, 0F, 0F, 2, 19, 1);
		box26.setPosition(21F, 4F, 10F);

		box27 = new ModelRendererTurbo(this, 117, 2, 256, 128);
		box27.addBox(0F, 0F, 0F, 5, 3, 18);
		box27.setPosition(-19F, 3F, -9F);

		box28 = new ModelRendererTurbo(this, 159, 43, 256, 128);
		box28.addBox(0F, 0F, 0F, 1, 2, 20);
		box28.setPosition(22F, 22F, -10F);

		box29 = new ModelRendererTurbo(this, 116, 5, 256, 128);
		box29.addBox(0F, 0F, 0F, 5, 5, 4);
		box29.setPosition(-19F, 6F, -10F);

		box3 = new ModelRendererTurbo(this, 209, 25, 256, 128);
		box3.addBox(0F, 0F, 0F, 1, 7, 22);
		box3.setPosition(-20F, 4F, -11F);

		box30 = new ModelRendererTurbo(this, 68, 112, 256, 128);
		box30.addBox(0F, 0F, 0F, 11, 1, 3);
		box30.setPosition(5F, 4F, -11F);
		box30.rotateAngleX = -5.497787143782138F;

		box31 = new ModelRendererTurbo(this, 113, 112, 256, 128);
		box31.addBox(16F, 0F, 0F, 3, 1, 3);
		box31.setPosition(5F, 4F, -11F);
		box31.rotateAngleX = -5.497787143782138F;

		box32 = new ModelRendererTurbo(this, 99, 114, 256, 128);
		box32.addBox(0F, 0F, 2F, 5, 1, 1);
		box32.setPosition(16F, 4F, -11F);
		box32.rotateAngleX = -5.497787143782138F;

		box33 = new ModelRendererTurbo(this, 134, 112, 256, 128);
		box33.addBox(0F, 0F, 0F, 3, 1, 3);
		box33.setPosition(24F, 4F, 11F);
		box33.rotateAngleX = -5.497787143782138F;
		box33.rotateAngleY = -3.141592653589793F;

		box34 = new ModelRendererTurbo(this, 149, 114, 256, 128);
		box34.addBox(0F, 0F, 2F, 5, 1, 1);
		box34.setPosition(21F, 4F, 11F);
		box34.rotateAngleX = -5.497787143782138F;
		box34.rotateAngleY = -3.141592653589793F;

		box35 = new ModelRendererTurbo(this, 116, 5, 256, 128);
		box35.addBox(0F, 0F, 0F, 5, 5, 4);
		box35.setPosition(-19F, 6F, 6F);

		box36 = new ModelRendererTurbo(this, 184, 2, 256, 128);
		box36.addBox(0F, 0F, 0F, 6, 10, 8);
		box36.setPosition(6F, 11F, -4F);

		box37 = new ModelRendererTurbo(this, 211, 55, 256, 128);
		box37.addBox(0F, 0F, 0F, 1, 1, 20);
		box37.setPosition(23F, 3F, -10F);

		box38 = new ModelRendererTurbo(this, 141, 61, 256, 128);
		box38.addBox(0F, 0F, 0F, 1, 3, 3);
		box38.setPosition(24F, 7F, 4F);

		box39 = new ModelRendererTurbo(this, 58, 61, 256, 128);
		box39.addBox(0F, 0F, 0F, 7, 2, 14);
		box39.setPosition(-13F, 5F, -7F);

		box4 = new ModelRendererTurbo(this, 211, 55, 256, 128);
		box4.addBox(0F, 0F, 0F, 1, 1, 20);
		box4.setPosition(-20F, 3F, -10F);

		box40 = new ModelRendererTurbo(this, 141, 61, 256, 128);
		box40.addBox(0F, 0F, 0F, 1, 3, 3);
		box40.setPosition(-21F, 7F, -7F);

		box41 = new ModelRendererTurbo(this, 54, 20, 256, 128);
		box41.addBox(0F, 0F, 0F, 24, 1, 12);
		box41.setPosition(-19F, 10F, -6F);

		box42 = new ModelRendererTurbo(this, 141, 61, 256, 128);
		box42.addBox(0F, 0F, 0F, 1, 3, 3);
		box42.setPosition(-21F, 7F, 4F);

		box43 = new ModelRendererTurbo(this, 161, 55, 256, 128);
		box43.addBox(0F, 0F, 0F, 0, 3, 2);
		box43.setPosition(-19F, 11F, -9F);

		box44 = new ModelRendererTurbo(this, 152, 35, 256, 128);
		box44.addBox(0F, 0F, 0F, 2, 3, 4);
		box44.setPosition(-22F, 6F, -2F);

		box45 = new ModelRendererTurbo(this, 161, 55, 256, 128);
		box45.addBox(0F, 0F, 0F, 0, 3, 2);
		box45.setPosition(-19F, 11F, 7F);

		box46 = new ModelRendererTurbo(this, 161, 44, 256, 128);
		box46.addBox(0F, 0F, 0F, 1, 2, 2);
		box46.setPosition(23F, 12F, 7F);

		box47 = new ModelRendererTurbo(this, 161, 44, 256, 128);
		box47.addBox(0F, 0F, 0F, 1, 2, 2);
		box47.setPosition(23F, 12F, -9F);

		box48 = new ModelRendererTurbo(this, 161, 44, 256, 128);
		box48.addBox(0F, 0F, 0F, 1, 2, 2);
		box48.setPosition(23F, 21F, -1F);

		box49 = new ModelRendererTurbo(this, 154, 55, 256, 128);
		box49.addBox(0F, 0F, 0F, 1, 2, 2);
		box49.setPosition(-16F, 23F, -1F);

		box5 = new ModelRendererTurbo(this, 213, 57, 256, 128);
		box5.addBox(0F, 0F, 0F, 1, 1, 18);
		box5.setPosition(-20F, 2F, -9F);

		box50 = new ModelRendererTurbo(this, 108, 24, 256, 128);
		box50.addBox(0F, 0F, 0F, 1, 7, 22);
		box50.setPosition(23F, 4F, -11F);

		box51 = new ModelRendererTurbo(this, 161, 55, 256, 128);
		box51.addBox(0F, 0F, 0F, 0, 3, 2);
		box51.setPosition(-15F, 22F, -1F);

		box52 = new ModelRendererTurbo(this, 94, 3, 256, 128);
		box52.addBox(0F, 0F, 0F, 0, 2, 8);
		box52.setPosition(-1F, 22F, -4F);

		box53 = new ModelRendererTurbo(this, 94, 3, 256, 128);
		box53.addBox(0F, 0F, 0F, 0, 2, 8);
		box53.setPosition(3F, 22F, -4F);

		box54 = new ModelRendererTurbo(this, 20, 53, 256, 128);
		box54.addBox(0F, 0F, 0F, 3, 1, 1);
		box54.setPosition(14F, 26F, 0F);
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new ModelRendererTurbo(this, 0, 100, 256, 128);
		box55.addBox(0F, 0F, 0F, 25, 9, 1);
		box55.setPosition(-19F, 1F, 5F);

		box56 = new ModelRendererTurbo(this, 215, 1, 256, 128);
		box56.addBox(0F, 0F, 0F, 8, 10, 12);
		box56.setPosition(6F, 1F, -6F);

		box57 = new ModelRendererTurbo(this, 90, 81, 256, 128);
		box57.addBox(0F, 0F, 0F, 9, 8, 10);
		box57.setPosition(-14F, 0F, -5F);

		box58 = new ModelRendererTurbo(this, 90, 81, 256, 128);
		box58.addBox(0F, 0F, 0F, 9, 8, 10);
		box58.setPosition(5F, 0F, -5F);

		box59 = new ModelRendererTurbo(this, 1, 94, 256, 128);
		box59.addBox(0F, 0F, 0F, 0, 10, 20);
		box59.setPosition(-10F, 4F, -10F);

		box6 = new ModelRendererTurbo(this, 2, 37, 256, 128);
		box6.addBox(0F, -1F, 0F, 20, 1, 7);
		box6.setPosition(4F, 25F, 3F);
		box6.rotateAngleX = -6.14355896702004F;

		box60 = new ModelRendererTurbo(this, 210, 3, 256, 128);
		box60.addBox(0F, 0F, 0F, 7, 7, 0);
		box60.setPosition(7F, 12F, -5F);

		box61 = new ModelRendererTurbo(this, 210, 3, 256, 128);
		box61.addBox(0F, 0F, 0F, 7, 7, 0);
		box61.setPosition(7F, 12F, 5F);

		box62 = new ModelRendererTurbo(this, 151, 85, 256, 128);
		box62.addBox(0F, 0F, 0F, 1, 9, 0);
		box62.setPosition(14F, 14F, 11F);

		box63 = new ModelRendererTurbo(this, 20, 56, 256, 128);
		box63.addBox(0F, 0F, 0F, 3, 1, 1);
		box63.setPosition(14F, 26F, 0F);

		box64 = new ModelRendererTurbo(this, 9, 54, 256, 128);
		box64.addBox(-1F, 0F, -1F, 2, 2, 2);
		box64.setPosition(14F, 25F, 0F);
		box64.rotateAngleY = -0.7853981633974483F;

		box65 = new ModelRendererTurbo(this, 151, 85, 256, 128);
		box65.addBox(0F, 0F, 0F, 1, 9, 0);
		box65.setPosition(14F, 14F, -11F);

		box66 = new ModelRendererTurbo(this, 58, 89, 256, 128);
		box66.addBox(0F, 0F, 0F, 7, 4, 14);
		box66.setPosition(6F, 3F, -7F);

		box67 = new ModelRendererTurbo(this, 161, 98, 256, 128);
		box67.addBox(0F, 0F, 0F, 11, 10, 1);
		box67.setPosition(5F, 4F, -11F);

		box68 = new ModelRendererTurbo(this, 88, 55, 256, 128);
		box68.addBox(0F, 0F, 0F, 3, 3, 14);
		box68.setPosition(-11F, 2F, -7F);

		box7 = new ModelRendererTurbo(this, 7, 47, 256, 128);
		box7.addBox(0F, 0F, 0F, 20, 1, 2);
		box7.setPosition(24F, 22F, 11F);
		box7.rotateAngleX = -0.6457718232379019F;
		box7.rotateAngleY = -3.141592653589793F;

		box72 = new ModelRendererTurbo(this, 156, 66, 256, 128);
		box72.addBox(0F, 0F, 0F, 19, 1, 4);
		box72.setPosition(-14F, 3F, -10F);

		box74 = new ModelRendererTurbo(this, 71, 2, 256, 128);
		box74.addBox(0F, 0F, 0F, 3, 3, 8);
		box74.setPosition(-1F, 24F, -4F);
		box74.rotateAngleZ = -0.7853981633974483F;

		box8 = new ModelRendererTurbo(this, 7, 47, 256, 128);
		box8.addBox(0F, 0F, 0F, 20, 1, 2);
		box8.setPosition(4F, 22F, -11F);
		box8.rotateAngleX = -0.6457718232379019F;

		box81 = new ModelRendererTurbo(this, 154, 55, 256, 128);
		box81.addBox(0F, 0F, 0F, 1, 2, 2);
		box81.setPosition(-20F, 12F, -9F);

		box82 = new ModelRendererTurbo(this, 154, 55, 256, 128);
		box82.addBox(0F, 0F, 0F, 1, 2, 2);
		box82.setPosition(-20F, 12F, 7F);

		box9 = new ModelRendererTurbo(this, 0, 89, 256, 128);
		box9.addBox(0F, 0F, 0F, 25, 9, 1);
		box9.setPosition(-19F, 1F, -6F);
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		//box46.render(f5);
		//box47.render(f5);
		//box48.render(f5);
		//box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box7.render(f5);
		box72.render(f5);
		box74.render(f5);
		box8.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap();
		box81.render(f5);
		box82.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap();
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}