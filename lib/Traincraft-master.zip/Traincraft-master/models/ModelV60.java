package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelV60 extends ModelBase {
	
	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box80;
	public ModelRendererTurbo box81;
	public ModelRendererTurbo box82;
	public ModelRendererTurbo box83;
	public ModelRendererTurbo box84;
	public ModelRendererTurbo box85;
	public ModelRendererTurbo box86;
	public ModelRendererTurbo box87;
	public ModelRendererTurbo box88;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;

	public ModelV60() {
		box = new ModelRendererTurbo(this, 7, 164, 256, 256);
		box.addBox(0F, 0F, 0F, 44, 9, 0);
		box.setPosition(-22F, 0F, -5F);

		box0 = new ModelRendererTurbo(this, 202, 167, 256, 256);
		box0.addBox(0F, 0F, 0F, 1, 6, 1);
		box0.setPosition(13F, 26F, -9F);

		box1 = new ModelRendererTurbo(this, 7, 153, 256, 256);
		box1.addBox(0F, 0F, 0F, 44, 9, 0);
		box1.setPosition(-22F, 0F, 5F);

		box10 = new ModelRendererTurbo(this, 138, 53, 256, 256);
		box10.addBox(0F, 0F, 0F, 0, 6, 3);
		box10.setPosition(-22F, 3F, 8F);

		box11 = new ModelRendererTurbo(this, 152, 35, 256, 256);
		box11.addBox(0F, 0F, 0F, 2, 3, 4);
		box11.setPosition(28F, 6F, -2F);

		box12 = new ModelRendererTurbo(this, 90, 39, 256, 256);
		box12.addBox(0F, 0F, 0F, 6, 1, 3);
		box12.setPosition(-28F, 3F, 8F);

		box13 = new ModelRendererTurbo(this, 2, 47, 256, 256);
		box13.addBox(0F, 0F, 0F, 21, 1, 6);
		box13.setPosition(-5F, 33F, -3F);

		box14 = new ModelRendererTurbo(this, 126, 54, 256, 256);
		box14.addBox(0F, 0F, 0F, 4, 7, 0);
		box14.setPosition(-28F, 3F, 8F);

		box15 = new ModelRendererTurbo(this, 122, 186, 256, 256);
		box15.addBox(0F, 0F, 0F, 22, 15, 14);
		box15.setPosition(-25F, 11F, -7F);

		box16 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box16.addBox(0F, -1F, 0F, 21, 1, 7);
		box16.setPosition(-5F, 34F, 3F);
		box16.rotateAngleX = -6.126105674500097F;

		box17 = new ModelRendererTurbo(this, 214, 168, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 8, 1);
		box17.setPosition(-3F, 25F, -11F);
		box17.rotateAngleX = -6.056292504420323F;

		box18 = new ModelRendererTurbo(this, 1, 55, 256, 256);
		box18.addBox(0F, -1F, 0F, 21, 1, 7);
		box18.setPosition(16F, 34F, -3F);
		box18.rotateAngleX = -6.126105674500097F;
		box18.rotateAngleY = -3.141592653589793F;

		box19 = new ModelRendererTurbo(this, 184, 150, 256, 256);
		box19.addBox(0F, 0F, 0F, 1, 5, 6);
		box19.setPosition(-3F, 27F, -3F);

		box2 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 10);
		box2.setPosition(14F, 3F, -5F);

		box20 = new ModelRendererTurbo(this, 4, 186, 256, 256);
		box20.addBox(0F, 0F, 0F, 1, 5, 16);
		box20.setPosition(-28F, 6F, -8F);

		box21 = new ModelRendererTurbo(this, 195, 186, 256, 256);
		box21.addBox(0F, 0F, 0F, 11, 15, 14);
		box21.setPosition(14F, 11F, -7F);

		box22 = new ModelRendererTurbo(this, 39, 186, 256, 256);
		box22.addBox(0F, 0F, 0F, 1, 5, 16);
		box22.setPosition(27F, 6F, -8F);

		box23 = new ModelRendererTurbo(this, 147, 71, 256, 256);
		box23.addBox(0F, 0F, 0F, 1, 13, 20);
		box23.setPosition(-3F, 14F, -10F);

		box24 = new ModelRendererTurbo(this, 3, 108, 256, 256);
		box24.addBox(0F, 0F, 0F, 42, 2, 22);
		box24.setPosition(-22F, 9F, -11F);

		box25 = new ModelRendererTurbo(this, 153, 51, 256, 256);
		box25.addBox(0F, 0F, 0F, 1, 3, 3);
		box25.setPosition(28F, 7F, -7F);

		box26 = new ModelRendererTurbo(this, 192, 73, 256, 256);
		box26.addBox(0F, 0F, 0F, 1, 16, 18);
		box26.setPosition(13F, 11F, -9F);

		box27 = new ModelRendererTurbo(this, 168, 110, 256, 256);
		box27.addBox(0F, 0F, 0F, 11, 11, 1);
		box27.setPosition(-3F, 14F, -11F);

		box28 = new ModelRendererTurbo(this, 234, 110, 256, 256);
		box28.addBox(0F, 0F, 0F, 5, 21, 0);
		box28.setPosition(8F, 11F, -9F);

		box29 = new ModelRendererTurbo(this, 228, 146, 256, 256);
		box29.addBox(0F, 0F, 0F, 1, 15, 1);
		box29.setPosition(7F, 14F, -10F);

		box3 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 10);
		box3.setPosition(-16F, 3F, -5F);

		box30 = new ModelRendererTurbo(this, 3, 79, 256, 256);
		box30.addBox(0F, 0F, 0F, 29, 3, 22);
		box30.setPosition(-21F, 11F, -11F);

		box31 = new ModelRendererTurbo(this, 119, 154, 256, 256);
		box31.addBox(0F, 0F, 0F, 5, 1, 16);
		box31.setPosition(-27F, 10F, -8F);

		box32 = new ModelRendererTurbo(this, 85, 77, 256, 256);
		box32.addBox(0F, 0F, 0F, 5, 3, 18);
		box32.setPosition(8F, 11F, -9F);

		box33 = new ModelRendererTurbo(this, 22, 0, 256, 256);
		box33.addBox(0F, 0F, 0F, 5, 10, 8);
		box33.setPosition(-2F, 14F, -4F);

		box34 = new ModelRendererTurbo(this, 3, 12, 256, 256);
		box34.addBox(0F, 0F, 0F, 2, 10, 8);
		box34.setPosition(11F, 14F, -4F);

		box35 = new ModelRendererTurbo(this, 222, 168, 256, 256);
		box35.addBox(0F, 0F, 0F, 2, 8, 1);
		box35.setPosition(6F, 25F, -11F);
		box35.rotateAngleX = -6.056292504420323F;

		box36 = new ModelRendererTurbo(this, 90, 46, 256, 256);
		box36.addBox(0F, 0F, 0F, 8, 1, 3);
		box36.setPosition(20F, 3F, 8F);

		box37 = new ModelRendererTurbo(this, 213, 178, 256, 256);
		box37.addBox(0F, 0F, 0F, 7, 1, 1);
		box37.setPosition(-1F, 25F, -11F);
		box37.rotateAngleX = -6.056292504420323F;

		box38 = new ModelRendererTurbo(this, 153, 51, 256, 256);
		box38.addBox(0F, 0F, 0F, 1, 3, 3);
		box38.setPosition(28F, 7F, 4F);

		box39 = new ModelRendererTurbo(this, 213, 181, 256, 256);
		box39.addBox(0F, 6F, 0F, 7, 2, 1);
		box39.setPosition(-1F, 25F, -11F);
		box39.rotateAngleX = -6.056292504420323F;

		box4 = new ModelRendererTurbo(this, 8, 176, 256, 256);
		box4.addBox(0F, 0F, 0F, 33, 2, 1);
		box4.setPosition(-17F, 1F, 5F);

		box40 = new ModelRendererTurbo(this, 153, 44, 256, 256);
		box40.addBox(0F, 0F, 0F, 1, 3, 3);
		box40.setPosition(-29F, 7F, -7F);

		box41 = new ModelRendererTurbo(this, 199, 146, 256, 256);
		box41.addBox(0F, 0F, 0F, 1, 1, 18);
		box41.setPosition(-3F, 32F, -9F);

		box42 = new ModelRendererTurbo(this, 153, 44, 256, 256);
		box42.addBox(0F, 0F, 0F, 1, 3, 3);
		box42.setPosition(-29F, 7F, 4F);

		box43 = new ModelRendererTurbo(this, 200, 150, 256, 256);
		box43.addBox(0F, 0F, 0F, 1, 5, 6);
		box43.setPosition(13F, 27F, -3F);

		box44 = new ModelRendererTurbo(this, 152, 35, 256, 256);
		box44.addBox(0F, 0F, 0F, 2, 3, 4);
		box44.setPosition(-30F, 6F, -2F);

		box45 = new ModelRendererTurbo(this, 199, 126, 256, 256);
		box45.addBox(0F, 0F, 0F, 1, 1, 18);
		box45.setPosition(13F, 32F, -9F);

		box46 = new ModelRendererTurbo(this, 202, 173, 256, 256);
		box46.addBox(0F, 0F, 0F, 1, 5, 1);
		box46.setPosition(13F, 28F, -9F);
		box46.rotateAngleX = -6.056292504420323F;

		box47 = new ModelRendererTurbo(this, 191, 128, 256, 256);
		box47.addBox(-4F, 0F, 0F, 3, 8, 4);
		box47.setPosition(18F, 26F, -2F);
		box47.rotateAngleZ = -6.161012259539984F;

		box48 = new ModelRendererTurbo(this, 119, 136, 256, 256);
		box48.addBox(0F, 0F, 0F, 7, 1, 16);
		box48.setPosition(20F, 10F, -8F);

		box49 = new ModelRendererTurbo(this, 172, 127, 256, 256);
		box49.addBox(-5F, 0F, 0F, 5, 9, 4);
		box49.setPosition(-9F, 26F, 2F);
		box49.rotateAngleY = 3.141592653589793F;
		box49.rotateAngleZ = 6.126105674500097F;

		box5 = new ModelRendererTurbo(this, 11, 68, 256, 256);
		box5.addBox(0F, 0F, 0F, 56, 0, 2);
		box5.setPosition(-28F, 7F, 8F);

		box50 = new ModelRendererTurbo(this, 90, 46, 256, 256);
		box50.addBox(0F, 0F, 0F, 8, 1, 3);
		box50.setPosition(20F, 3F, -11F);

		box51 = new ModelRendererTurbo(this, 194, 110, 256, 256);
		box51.addBox(0F, 0F, 0F, 11, 11, 1);
		box51.setPosition(-3F, 14F, 10F);

		box52 = new ModelRendererTurbo(this, 233, 167, 256, 256);
		box52.addBox(0F, 0F, 0F, 1, 5, 1);
		box52.setPosition(13F, 27F, 8F);

		box53 = new ModelRendererTurbo(this, 220, 110, 256, 256);
		box53.addBox(0F, 0F, 0F, 5, 21, 0);
		box53.setPosition(13F, 11F, 9F);
		box53.rotateAngleY = -3.141592653589793F;

		box54 = new ModelRendererTurbo(this, 222, 146, 256, 256);
		box54.addBox(0F, 0F, 0F, 1, 15, 1);
		box54.setPosition(7F, 14F, 9F);

		box55 = new ModelRendererTurbo(this, 238, 168, 256, 256);
		box55.addBox(0F, 0F, 0F, 2, 8, 1);
		box55.setPosition(8F, 25F, 11F);
		box55.rotateAngleX = -6.056292504420323F;
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new ModelRendererTurbo(this, 245, 168, 256, 256);
		box56.addBox(0F, 0F, 0F, 2, 8, 1);
		box56.setPosition(-1F, 25F, 11F);
		box56.rotateAngleX = -6.056292504420323F;
		box56.rotateAngleY = -3.141592653589793F;

		box57 = new ModelRendererTurbo(this, 237, 183, 256, 256);
		box57.addBox(0F, 0F, 0F, 7, 1, 1);
		box57.setPosition(6F, 25F, 11F);
		box57.rotateAngleX = -6.056292504420323F;
		box57.rotateAngleY = -3.141592653589793F;

		box58 = new ModelRendererTurbo(this, 237, 179, 256, 256);
		box58.addBox(0F, 6F, 0F, 7, 2, 1);
		box58.setPosition(6F, 25F, 11F);
		box58.rotateAngleX = -6.056292504420323F;
		box58.rotateAngleY = -3.141592653589793F;

		box59 = new ModelRendererTurbo(this, 146, 217, 256, 256);
		box59.addBox(0F, 0F, 0F, 9, 12, 16);
		box59.setPosition(-18F, 15F, -8F);

		box6 = new ModelRendererTurbo(this, 11, 68, 256, 256);
		box6.addBox(0F, 0F, 0F, 56, 0, 2);
		box6.setPosition(-28F, 9F, 8F);

		box60 = new ModelRendererTurbo(this, 186, 194, 256, 256);
		box60.addBox(0F, 0F, 0F, 6, 1, 2);
		box60.setPosition(-24F, 26F, -1F);

		box61 = new ModelRendererTurbo(this, 160, 137, 256, 256);
		box61.addBox(0F, 0F, 0F, 3, 3, 2);
		box61.setPosition(-6F, 34F, -1F);

		box62 = new ModelRendererTurbo(this, 61, 45, 256, 256);
		box62.addBox(0F, 0F, 1F, 4, 1, 1);
		box62.setPosition(-2F, 34F, -6F);

		box63 = new ModelRendererTurbo(this, 61, 49, 256, 256);
		box63.addBox(0F, 0F, 1F, 4, 1, 1);
		box63.setPosition(-4F, 34F, -8F);

		box64 = new ModelRendererTurbo(this, 69, 53, 256, 256);
		box64.addBox(0F, 0F, 0F, 2, 1, 2);
		box64.setPosition(-1F, 33F, -7F);
		box64.rotateAngleY = -0.7853981633974483F;

		box65 = new ModelRendererTurbo(this, 61, 55, 256, 256);
		box65.addBox(-1F, 0F, -1F, 2, 2, 2);
		box65.setPosition(7F, 34F, 0F);
		box65.rotateAngleY = -0.7853981633974483F;

		box66 = new ModelRendererTurbo(this, 114, 54, 256, 256);
		box66.addBox(0F, 0F, 0F, 4, 7, 0);
		box66.setPosition(24F, 3F, -8F);

		box67 = new ModelRendererTurbo(this, 114, 43, 256, 256);
		box67.addBox(0F, 0F, 0F, 0, 6, 3);
		box67.setPosition(20F, 3F, -11F);

		box68 = new ModelRendererTurbo(this, 96, 1, 256, 256);
		box68.addBox(0F, 0F, 0F, 2, 2, 10);
		box68.setPosition(-4F, 3F, -5F);

		box69 = new ModelRendererTurbo(this, 94, 195, 256, 256);
		box69.addBox(0F, 0F, 0F, 0, 17, 24);
		box69.setPosition(28F, 4F, -12F);

		box7 = new ModelRendererTurbo(this, 114, 43, 256, 256);
		box7.addBox(0F, 0F, 0F, 0, 6, 3);
		box7.setPosition(20F, 3F, 8F);

		box70 = new ModelRendererTurbo(this, 206, 129, 256, 256);
		box70.addBox(0F, 0F, 0F, 1, 6, 4);
		box70.setPosition(-4F, 26F, -2F);

		box71 = new ModelRendererTurbo(this, 138, 53, 256, 256);
		box71.addBox(0F, 0F, 0F, 0, 6, 3);
		box71.setPosition(-22F, 3F, -11F);

		box72 = new ModelRendererTurbo(this, 90, 39, 256, 256);
		box72.addBox(0F, 0F, 0F, 6, 1, 3);
		box72.setPosition(-28F, 3F, -11F);

		box73 = new ModelRendererTurbo(this, 126, 54, 256, 256);
		box73.addBox(0F, 0F, 0F, 4, 7, 0);
		box73.setPosition(-28F, 3F, -8F);

		box74 = new ModelRendererTurbo(this, 171, 147, 256, 256);
		box74.addBox(0F, 0F, 0F, 2, 2, 2);
		box74.setPosition(-10F, 30F, -1F);

		box75 = new ModelRendererTurbo(this, 171, 147, 256, 256);
		box75.addBox(0F, 0F, 0F, 2, 2, 2);
		box75.setPosition(16F, 30F, -1F);

		box76 = new ModelRendererTurbo(this, 11, 68, 256, 256);
		box76.addBox(0F, 0F, 0F, 56, 0, 2);
		box76.setPosition(-28F, 7F, -10F);

		box77 = new ModelRendererTurbo(this, 11, 68, 256, 256);
		box77.addBox(0F, 0F, 0F, 56, 0, 2);
		box77.setPosition(-28F, 9F, -10F);

		box78 = new ModelRendererTurbo(this, 94, 215, 256, 256);
		box78.addBox(0F, 0F, 0F, 0, 17, 24);
		box78.setPosition(-28F, 4F, -12F);

		box79 = new ModelRendererTurbo(this, 163, 50, 256, 256);
		box79.addBox(0F, 0F, 0F, 1, 2, 2);
		box79.setPosition(28F, 12F, 7F);

		box8 = new ModelRendererTurbo(this, 114, 54, 256, 256);
		box8.addBox(0F, 0F, 0F, 4, 7, 0);
		box8.setPosition(24F, 3F, 8F);

		box80 = new ModelRendererTurbo(this, 163, 50, 256, 256);
		box80.addBox(0F, 0F, 0F, 1, 2, 2);
		box80.setPosition(28F, 12F, -9F);

		box81 = new ModelRendererTurbo(this, 163, 44, 256, 256);
		box81.addBox(0F, 0F, 0F, 1, 2, 2);
		box81.setPosition(-29F, 12F, -9F);

		box82 = new ModelRendererTurbo(this, 163, 44, 256, 256);
		box82.addBox(0F, 0F, 0F, 1, 2, 2);
		box82.setPosition(-29F, 12F, 7F);

		box83 = new ModelRendererTurbo(this, 8, 176, 256, 256);
		box83.addBox(0F, 0F, 0F, 33, 2, 1);
		box83.setPosition(-17F, 1F, -6F);

		box84 = new ModelRendererTurbo(this, 0, 211, 256, 256);
		box84.addBox(0F, 0F, -8F, 47, 20, 0);
		box84.setPosition(-24F, 4F, -3F);

		box85 = new ModelRendererTurbo(this, 0, 234, 256, 256);
		box85.addBox(0F, 0F, 0F, 47, 20, 0);
		box85.setPosition(-24F, 4F, 11F);

		box86 = new ModelRendererTurbo(this, 0, 0, 256, 256);
		box86.addBox(0F, 0F, 0F, 2, 3, 8);
		box86.setPosition(0F, 24F, 4F);
		box86.rotateAngleY = 3.141592653589793F;
		box86.rotateAngleZ = 0.6457718232379019F;

		box87 = new ModelRendererTurbo(this, 233, 173, 256, 256);
		box87.addBox(0F, 0F, 0F, 1, 5, 1);
		box87.setPosition(14F, 28F, 9F);
		box87.rotateAngleX = -6.056292504420323F;
		box87.rotateAngleY = -3.141592653589793F;

		box88 = new ModelRendererTurbo(this, 203, 46, 256, 256);
		box88.addBox(0F, 0F, 0F, 2, 0, 22);
		box88.setPosition(8F, 13F, -11F);

		box89 = new ModelRendererTurbo(this, 168, 42, 256, 256);
		box89.addBox(0F, 0F, 0F, 4, 2, 22);
		box89.setPosition(-18F, 7F, -11F);

		box9 = new ModelRendererTurbo(this, 2, 134, 256, 256);
		box9.addBox(0F, 0F, 0F, 52, 8, 8);
		box9.setPosition(-26F, 2F, -4F);
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box8.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap();
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box79.render(f5);
		box74.render(f5);
		box75.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap();
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}