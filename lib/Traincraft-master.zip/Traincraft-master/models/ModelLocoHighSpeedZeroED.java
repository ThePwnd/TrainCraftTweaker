package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.ModelRendererTurbo;

public class ModelLocoHighSpeedZeroED extends ModelBase {
	
	public ModelRendererTurbo box;
	public ModelRendererTurbo box0;
	public ModelRendererTurbo box1;
	public ModelRendererTurbo box10;
	public ModelRendererTurbo box11;
	public ModelRendererTurbo box12;
	public ModelRendererTurbo box13;
	public ModelRendererTurbo box14;
	public ModelRendererTurbo box15;
	public ModelRendererTurbo box16;
	public ModelRendererTurbo box17;
	public ModelRendererTurbo box18;
	public ModelRendererTurbo box19;
	public ModelRendererTurbo box2;
	public ModelRendererTurbo box20;
	public ModelRendererTurbo box21;
	public ModelRendererTurbo box22;
	public ModelRendererTurbo box23;
	public ModelRendererTurbo box24;
	public ModelRendererTurbo box25;
	public ModelRendererTurbo box26;
	public ModelRendererTurbo box27;
	public ModelRendererTurbo box28;
	public ModelRendererTurbo box29;
	public ModelRendererTurbo box3;
	public ModelRendererTurbo box30;
	public ModelRendererTurbo box31;
	public ModelRendererTurbo box32;
	public ModelRendererTurbo box33;
	public ModelRendererTurbo box34;
	public ModelRendererTurbo box35;
	public ModelRendererTurbo box36;
	public ModelRendererTurbo box37;
	public ModelRendererTurbo box38;
	public ModelRendererTurbo box39;
	public ModelRendererTurbo box4;
	public ModelRendererTurbo box40;
	public ModelRendererTurbo box41;
	public ModelRendererTurbo box42;
	public ModelRendererTurbo box43;
	public ModelRendererTurbo box44;
	public ModelRendererTurbo box45;
	public ModelRendererTurbo box46;
	public ModelRendererTurbo box47;
	public ModelRendererTurbo box48;
	public ModelRendererTurbo box49;
	public ModelRendererTurbo box5;
	public ModelRendererTurbo box50;
	public ModelRendererTurbo box51;
	public ModelRendererTurbo box52;
	public ModelRendererTurbo box53;
	public ModelRendererTurbo box54;
	public ModelRendererTurbo box55;
	public ModelRendererTurbo box56;
	public ModelRendererTurbo box57;
	public ModelRendererTurbo box58;
	public ModelRendererTurbo box59;
	public ModelRendererTurbo box6;
	public ModelRendererTurbo box60;
	public ModelRendererTurbo box61;
	public ModelRendererTurbo box62;
	public ModelRendererTurbo box63;
	public ModelRendererTurbo box64;
	public ModelRendererTurbo box65;
	public ModelRendererTurbo box66;
	public ModelRendererTurbo box67;
	public ModelRendererTurbo box68;
	public ModelRendererTurbo box69;
	public ModelRendererTurbo box7;
	public ModelRendererTurbo box70;
	public ModelRendererTurbo box71;
	public ModelRendererTurbo box72;
	public ModelRendererTurbo box73;
	public ModelRendererTurbo box74;
	public ModelRendererTurbo box75;
	public ModelRendererTurbo box76;
	public ModelRendererTurbo box77;
	public ModelRendererTurbo box78;
	public ModelRendererTurbo box79;
	public ModelRendererTurbo box8;
	public ModelRendererTurbo box89;
	public ModelRendererTurbo box9;
	
	public ModelLocoHighSpeedZeroED() {

		box = new ModelRendererTurbo(this, 63, 158, 256, 256);
		box.addBox(0F, 0F, 0F, 15, 18, 2);
		box.setPosition(-12F, 6F, 11F);
		box.rotateAngleY = -3.2812189937493397F;

		box0 = new ModelRendererTurbo(this, 143, 8, 256, 256);
		box0.addBox(0F, 0F, 0F, 16, 3, 1);
		box0.setPosition(13F, 3F, -6F);

		box1 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-19F, 0F, 5F);

		box10 = new ModelRendererTurbo(this, 98, 122, 256, 256);
		box10.addBox(0F, -5F, -1F, 24, 5, 1);
		box10.setPosition(-12F, 6F, 11F);
		box10.rotateAngleX = -5.951572749300664F;

		box11 = new ModelRendererTurbo(this, 38, 158, 256, 256);
		box11.addBox(0F, 0F, -2F, 10, 18, 2);
		box11.setPosition(-36F, 6F, 5F);
		box11.rotateAngleY = -0.4014257279586958F;

		box12 = new ModelRendererTurbo(this, 7, 160, 256, 256);
		box12.addBox(0F, -5F, -1F, 5, 5, 1);
		box12.setPosition(-36F, 6F, 5F);
		box12.rotateAngleX = -5.951572749300664F;
		box12.rotateAngleY = -0.4014257279586958F;

		box13 = new ModelRendererTurbo(this, 0, 72, 256, 256);
		box13.addBox(0F, 0F, 0F, 46, 18, 2);
		box13.setPosition(-12F, 6F, -11F);

		box14 = new ModelRendererTurbo(this, 1, 61, 256, 256);
		box14.addBox(0F, 0F, -2F, 37, 8, 2);
		box14.setPosition(34F, 24F, -11F);
		box14.rotateAngleX = -0.22689280275926285F;
		box14.rotateAngleY = -3.141592653589793F;

		box15 = new ModelRendererTurbo(this, 62, 93, 256, 256);
		box15.addBox(0F, 0F, -2F, 15, 18, 2);
		box15.setPosition(-12F, 6F, -11F);
		box15.rotateAngleY = -3.001966313430247F;

		box16 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-31F, 0F, -5F);

		box17 = new ModelRendererTurbo(this, 199, 14, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 2, 14);
		box17.setPosition(-28F, 2F, -7F);

		box18 = new ModelRendererTurbo(this, 2, 96, 256, 256);
		box18.addBox(0F, -5F, 0F, 5, 5, 1);
		box18.setPosition(-36F, 6F, -5F);
		box18.rotateAngleX = -0.33161255787892263F;
		box18.rotateAngleY = -5.8817595792208905F;

		box19 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(23F, 0F, -5F);

		box2 = new ModelRendererTurbo(this, 199, 14, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 14);
		box2.setPosition(14F, 2F, -7F);

		box20 = new ModelRendererTurbo(this, 199, 14, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 14);
		box20.setPosition(26F, 2F, -7F);

		box21 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(23F, 0F, 5F);

		box22 = new ModelRendererTurbo(this, 162, 1, 256, 256);
		box22.addBox(0F, 0F, 0F, 8, 4, 16);
		box22.setPosition(17F, 1F, -8F);

		box23 = new ModelRendererTurbo(this, 162, 1, 256, 256);
		box23.addBox(0F, 0F, 0F, 8, 4, 16);
		box23.setPosition(-25F, 1F, -8F);

		box24 = new ModelRendererTurbo(this, 143, 8, 256, 256);
		box24.addBox(0F, 0F, 0F, 16, 3, 1);
		box24.setPosition(-29F, 3F, -6F);

		box25 = new ModelRendererTurbo(this, 199, 144, 256, 256);
		box25.addBox(0F, 0F, -1F, 3, 5, 1);
		box25.setPosition(-2F, 26F, -9F);
		box25.rotateAngleX = -0.19198621771937624F;
		box25.rotateAngleY = -3.141592653589793F;

		box26 = new ModelRendererTurbo(this, 103, 86, 256, 256);
		box26.addBox(0F, 0F, 0F, 17, 5, 16);
		box26.setPosition(-9F, 1F, -8F);

		box27 = new ModelRendererTurbo(this, 36, 93, 256, 256);
		box27.addBox(0F, 0F, 0F, 10, 18, 2);
		box27.setPosition(-36F, 6F, -5F);
		box27.rotateAngleY = -5.8817595792208905F;

		box28 = new ModelRendererTurbo(this, 234, 2, 256, 256);
		box28.addBox(0F, 1F, 0F, 2, 19, 8);
		box28.setPosition(-35F, 3F, -4F);

		box29 = new ModelRendererTurbo(this, 117, 66, 256, 256);
		box29.addBox(0F, -2F, 0F, 3, 2, 16);
		box29.setPosition(-1F, 32F, 8F);
		box29.rotateAngleY = -3.141592653589793F;

		box3 = new ModelRendererTurbo(this, 199, 14, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 14);
		box3.setPosition(-16F, 2F, -7F);

		box30 = new ModelRendererTurbo(this, 213, 33, 256, 256);
		box30.addBox(0F, 0F, 0F, 5, 2, 16);
		box30.setPosition(-33F, 9F, -8F);

		box31 = new ModelRendererTurbo(this, 0, 38, 256, 256);
		box31.addBox(0F, -2F, -3F, 19, 2, 2);
		box31.setPosition(-28F, 24F, -4F);
		box31.rotateAngleY = -6.230825429619756F;
		box31.rotateAngleZ = -5.8817595792208905F;

		box32 = new ModelRendererTurbo(this, 0, 43, 256, 256);
		box32.addBox(0F, -2F, 1F, 19, 2, 2);
		box32.setPosition(-28F, 24F, 4F);
		box32.rotateAngleY = -0.05235987755982989F;
		box32.rotateAngleZ = -5.8817595792208905F;

		box33 = new ModelRendererTurbo(this, 162, 22, 256, 256);
		box33.addBox(-12F, -2F, 0F, 12, 2, 12);
		box33.setPosition(-34F, 23F, 6F);
		box33.rotateAngleY = 3.141592653589793F;
		box33.rotateAngleZ = 0.29670597283903605F;

		box34 = new ModelRendererTurbo(this, 228, 152, 256, 256);
		box34.addBox(0F, 0F, -2F, 12, 18, 1);
		box34.setPosition(-12F, 8F, -10F);
		box34.rotateAngleY = -3.001966313430247F;

		box35 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(11F, 0F, 4F);

		box36 = new ModelRendererTurbo(this, 217, 5, 256, 256);
		box36.addBox(0F, 0F, 0F, 2, 4, 4);
		box36.setPosition(-36F, 18F, -2F);

		box37 = new ModelRendererTurbo(this, 219, 16, 256, 256);
		box37.addBox(0F, 0F, 0F, 2, 2, 2);
		box37.setPosition(-36F, 15F, -1F);

		box38 = new ModelRendererTurbo(this, 209, 131, 256, 256);
		box38.addBox(0F, 0F, 0F, 10, 18, 1);
		box38.setPosition(-12F, 8F, -9F);

		box39 = new ModelRendererTurbo(this, 233, 131, 256, 256);
		box39.addBox(0F, 0F, 0F, 10, 18, 1);
		box39.setPosition(-12F, 8F, 8F);

		box4 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box4.addBox(0F, 0F, 0F, 8, 7, 0);
		box4.setPosition(-31F, 0F, 5F);

		box40 = new ModelRendererTurbo(this, 200, 152, 256, 256);
		box40.addBox(0F, 0F, 0F, 12, 18, 1);
		box40.setPosition(-12F, 8F, 9F);
		box40.rotateAngleY = -3.2812189937493397F;

		box41 = new ModelRendererTurbo(this, 149, 122, 256, 256);
		box41.addBox(0F, -5F, 0F, 24, 5, 1);
		box41.setPosition(-12F, 6F, -11F);
		box41.rotateAngleX = -0.33161255787892263F;

		box42 = new ModelRendererTurbo(this, 16, 96, 256, 256);
		box42.addBox(0F, -5F, 0F, 4, 5, 1);
		box42.setPosition(30F, 6F, -11F);
		box42.rotateAngleX = -0.33161255787892263F;

		box43 = new ModelRendererTurbo(this, 110, 67, 256, 256);
		box43.addBox(0F, -3F, 0F, 1, 3, 8);
		box43.setPosition(-35F, 4F, -4F);
		box43.rotateAngleX = -6.283185307179586F;
		box43.rotateAngleZ = -5.6374134839416845F;

		box44 = new ModelRendererTurbo(this, 217, 89, 256, 256);
		box44.addBox(0F, 0F, 0F, 1, 20, 18);
		box44.setPosition(-2F, 10F, -9F);

		box45 = new ModelRendererTurbo(this, 158, 82, 256, 256);
		box45.addBox(0F, -2F, 0F, 6, 1, 14);
		box45.setPosition(-17F, 27F, 7F);
		box45.rotateAngleY = 3.141592653589793F;
		box45.rotateAngleZ = 0.06981317007977318F;

		box46 = new ModelRendererTurbo(this, 187, 84, 256, 256);
		box46.addBox(0F, -4F, 0F, 1, 4, 14);
		box46.setPosition(-17F, 25F, 7F);
		box46.rotateAngleY = 3.141592653589793F;
		box46.rotateAngleZ = 0.22689280275926285F;

		box47 = new ModelRendererTurbo(this, 181, 141, 256, 256);
		box47.addBox(2F, 0F, -1F, 5, 6, 1);
		box47.setPosition(-12F, 22F, -8F);
		box47.rotateAngleY = -3.001966313430247F;

		box48 = new ModelRendererTurbo(this, 181, 133, 256, 256);
		box48.addBox(2F, 0F, 0F, 5, 6, 1);
		box48.setPosition(-12F, 22F, 8F);
		box48.rotateAngleY = -3.2812189937493397F;

		box49 = new ModelRendererTurbo(this, 173, 104, 256, 256);
		box49.addBox(0F, 0F, 0F, 5, 1, 16);
		box49.setPosition(-14F, 21F, 8F);
		box49.rotateAngleY = 3.141592653589793F;
		box49.rotateAngleZ = 6.126105674500097F;

		box5 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(11F, 0F, -5F);

		box50 = new ModelRendererTurbo(this, 142, 62, 256, 256);
		box50.addBox(0F, -2F, 0F, 21, 2, 16);
		box50.setPosition(-2F, 14F, 8F);
		box50.rotateAngleY = -3.141592653589793F;

		box51 = new ModelRendererTurbo(this, 123, 3, 256, 256);
		box51.addBox(0F, 0F, 0F, 1, 9, 16);
		box51.setPosition(-17F, 14F, 8F);
		box51.rotateAngleY = -3.141592653589793F;

		box52 = new ModelRendererTurbo(this, 158, 109, 256, 256);
		box52.addBox(0F, -2F, 0F, 7, 2, 8);
		box52.setPosition(-3F, 18F, 4F);
		box52.rotateAngleY = -3.141592653589793F;
		box52.rotateAngleZ = -6.19591884457987F;

		box53 = new ModelRendererTurbo(this, 200, 103, 256, 256);
		box53.addBox(-2F, 0F, 0F, 2, 10, 6);
		box53.setPosition(-5F, 17F, 3F);
		box53.rotateAngleY = 3.141592653589793F;
		box53.rotateAngleZ = 6.161012259539984F;

		box54 = new ModelRendererTurbo(this, 201, 122, 256, 256);
		box54.addBox(0F, -2F, 0F, 6, 2, 1);
		box54.setPosition(-3F, 22F, 4F);
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new ModelRendererTurbo(this, 201, 122, 256, 256);
		box55.addBox(0F, -2F, 0F, 6, 2, 1);
		box55.setPosition(-3F, 22F, -3F);
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new ModelRendererTurbo(this, 34, 38, 256, 256);
		box56.addBox(0F, -1F, 0F, 7, 1, 16);
		box56.setPosition(-4F, 32F, 8F);
		box56.rotateAngleY = 3.141592653589793F;
		box56.rotateAngleZ = 0.08726646259971647F;

		box57 = new ModelRendererTurbo(this, 0, 48, 256, 256);
		box57.addBox(0F, -2F, 0F, 7, 1, 2);
		box57.setPosition(-4F, 32F, 8F);
		box57.rotateAngleY = 3.141592653589793F;
		box57.rotateAngleZ = 0.08726646259971647F;

		box58 = new ModelRendererTurbo(this, 0, 52, 256, 256);
		box58.addBox(0F, -2F, 0F, 7, 1, 2);
		box58.setPosition(-4F, 32F, -6F);
		box58.rotateAngleY = 3.141592653589793F;
		box58.rotateAngleZ = 0.08726646259971647F;

		box59 = new ModelRendererTurbo(this, 118, 29, 256, 256);
		box59.addBox(0F, 0F, 0F, 10, 2, 6);
		box59.setPosition(14F, 28F, -3F);

		box6 = new ModelRendererTurbo(this, 143, 8, 256, 256);
		box6.addBox(0F, 0F, 0F, 16, 3, 1);
		box6.setPosition(-29F, 3F, 5F);

		box60 = new ModelRendererTurbo(this, 104, 2, 256, 256);
		box60.addBox(0F, 0F, 0F, 12, 1, 2);
		box60.setPosition(25F, 38F, 1F);
		box60.rotateAngleY = 3.141592653589793F;
		box60.rotateAngleZ = 0.3490658503988659F;

		box61 = new ModelRendererTurbo(this, 107, 6, 256, 256);
		box61.addBox(0F, 0F, 0F, 10, 1, 1);
		box61.setPosition(22F, 29F, 2F);
		box61.rotateAngleY = 3.141592653589793F;
		box61.rotateAngleZ = 5.742133239061344F;

		box62 = new ModelRendererTurbo(this, 107, 6, 256, 256);
		box62.addBox(0F, 0F, 0F, 10, 1, 1);
		box62.setPosition(22F, 29F, -1F);
		box62.rotateAngleY = 3.141592653589793F;
		box62.rotateAngleZ = 5.742133239061344F;

		box63 = new ModelRendererTurbo(this, 195, 4, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-19F, 0F, -5F);

		box64 = new ModelRendererTurbo(this, 88, 2, 256, 256);
		box64.addBox(0F, 0F, 0F, 2, 1, 12);
		box64.setPosition(24F, 38F, -6F);

		box65 = new ModelRendererTurbo(this, 199, 137, 256, 256);
		box65.addBox(0F, 0F, -1F, 3, 5, 1);
		box65.setPosition(-5F, 26F, 9F);
		box65.rotateAngleX = -0.19198621771937624F;

		box66 = new ModelRendererTurbo(this, 242, 78, 256, 256);
		box66.addBox(0F, 0F, 0F, 2, 3, 4);
		box66.setPosition(-37F, 6F, -2F);

		box67 = new ModelRendererTurbo(this, 219, 70, 256, 256);
		box67.addBox(0F, 0F, 0F, 3, 3, 8);
		box67.setPosition(1F, 29F, -6F);

		box68 = new ModelRendererTurbo(this, 219, 70, 256, 256);
		box68.addBox(0F, 0F, 0F, 3, 3, 8);
		box68.setPosition(6F, 29F, -6F);

		box69 = new ModelRendererTurbo(this, 0, 0, 256, 256);
		box69.addBox(0F, 0F, 0F, 35, 19, 18);
		box69.setPosition(-1F, 10F, -9F);

		box7 = new ModelRendererTurbo(this, 0, 147, 256, 256);
		box7.addBox(0F, 0F, -2F, 37, 8, 2);
		box7.setPosition(-3F, 24F, 11F);
		box7.rotateAngleX = -0.22689280275926285F;

		box70 = new ModelRendererTurbo(this, 201, 37, 256, 256);
		box70.addBox(0F, 0F, 0F, 7, 2, 6);
		box70.setPosition(25F, 29F, -1F);

		box71 = new ModelRendererTurbo(this, 248, 86, 256, 256);
		box71.addBox(0F, 0F, 0F, 1, 16, 2);
		box71.setPosition(34F, 10F, -5F);

		box72 = new ModelRendererTurbo(this, 248, 86, 256, 256);
		box72.addBox(0F, 0F, 0F, 1, 16, 2);
		box72.setPosition(34F, 10F, 3F);

		box73 = new ModelRendererTurbo(this, 216, 85, 256, 256);
		box73.addBox(0F, 0F, 0F, 1, 2, 8);
		box73.setPosition(34F, 26F, -4F);

		box74 = new ModelRendererTurbo(this, 63, 38, 256, 256);
		box74.addBox(0F, 0F, 0F, 55, 4, 18);
		box74.setPosition(-21F, 6F, -9F);

		box75 = new ModelRendererTurbo(this, 212, 96, 256, 256);
		box75.addBox(0F, 0F, 0F, 2, 0, 8);
		box75.setPosition(34F, 9F, -4F);
		box75.rotateAngleZ = -6.213372137099813F;

		box76 = new ModelRendererTurbo(this, 111, 132, 256, 256);
		box76.addBox(0F, 0F, 0F, 18, 4, 6);
		box76.setPosition(12F, 2F, -3F);

		box77 = new ModelRendererTurbo(this, 111, 132, 256, 256);
		box77.addBox(0F, 0F, 0F, 18, 4, 6);
		box77.setPosition(-30F, 2F, -3F);

		box78 = new ModelRendererTurbo(this, 242, 78, 256, 256);
		box78.addBox(0F, 0F, 0F, 2, 3, 4);
		box78.setPosition(34F, 6F, -2F);

		box79 = new ModelRendererTurbo(this, 85, 42, 256, 256);
		box79.addBox(0F, 0F, 0F, 9, 3, 14);
		box79.setPosition(-30F, 6F, -7F);

		box8 = new ModelRendererTurbo(this, 143, 8, 256, 256);
		box8.addBox(0F, 0F, 0F, 16, 3, 1);
		box8.setPosition(13F, 3F, 5F);

		box89 = new ModelRendererTurbo(this, 0, 126, 256, 256);
		box89.addBox(0F, 0F, 0F, 46, 18, 2);
		box89.setPosition(-12F, 6F, 9F);

		box9 = new ModelRendererTurbo(this, 21, 160, 256, 256);
		box9.addBox(0F, -5F, -1F, 4, 5, 1);
		box9.setPosition(30F, 6F, 11F);
		box9.rotateAngleX = -5.951572749300664F;
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box89.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap();
		box36.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap();
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
