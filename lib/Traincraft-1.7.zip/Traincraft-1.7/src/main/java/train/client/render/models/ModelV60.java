package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;

public class ModelV60 extends ModelBase {
	
	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box11;
	public CustomModelRenderer box12;
	public CustomModelRenderer box13;
	public CustomModelRenderer box14;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box64;
	public CustomModelRenderer box65;
	public CustomModelRenderer box66;
	public CustomModelRenderer box67;
	public CustomModelRenderer box68;
	public CustomModelRenderer box69;
	public CustomModelRenderer box7;
	public CustomModelRenderer box70;
	public CustomModelRenderer box71;
	public CustomModelRenderer box72;
	public CustomModelRenderer box73;
	public CustomModelRenderer box74;
	public CustomModelRenderer box75;
	public CustomModelRenderer box76;
	public CustomModelRenderer box77;
	public CustomModelRenderer box78;
	public CustomModelRenderer box79;
	public CustomModelRenderer box8;
	public CustomModelRenderer box80;
	public CustomModelRenderer box81;
	public CustomModelRenderer box82;
	public CustomModelRenderer box83;
	public CustomModelRenderer box84;
	public CustomModelRenderer box85;
	public CustomModelRenderer box86;
	public CustomModelRenderer box87;
	public CustomModelRenderer box88;
	public CustomModelRenderer box89;
	public CustomModelRenderer box9;

	public ModelV60() {
		box = new CustomModelRenderer(this, 7, 164, 256, 256);
		box.addBox(0F, 0F, 0F, 44, 9, 0);
		box.setPosition(-22F, 0F, -5F);

		box0 = new CustomModelRenderer(this, 202, 167, 256, 256);
		box0.addBox(0F, 0F, 0F, 1, 6, 1);
		box0.setPosition(13F, 26F, -9F);

		box1 = new CustomModelRenderer(this, 7, 153, 256, 256);
		box1.addBox(0F, 0F, 0F, 44, 9, 0);
		box1.setPosition(-22F, 0F, 5F);

		box10 = new CustomModelRenderer(this, 138, 53, 256, 256);
		box10.addBox(0F, 0F, 0F, 0, 6, 3);
		box10.setPosition(-22F, 3F, 8F);

		box11 = new CustomModelRenderer(this, 152, 35, 256, 256);
		box11.addBox(0F, 0F, 0F, 2, 3, 4);
		box11.setPosition(28F, 6F, -2F);

		box12 = new CustomModelRenderer(this, 90, 39, 256, 256);
		box12.addBox(0F, 0F, 0F, 6, 1, 3);
		box12.setPosition(-28F, 3F, 8F);

		box13 = new CustomModelRenderer(this, 2, 47, 256, 256);
		box13.addBox(0F, 0F, 0F, 21, 1, 6);
		box13.setPosition(-5F, 33F, -3F);

		box14 = new CustomModelRenderer(this, 126, 54, 256, 256);
		box14.addBox(0F, 0F, 0F, 4, 7, 0);
		box14.setPosition(-28F, 3F, 8F);

		box15 = new CustomModelRenderer(this, 122, 186, 256, 256);
		box15.addBox(0F, 0F, 0F, 22, 15, 14);
		box15.setPosition(-25F, 11F, -7F);

		box16 = new CustomModelRenderer(this, 1, 55, 256, 256);
		box16.addBox(0F, -1F, 0F, 21, 1, 7);
		box16.setPosition(-5F, 34F, 3F);
		box16.rotateAngleX = -6.126105674500097F;

		box17 = new CustomModelRenderer(this, 214, 168, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 8, 1);
		box17.setPosition(-3F, 25F, -11F);
		box17.rotateAngleX = -6.056292504420323F;

		box18 = new CustomModelRenderer(this, 1, 55, 256, 256);
		box18.addBox(0F, -1F, 0F, 21, 1, 7);
		box18.setPosition(16F, 34F, -3F);
		box18.rotateAngleX = -6.126105674500097F;
		box18.rotateAngleY = -3.141592653589793F;

		box19 = new CustomModelRenderer(this, 184, 150, 256, 256);
		box19.addBox(0F, 0F, 0F, 1, 5, 6);
		box19.setPosition(-3F, 27F, -3F);

		box2 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 10);
		box2.setPosition(14F, 3F, -5F);

		box20 = new CustomModelRenderer(this, 4, 186, 256, 256);
		box20.addBox(0F, 0F, 0F, 1, 5, 16);
		box20.setPosition(-28F, 6F, -8F);

		box21 = new CustomModelRenderer(this, 195, 186, 256, 256);
		box21.addBox(0F, 0F, 0F, 11, 15, 14);
		box21.setPosition(14F, 11F, -7F);

		box22 = new CustomModelRenderer(this, 39, 186, 256, 256);
		box22.addBox(0F, 0F, 0F, 1, 5, 16);
		box22.setPosition(27F, 6F, -8F);

		box23 = new CustomModelRenderer(this, 147, 71, 256, 256);
		box23.addBox(0F, 0F, 0F, 1, 13, 20);
		box23.setPosition(-3F, 14F, -10F);

		box24 = new CustomModelRenderer(this, 3, 108, 256, 256);
		box24.addBox(0F, 0F, 0F, 42, 2, 22);
		box24.setPosition(-22F, 9F, -11F);

		box25 = new CustomModelRenderer(this, 153, 51, 256, 256);
		box25.addBox(0F, 0F, 0F, 1, 3, 3);
		box25.setPosition(28F, 7F, -7F);

		box26 = new CustomModelRenderer(this, 192, 73, 256, 256);
		box26.addBox(0F, 0F, 0F, 1, 16, 18);
		box26.setPosition(13F, 11F, -9F);

		box27 = new CustomModelRenderer(this, 168, 110, 256, 256);
		box27.addBox(0F, 0F, 0F, 11, 11, 1);
		box27.setPosition(-3F, 14F, -11F);

		box28 = new CustomModelRenderer(this, 234, 110, 256, 256);
		box28.addBox(0F, 0F, 0F, 5, 21, 0);
		box28.setPosition(8F, 11F, -9F);

		box29 = new CustomModelRenderer(this, 228, 146, 256, 256);
		box29.addBox(0F, 0F, 0F, 1, 15, 1);
		box29.setPosition(7F, 14F, -10F);

		box3 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 10);
		box3.setPosition(-16F, 3F, -5F);

		box30 = new CustomModelRenderer(this, 3, 79, 256, 256);
		box30.addBox(0F, 0F, 0F, 29, 3, 22);
		box30.setPosition(-21F, 11F, -11F);

		box31 = new CustomModelRenderer(this, 119, 154, 256, 256);
		box31.addBox(0F, 0F, 0F, 5, 1, 16);
		box31.setPosition(-27F, 10F, -8F);

		box32 = new CustomModelRenderer(this, 85, 77, 256, 256);
		box32.addBox(0F, 0F, 0F, 5, 3, 18);
		box32.setPosition(8F, 11F, -9F);

		box33 = new CustomModelRenderer(this, 22, 0, 256, 256);
		box33.addBox(0F, 0F, 0F, 5, 10, 8);
		box33.setPosition(-2F, 14F, -4F);

		box34 = new CustomModelRenderer(this, 3, 12, 256, 256);
		box34.addBox(0F, 0F, 0F, 2, 10, 8);
		box34.setPosition(11F, 14F, -4F);

		box35 = new CustomModelRenderer(this, 222, 168, 256, 256);
		box35.addBox(0F, 0F, 0F, 2, 8, 1);
		box35.setPosition(6F, 25F, -11F);
		box35.rotateAngleX = -6.056292504420323F;

		box36 = new CustomModelRenderer(this, 90, 46, 256, 256);
		box36.addBox(0F, 0F, 0F, 8, 1, 3);
		box36.setPosition(20F, 3F, 8F);

		box37 = new CustomModelRenderer(this, 213, 178, 256, 256);
		box37.addBox(0F, 0F, 0F, 7, 1, 1);
		box37.setPosition(-1F, 25F, -11F);
		box37.rotateAngleX = -6.056292504420323F;

		box38 = new CustomModelRenderer(this, 153, 51, 256, 256);
		box38.addBox(0F, 0F, 0F, 1, 3, 3);
		box38.setPosition(28F, 7F, 4F);

		box39 = new CustomModelRenderer(this, 213, 181, 256, 256);
		box39.addBox(0F, 6F, 0F, 7, 2, 1);
		box39.setPosition(-1F, 25F, -11F);
		box39.rotateAngleX = -6.056292504420323F;

		box4 = new CustomModelRenderer(this, 8, 176, 256, 256);
		box4.addBox(0F, 0F, 0F, 33, 2, 1);
		box4.setPosition(-17F, 1F, 5F);

		box40 = new CustomModelRenderer(this, 153, 44, 256, 256);
		box40.addBox(0F, 0F, 0F, 1, 3, 3);
		box40.setPosition(-29F, 7F, -7F);

		box41 = new CustomModelRenderer(this, 199, 146, 256, 256);
		box41.addBox(0F, 0F, 0F, 1, 1, 18);
		box41.setPosition(-3F, 32F, -9F);

		box42 = new CustomModelRenderer(this, 153, 44, 256, 256);
		box42.addBox(0F, 0F, 0F, 1, 3, 3);
		box42.setPosition(-29F, 7F, 4F);

		box43 = new CustomModelRenderer(this, 200, 150, 256, 256);
		box43.addBox(0F, 0F, 0F, 1, 5, 6);
		box43.setPosition(13F, 27F, -3F);

		box44 = new CustomModelRenderer(this, 152, 35, 256, 256);
		box44.addBox(0F, 0F, 0F, 2, 3, 4);
		box44.setPosition(-30F, 6F, -2F);

		box45 = new CustomModelRenderer(this, 199, 126, 256, 256);
		box45.addBox(0F, 0F, 0F, 1, 1, 18);
		box45.setPosition(13F, 32F, -9F);

		box46 = new CustomModelRenderer(this, 202, 173, 256, 256);
		box46.addBox(0F, 0F, 0F, 1, 5, 1);
		box46.setPosition(13F, 28F, -9F);
		box46.rotateAngleX = -6.056292504420323F;

		box47 = new CustomModelRenderer(this, 191, 128, 256, 256);
		box47.addBox(-4F, 0F, 0F, 3, 8, 4);
		box47.setPosition(18F, 26F, -2F);
		box47.rotateAngleZ = -6.161012259539984F;

		box48 = new CustomModelRenderer(this, 119, 136, 256, 256);
		box48.addBox(0F, 0F, 0F, 7, 1, 16);
		box48.setPosition(20F, 10F, -8F);

		box49 = new CustomModelRenderer(this, 172, 127, 256, 256);
		box49.addBox(-5F, 0F, 0F, 5, 9, 4);
		box49.setPosition(-9F, 26F, 2F);
		box49.rotateAngleY = 3.141592653589793F;
		box49.rotateAngleZ = 6.126105674500097F;

		box5 = new CustomModelRenderer(this, 11, 68, 256, 256);
		box5.addBox(0F, 0F, 0F, 56, 0, 2);
		box5.setPosition(-28F, 7F, 8F);

		box50 = new CustomModelRenderer(this, 90, 46, 256, 256);
		box50.addBox(0F, 0F, 0F, 8, 1, 3);
		box50.setPosition(20F, 3F, -11F);

		box51 = new CustomModelRenderer(this, 194, 110, 256, 256);
		box51.addBox(0F, 0F, 0F, 11, 11, 1);
		box51.setPosition(-3F, 14F, 10F);

		box52 = new CustomModelRenderer(this, 233, 167, 256, 256);
		box52.addBox(0F, 0F, 0F, 1, 5, 1);
		box52.setPosition(13F, 27F, 8F);

		box53 = new CustomModelRenderer(this, 220, 110, 256, 256);
		box53.addBox(0F, 0F, 0F, 5, 21, 0);
		box53.setPosition(13F, 11F, 9F);
		box53.rotateAngleY = -3.141592653589793F;

		box54 = new CustomModelRenderer(this, 222, 146, 256, 256);
		box54.addBox(0F, 0F, 0F, 1, 15, 1);
		box54.setPosition(7F, 14F, 9F);

		box55 = new CustomModelRenderer(this, 238, 168, 256, 256);
		box55.addBox(0F, 0F, 0F, 2, 8, 1);
		box55.setPosition(8F, 25F, 11F);
		box55.rotateAngleX = -6.056292504420323F;
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new CustomModelRenderer(this, 245, 168, 256, 256);
		box56.addBox(0F, 0F, 0F, 2, 8, 1);
		box56.setPosition(-1F, 25F, 11F);
		box56.rotateAngleX = -6.056292504420323F;
		box56.rotateAngleY = -3.141592653589793F;

		box57 = new CustomModelRenderer(this, 237, 183, 256, 256);
		box57.addBox(0F, 0F, 0F, 7, 1, 1);
		box57.setPosition(6F, 25F, 11F);
		box57.rotateAngleX = -6.056292504420323F;
		box57.rotateAngleY = -3.141592653589793F;

		box58 = new CustomModelRenderer(this, 237, 179, 256, 256);
		box58.addBox(0F, 6F, 0F, 7, 2, 1);
		box58.setPosition(6F, 25F, 11F);
		box58.rotateAngleX = -6.056292504420323F;
		box58.rotateAngleY = -3.141592653589793F;

		box59 = new CustomModelRenderer(this, 146, 217, 256, 256);
		box59.addBox(0F, 0F, 0F, 9, 12, 16);
		box59.setPosition(-18F, 15F, -8F);

		box6 = new CustomModelRenderer(this, 11, 68, 256, 256);
		box6.addBox(0F, 0F, 0F, 56, 0, 2);
		box6.setPosition(-28F, 9F, 8F);

		box60 = new CustomModelRenderer(this, 186, 194, 256, 256);
		box60.addBox(0F, 0F, 0F, 6, 1, 2);
		box60.setPosition(-24F, 26F, -1F);

		box61 = new CustomModelRenderer(this, 160, 137, 256, 256);
		box61.addBox(0F, 0F, 0F, 3, 3, 2);
		box61.setPosition(-6F, 34F, -1F);

		box62 = new CustomModelRenderer(this, 61, 45, 256, 256);
		box62.addBox(0F, 0F, 1F, 4, 1, 1);
		box62.setPosition(-2F, 34F, -6F);

		box63 = new CustomModelRenderer(this, 61, 49, 256, 256);
		box63.addBox(0F, 0F, 1F, 4, 1, 1);
		box63.setPosition(-4F, 34F, -8F);

		box64 = new CustomModelRenderer(this, 69, 53, 256, 256);
		box64.addBox(0F, 0F, 0F, 2, 1, 2);
		box64.setPosition(-1F, 33F, -7F);
		box64.rotateAngleY = -0.7853981633974483F;

		box65 = new CustomModelRenderer(this, 61, 55, 256, 256);
		box65.addBox(-1F, 0F, -1F, 2, 2, 2);
		box65.setPosition(7F, 34F, 0F);
		box65.rotateAngleY = -0.7853981633974483F;

		box66 = new CustomModelRenderer(this, 114, 54, 256, 256);
		box66.addBox(0F, 0F, 0F, 4, 7, 0);
		box66.setPosition(24F, 3F, -8F);

		box67 = new CustomModelRenderer(this, 114, 43, 256, 256);
		box67.addBox(0F, 0F, 0F, 0, 6, 3);
		box67.setPosition(20F, 3F, -11F);

		box68 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box68.addBox(0F, 0F, 0F, 2, 2, 10);
		box68.setPosition(-4F, 3F, -5F);

		box69 = new CustomModelRenderer(this, 94, 195, 256, 256);
		box69.addBox(0F, 0F, 0F, 0, 17, 24);
		box69.setPosition(28F, 4F, -12F);

		box7 = new CustomModelRenderer(this, 114, 43, 256, 256);
		box7.addBox(0F, 0F, 0F, 0, 6, 3);
		box7.setPosition(20F, 3F, 8F);

		box70 = new CustomModelRenderer(this, 206, 129, 256, 256);
		box70.addBox(0F, 0F, 0F, 1, 6, 4);
		box70.setPosition(-4F, 26F, -2F);

		box71 = new CustomModelRenderer(this, 138, 53, 256, 256);
		box71.addBox(0F, 0F, 0F, 0, 6, 3);
		box71.setPosition(-22F, 3F, -11F);

		box72 = new CustomModelRenderer(this, 90, 39, 256, 256);
		box72.addBox(0F, 0F, 0F, 6, 1, 3);
		box72.setPosition(-28F, 3F, -11F);

		box73 = new CustomModelRenderer(this, 126, 54, 256, 256);
		box73.addBox(0F, 0F, 0F, 4, 7, 0);
		box73.setPosition(-28F, 3F, -8F);

		box74 = new CustomModelRenderer(this, 171, 147, 256, 256);
		box74.addBox(0F, 0F, 0F, 2, 2, 2);
		box74.setPosition(-10F, 30F, -1F);

		box75 = new CustomModelRenderer(this, 171, 147, 256, 256);
		box75.addBox(0F, 0F, 0F, 2, 2, 2);
		box75.setPosition(16F, 30F, -1F);

		box76 = new CustomModelRenderer(this, 11, 68, 256, 256);
		box76.addBox(0F, 0F, 0F, 56, 0, 2);
		box76.setPosition(-28F, 7F, -10F);

		box77 = new CustomModelRenderer(this, 11, 68, 256, 256);
		box77.addBox(0F, 0F, 0F, 56, 0, 2);
		box77.setPosition(-28F, 9F, -10F);

		box78 = new CustomModelRenderer(this, 94, 215, 256, 256);
		box78.addBox(0F, 0F, 0F, 0, 17, 24);
		box78.setPosition(-28F, 4F, -12F);

		box79 = new CustomModelRenderer(this, 163, 50, 256, 256);
		box79.addBox(0F, 0F, 0F, 1, 2, 2);
		box79.setPosition(28F, 12F, 7F);

		box8 = new CustomModelRenderer(this, 114, 54, 256, 256);
		box8.addBox(0F, 0F, 0F, 4, 7, 0);
		box8.setPosition(24F, 3F, 8F);

		box80 = new CustomModelRenderer(this, 163, 50, 256, 256);
		box80.addBox(0F, 0F, 0F, 1, 2, 2);
		box80.setPosition(28F, 12F, -9F);

		box81 = new CustomModelRenderer(this, 163, 44, 256, 256);
		box81.addBox(0F, 0F, 0F, 1, 2, 2);
		box81.setPosition(-29F, 12F, -9F);

		box82 = new CustomModelRenderer(this, 163, 44, 256, 256);
		box82.addBox(0F, 0F, 0F, 1, 2, 2);
		box82.setPosition(-29F, 12F, 7F);

		box83 = new CustomModelRenderer(this, 8, 176, 256, 256);
		box83.addBox(0F, 0F, 0F, 33, 2, 1);
		box83.setPosition(-17F, 1F, -6F);

		box84 = new CustomModelRenderer(this, 0, 211, 256, 256);
		box84.addBox(0F, 0F, -8F, 47, 20, 0);
		box84.setPosition(-24F, 4F, -3F);

		box85 = new CustomModelRenderer(this, 0, 234, 256, 256);
		box85.addBox(0F, 0F, 0F, 47, 20, 0);
		box85.setPosition(-24F, 4F, 11F);

		box86 = new CustomModelRenderer(this, 0, 0, 256, 256);
		box86.addBox(0F, 0F, 0F, 2, 3, 8);
		box86.setPosition(0F, 24F, 4F);
		box86.rotateAngleY = 3.141592653589793F;
		box86.rotateAngleZ = 0.6457718232379019F;

		box87 = new CustomModelRenderer(this, 233, 173, 256, 256);
		box87.addBox(0F, 0F, 0F, 1, 5, 1);
		box87.setPosition(14F, 28F, 9F);
		box87.rotateAngleX = -6.056292504420323F;
		box87.rotateAngleY = -3.141592653589793F;

		box88 = new CustomModelRenderer(this, 203, 46, 256, 256);
		box88.addBox(0F, 0F, 0F, 2, 0, 22);
		box88.setPosition(8F, 13F, -11F);

		box89 = new CustomModelRenderer(this, 168, 42, 256, 256);
		box89.addBox(0F, 0F, 0F, 4, 2, 22);
		box89.setPosition(-18F, 7F, -11F);

		box9 = new CustomModelRenderer(this, 2, 134, 256, 256);
		box9.addBox(0F, 0F, 0F, 52, 8, 8);
		box9.setPosition(-26F, 2F, -4F);
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box8.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box79.render(f5);
		box74.render(f5);
		box75.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}