package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;

public class ModelBR_E69 extends ModelBase {

	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box11;
	public CustomModelRenderer box12;
	public CustomModelRenderer box13;
	public CustomModelRenderer box14;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box64;
	public CustomModelRenderer box7;
	public CustomModelRenderer box8;
	public CustomModelRenderer box9;

	public ModelBR_E69() {
		box = new CustomModelRenderer(this, 3, 117, 256, 128);
		box.addBox(0F, 0F, 0F, 6, 3, 3);
		box.setPosition(4F, 5F, 7F);

		box0 = new CustomModelRenderer(this, 139, 74, 256, 128);
		box0.addBox(0F, 0F, 0F, 40, 5, 1);
		box0.setPosition(20F, 1F, -5F);
		box0.rotateAngleY = -3.141592653589793F;

		box1 = new CustomModelRenderer(this, 188, 11, 256, 128);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-16F, 0F, 5F);

		box10 = new CustomModelRenderer(this, 0, 0, 256, 128);
		box10.addBox(0F, -3F, 0F, 11, 3, 20);
		box10.setPosition(8F, 22F, -10F);
		box10.rotateAngleZ = -0.15707963267948966F;

		box11 = new CustomModelRenderer(this, 152, 35, 256, 128);
		box11.addBox(0F, 0F, 0F, 2, 3, 4);
		box11.setPosition(22F, 6F, -2F);

		box12 = new CustomModelRenderer(this, 3, 117, 256, 128);
		box12.addBox(0F, 0F, 0F, 6, 3, 3);
		box12.setPosition(-10F, 5F, -10F);

		box13 = new CustomModelRenderer(this, 1, 32, 256, 128);
		box13.addBox(0F, -1F, 0F, 20, 1, 6);
		box13.setPosition(-10F, 32F, -3F);

		box14 = new CustomModelRenderer(this, 85, 87, 256, 128);
		box14.addBox(0F, 0F, 0F, 0, 20, 20);
		box14.setPosition(8F, 11F, -10F);

		box15 = new CustomModelRenderer(this, 191, 27, 256, 128);
		box15.addBox(0F, 0F, 0F, 12, 8, 20);
		box15.setPosition(-20F, 11F, -10F);

		box16 = new CustomModelRenderer(this, 0, 41, 256, 128);
		box16.addBox(0F, -1F, 0F, 20, 1, 7);
		box16.setPosition(-10F, 32F, 3F);
		box16.rotateAngleX = -6.14355896702004F;

		box17 = new CustomModelRenderer(this, 4, 26, 256, 128);
		box17.addBox(0F, -1F, 0F, 20, 1, 3);
		box17.setPosition(-10F, 31F, 10F);
		box17.rotateAngleX = -5.480333851262195F;

		box18 = new CustomModelRenderer(this, 0, 41, 256, 128);
		box18.addBox(0F, -1F, 0F, 20, 1, 7);
		box18.setPosition(10F, 32F, -3F);
		box18.rotateAngleX = -6.14355896702004F;
		box18.rotateAngleY = -3.141592653589793F;

		box19 = new CustomModelRenderer(this, 4, 26, 256, 128);
		box19.addBox(0F, -1F, 0F, 20, 1, 3);
		box19.setPosition(10F, 31F, -10F);
		box19.rotateAngleX = -5.480333851262195F;
		box19.rotateAngleY = -3.141592653589793F;

		box2 = new CustomModelRenderer(this, 96, 1, 256, 128);
		box2.addBox(0F, 0F, 0F, 2, 2, 16);
		box2.setPosition(11F, 2F, -8F);

		box20 = new CustomModelRenderer(this, 107, 66, 256, 128);
		box20.addBox(-2F, 0F, 0F, 2, 3, 20);
		box20.setPosition(21F, 18F, -10F);
		box20.rotateAngleZ = -5.515240436302081F;

		box21 = new CustomModelRenderer(this, 191, 7, 256, 128);
		box21.addBox(0F, 0F, 0F, 12, 8, 20);
		box21.setPosition(8F, 11F, -10F);

		box22 = new CustomModelRenderer(this, 173, 56, 256, 128);
		box22.addBox(0F, 0F, 0F, 10, 2, 14);
		box22.setPosition(-17F, 3F, -7F);

		box23 = new CustomModelRenderer(this, 0, 0, 256, 128);
		box23.addBox(0F, -3F, 0F, 11, 3, 20);
		box23.setPosition(-8F, 22F, 10F);
		box23.rotateAngleY = 3.141592653589793F;
		box23.rotateAngleZ = 0.15707963267948966F;

		box24 = new CustomModelRenderer(this, 165, 15, 256, 128);
		box24.addBox(0F, 0F, 0F, 1, 7, 20);
		box24.setPosition(-21F, 11F, -10F);

		box25 = new CustomModelRenderer(this, 161, 44, 256, 128);
		box25.addBox(0F, 0F, 0F, 1, 3, 3);
		box25.setPosition(22F, 7F, -7F);

		box26 = new CustomModelRenderer(this, 107, 66, 256, 128);
		box26.addBox(-2F, 0F, 0F, 2, 3, 20);
		box26.setPosition(-21F, 18F, 10F);
		box26.rotateAngleY = 3.141592653589793F;
		box26.rotateAngleZ = 5.515240436302081F;

		box27 = new CustomModelRenderer(this, 173, 56, 256, 128);
		box27.addBox(0F, 0F, 0F, 10, 2, 14);
		box27.setPosition(7F, 3F, -7F);

		box28 = new CustomModelRenderer(this, 163, 1, 256, 128);
		box28.addBox(0F, 1F, 0F, 44, 2, 2);
		box28.setPosition(-22F, 11F, 5F);

		box29 = new CustomModelRenderer(this, 163, 1, 256, 128);
		box29.addBox(0F, 1F, 0F, 44, 2, 2);
		box29.setPosition(-22F, 11F, -7F);

		box3 = new CustomModelRenderer(this, 96, 1, 256, 128);
		box3.addBox(0F, 0F, 0F, 2, 2, 16);
		box3.setPosition(-13F, 2F, -8F);

		box30 = new CustomModelRenderer(this, 111, 43, 256, 128);
		box30.addBox(0F, 0F, 0F, 18, 3, 0);
		box30.setPosition(-9F, 32F, 6F);

		box31 = new CustomModelRenderer(this, 72, 3, 256, 128);
		box31.addBox(0F, 0F, 0F, 2, 1, 18);
		box31.setPosition(-1F, 34F, -9F);

		box32 = new CustomModelRenderer(this, 23, 81, 256, 128);
		box32.addBox(0F, 0F, 0F, 5, 19, 1);
		box32.setPosition(-8F, 11F, -11F);

		box33 = new CustomModelRenderer(this, 36, 81, 256, 128);
		box33.addBox(0F, 0F, 0F, 5, 19, 1);
		box33.setPosition(3F, 11F, -11F);

		box34 = new CustomModelRenderer(this, 7, 81, 256, 128);
		box34.addBox(0F, 0F, 0F, 6, 2, 1);
		box34.setPosition(-3F, 28F, -11F);

		box35 = new CustomModelRenderer(this, 188, 11, 256, 128);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(8F, 0F, 5F);

		box36 = new CustomModelRenderer(this, 7, 60, 256, 128);
		box36.addBox(0F, 0F, 0F, 6, 2, 1);
		box36.setPosition(-3F, 28F, 10F);

		box37 = new CustomModelRenderer(this, 36, 60, 256, 128);
		box37.addBox(0F, 0F, 0F, 5, 19, 1);
		box37.setPosition(3F, 11F, 10F);

		box38 = new CustomModelRenderer(this, 161, 44, 256, 128);
		box38.addBox(0F, 0F, 0F, 1, 3, 3);
		box38.setPosition(22F, 7F, 4F);

		box39 = new CustomModelRenderer(this, 23, 60, 256, 128);
		box39.addBox(0F, 0F, 0F, 5, 19, 1);
		box39.setPosition(-8F, 11F, 10F);

		box4 = new CustomModelRenderer(this, 85, 42, 256, 128);
		box4.addBox(0F, 0F, 0F, 0, 20, 20);
		box4.setPosition(-8F, 11F, -10F);

		box40 = new CustomModelRenderer(this, 153, 44, 256, 128);
		box40.addBox(0F, 0F, 0F, 1, 3, 3);
		box40.setPosition(-23F, 7F, -7F);

		box41 = new CustomModelRenderer(this, 134, -1, 256, 128);
		box41.addBox(0F, 0F, 0F, 3, 9, 20);
		box41.setPosition(-7F, 11F, -10F);

		box42 = new CustomModelRenderer(this, 153, 44, 256, 128);
		box42.addBox(0F, 0F, 0F, 1, 3, 3);
		box42.setPosition(-23F, 7F, 4F);

		box43 = new CustomModelRenderer(this, 36, 106, 256, 128);
		box43.addBox(0F, 0F, 0F, 1, 9, 8);
		box43.setPosition(7F, 11F, 1F);

		box44 = new CustomModelRenderer(this, 152, 35, 256, 128);
		box44.addBox(0F, 0F, 0F, 2, 3, 4);
		box44.setPosition(-24F, 6F, -2F);

		box45 = new CustomModelRenderer(this, 36, 106, 256, 128);
		box45.addBox(0F, 1F, 0F, 5, 1, 20);
		box45.setPosition(-8F, 19F, -10F);
		box45.rotateAngleZ = -0.20943951023931956F;

		box46 = new CustomModelRenderer(this, 133, 52, 256, 128);
		box46.addBox(0F, -1F, 0F, 14, 2, 12);
		box46.setPosition(-7F, 32F, -6F);

		box47 = new CustomModelRenderer(this, 112, 48, 256, 128);
		box47.addBox(0F, 0F, 0F, 10, 10, 0);
		box47.setPosition(0F, 28F, -6F);
		box47.rotateAngleZ = -5.497787143782138F;

		box48 = new CustomModelRenderer(this, 112, 48, 256, 128);
		box48.addBox(0F, 0F, 0F, 10, 10, 0);
		box48.setPosition(0F, 28F, 6F);
		box48.rotateAngleZ = -5.497787143782138F;

		box49 = new CustomModelRenderer(this, 47, 0, 256, 128);
		box49.addBox(0F, 0F, 0F, 2, 1, 18);
		box49.setPosition(-1F, 41F, -9F);

		box5 = new CustomModelRenderer(this, 188, 11, 256, 128);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(8F, 0F, -5F);

		box50 = new CustomModelRenderer(this, 235, 7, 256, 128);
		box50.addBox(0F, 0F, 0F, 1, 4, 8);
		box50.setPosition(-22F, 1F, 0F);
		box50.rotateAngleY = -6.003932626860494F;

		box51 = new CustomModelRenderer(this, 235, 7, 256, 128);
		box51.addBox(-1F, 0F, 0F, 1, 4, 8);
		box51.setPosition(-22F, 1F, 0F);
		box51.rotateAngleY = -3.420845333908886F;

		box52 = new CustomModelRenderer(this, 235, 7, 256, 128);
		box52.addBox(-1F, 0F, 0F, 1, 4, 8);
		box52.setPosition(22F, 1F, 0F);
		box52.rotateAngleY = -0.2792526803190927F;

		box53 = new CustomModelRenderer(this, 235, 7, 256, 128);
		box53.addBox(0F, 0F, 0F, 1, 4, 8);
		box53.setPosition(22F, 1F, 0F);
		box53.rotateAngleY = -2.8623399732707004F;

		box54 = new CustomModelRenderer(this, 237, 64, 256, 128);
		box54.addBox(0F, 0F, 0F, 1, 7, 1);
		box54.setPosition(-3F, 3F, -9F);

		box55 = new CustomModelRenderer(this, 237, 64, 256, 128);
		box55.addBox(0F, 0F, 0F, 1, 7, 1);
		box55.setPosition(2F, 3F, -9F);

		box56 = new CustomModelRenderer(this, 237, 64, 256, 128);
		box56.addBox(0F, 0F, 0F, 1, 7, 1);
		box56.setPosition(2F, 3F, 8F);

		box57 = new CustomModelRenderer(this, 237, 64, 256, 128);
		box57.addBox(0F, 0F, 0F, 1, 7, 1);
		box57.setPosition(-3F, 3F, 8F);

		box58 = new CustomModelRenderer(this, 236, 59, 256, 128);
		box58.addBox(0F, 0F, 0F, 6, 1, 3);
		box58.setPosition(-3F, 3F, 8F);

		box59 = new CustomModelRenderer(this, 200, 59, 256, 128);
		box59.addBox(0F, 0F, 0F, 6, 1, 22);
		box59.setPosition(-3F, 6F, -11F);

		box6 = new CustomModelRenderer(this, 139, 74, 256, 128);
		box6.addBox(0F, 0F, 0F, 40, 5, 1);
		box6.setPosition(-20F, 1F, 5F);

		box60 = new CustomModelRenderer(this, 236, 59, 256, 128);
		box60.addBox(0F, 0F, 0F, 6, 1, 3);
		box60.setPosition(-3F, 3F, -11F);

		box61 = new CustomModelRenderer(this, 50, 60, 256, 128);
		box61.addBox(0F, 0F, 0F, 6, 17, 0);
		box61.setPosition(-3F, 11F, 10F);

		box62 = new CustomModelRenderer(this, 50, 81, 256, 128);
		box62.addBox(0F, 0F, 0F, 6, 17, 0);
		box62.setPosition(-3F, 11F, -10F);

		box63 = new CustomModelRenderer(this, 188, 11, 256, 128);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-16F, 0F, -5F);

		box64 = new CustomModelRenderer(this, 111, 43, 256, 128);
		box64.addBox(0F, 0F, 0F, 18, 3, 0);
		box64.setPosition(-9F, 32F, -6F);

		box7 = new CustomModelRenderer(this, 128, 104, 256, 128);
		box7.addBox(0F, 0F, 0F, 42, 2, 22);
		box7.setPosition(-21F, 9F, -11F);

		box8 = new CustomModelRenderer(this, 165, 15, 256, 128);
		box8.addBox(0F, 0F, 0F, 1, 7, 20);
		box8.setPosition(20F, 11F, -10F);

		box9 = new CustomModelRenderer(this, 136, 83, 256, 128);
		box9.addBox(0F, 0F, 0F, 44, 5, 16);
		box9.setPosition(-22F, 6F, -8F);

	}
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);		
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box7.render(f5);
		box8.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box28.render(f5);
		box29.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}