package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;

public class ModelLocoHighSpeedZeroED extends ModelBase {
	
	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box11;
	public CustomModelRenderer box12;
	public CustomModelRenderer box13;
	public CustomModelRenderer box14;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box64;
	public CustomModelRenderer box65;
	public CustomModelRenderer box66;
	public CustomModelRenderer box67;
	public CustomModelRenderer box68;
	public CustomModelRenderer box69;
	public CustomModelRenderer box7;
	public CustomModelRenderer box70;
	public CustomModelRenderer box71;
	public CustomModelRenderer box72;
	public CustomModelRenderer box73;
	public CustomModelRenderer box74;
	public CustomModelRenderer box75;
	public CustomModelRenderer box76;
	public CustomModelRenderer box77;
	public CustomModelRenderer box78;
	public CustomModelRenderer box79;
	public CustomModelRenderer box8;
	public CustomModelRenderer box89;
	public CustomModelRenderer box9;
	
	public ModelLocoHighSpeedZeroED() {

		box = new CustomModelRenderer(this, 63, 158, 256, 256);
		box.addBox(0F, 0F, 0F, 15, 18, 2);
		box.setPosition(-12F, 6F, 11F);
		box.rotateAngleY = -3.2812189937493397F;

		box0 = new CustomModelRenderer(this, 143, 8, 256, 256);
		box0.addBox(0F, 0F, 0F, 16, 3, 1);
		box0.setPosition(13F, 3F, -6F);

		box1 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-19F, 0F, 5F);

		box10 = new CustomModelRenderer(this, 98, 122, 256, 256);
		box10.addBox(0F, -5F, -1F, 24, 5, 1);
		box10.setPosition(-12F, 6F, 11F);
		box10.rotateAngleX = -5.951572749300664F;

		box11 = new CustomModelRenderer(this, 38, 158, 256, 256);
		box11.addBox(0F, 0F, -2F, 10, 18, 2);
		box11.setPosition(-36F, 6F, 5F);
		box11.rotateAngleY = -0.4014257279586958F;

		box12 = new CustomModelRenderer(this, 7, 160, 256, 256);
		box12.addBox(0F, -5F, -1F, 5, 5, 1);
		box12.setPosition(-36F, 6F, 5F);
		box12.rotateAngleX = -5.951572749300664F;
		box12.rotateAngleY = -0.4014257279586958F;

		box13 = new CustomModelRenderer(this, 0, 72, 256, 256);
		box13.addBox(0F, 0F, 0F, 46, 18, 2);
		box13.setPosition(-12F, 6F, -11F);

		box14 = new CustomModelRenderer(this, 1, 61, 256, 256);
		box14.addBox(0F, 0F, -2F, 37, 8, 2);
		box14.setPosition(34F, 24F, -11F);
		box14.rotateAngleX = -0.22689280275926285F;
		box14.rotateAngleY = -3.141592653589793F;

		box15 = new CustomModelRenderer(this, 62, 93, 256, 256);
		box15.addBox(0F, 0F, -2F, 15, 18, 2);
		box15.setPosition(-12F, 6F, -11F);
		box15.rotateAngleY = -3.001966313430247F;

		box16 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-31F, 0F, -5F);

		box17 = new CustomModelRenderer(this, 199, 14, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 2, 14);
		box17.setPosition(-28F, 2F, -7F);

		box18 = new CustomModelRenderer(this, 2, 96, 256, 256);
		box18.addBox(0F, -5F, 0F, 5, 5, 1);
		box18.setPosition(-36F, 6F, -5F);
		box18.rotateAngleX = -0.33161255787892263F;
		box18.rotateAngleY = -5.8817595792208905F;

		box19 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(23F, 0F, -5F);

		box2 = new CustomModelRenderer(this, 199, 14, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 14);
		box2.setPosition(14F, 2F, -7F);

		box20 = new CustomModelRenderer(this, 199, 14, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 14);
		box20.setPosition(26F, 2F, -7F);

		box21 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(23F, 0F, 5F);

		box22 = new CustomModelRenderer(this, 162, 1, 256, 256);
		box22.addBox(0F, 0F, 0F, 8, 4, 16);
		box22.setPosition(17F, 1F, -8F);

		box23 = new CustomModelRenderer(this, 162, 1, 256, 256);
		box23.addBox(0F, 0F, 0F, 8, 4, 16);
		box23.setPosition(-25F, 1F, -8F);

		box24 = new CustomModelRenderer(this, 143, 8, 256, 256);
		box24.addBox(0F, 0F, 0F, 16, 3, 1);
		box24.setPosition(-29F, 3F, -6F);

		box25 = new CustomModelRenderer(this, 199, 144, 256, 256);
		box25.addBox(0F, 0F, -1F, 3, 5, 1);
		box25.setPosition(-2F, 26F, -9F);
		box25.rotateAngleX = -0.19198621771937624F;
		box25.rotateAngleY = -3.141592653589793F;

		box26 = new CustomModelRenderer(this, 103, 86, 256, 256);
		box26.addBox(0F, 0F, 0F, 17, 5, 16);
		box26.setPosition(-9F, 1F, -8F);

		box27 = new CustomModelRenderer(this, 36, 93, 256, 256);
		box27.addBox(0F, 0F, 0F, 10, 18, 2);
		box27.setPosition(-36F, 6F, -5F);
		box27.rotateAngleY = -5.8817595792208905F;

		box28 = new CustomModelRenderer(this, 234, 2, 256, 256);
		box28.addBox(0F, 1F, 0F, 2, 19, 8);
		box28.setPosition(-35F, 3F, -4F);

		box29 = new CustomModelRenderer(this, 117, 66, 256, 256);
		box29.addBox(0F, -2F, 0F, 3, 2, 16);
		box29.setPosition(-1F, 32F, 8F);
		box29.rotateAngleY = -3.141592653589793F;

		box3 = new CustomModelRenderer(this, 199, 14, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 14);
		box3.setPosition(-16F, 2F, -7F);

		box30 = new CustomModelRenderer(this, 213, 33, 256, 256);
		box30.addBox(0F, 0F, 0F, 5, 2, 16);
		box30.setPosition(-33F, 9F, -8F);

		box31 = new CustomModelRenderer(this, 0, 38, 256, 256);
		box31.addBox(0F, -2F, -3F, 19, 2, 2);
		box31.setPosition(-28F, 24F, -4F);
		box31.rotateAngleY = -6.230825429619756F;
		box31.rotateAngleZ = -5.8817595792208905F;

		box32 = new CustomModelRenderer(this, 0, 43, 256, 256);
		box32.addBox(0F, -2F, 1F, 19, 2, 2);
		box32.setPosition(-28F, 24F, 4F);
		box32.rotateAngleY = -0.05235987755982989F;
		box32.rotateAngleZ = -5.8817595792208905F;

		box33 = new CustomModelRenderer(this, 162, 22, 256, 256);
		box33.addBox(-12F, -2F, 0F, 12, 2, 12);
		box33.setPosition(-34F, 23F, 6F);
		box33.rotateAngleY = 3.141592653589793F;
		box33.rotateAngleZ = 0.29670597283903605F;

		box34 = new CustomModelRenderer(this, 228, 152, 256, 256);
		box34.addBox(0F, 0F, -2F, 12, 18, 1);
		box34.setPosition(-12F, 8F, -10F);
		box34.rotateAngleY = -3.001966313430247F;

		box35 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(11F, 0F, 4F);

		box36 = new CustomModelRenderer(this, 217, 5, 256, 256);
		box36.addBox(0F, 0F, 0F, 2, 4, 4);
		box36.setPosition(-36F, 18F, -2F);

		box37 = new CustomModelRenderer(this, 219, 16, 256, 256);
		box37.addBox(0F, 0F, 0F, 2, 2, 2);
		box37.setPosition(-36F, 15F, -1F);

		box38 = new CustomModelRenderer(this, 209, 131, 256, 256);
		box38.addBox(0F, 0F, 0F, 10, 18, 1);
		box38.setPosition(-12F, 8F, -9F);

		box39 = new CustomModelRenderer(this, 233, 131, 256, 256);
		box39.addBox(0F, 0F, 0F, 10, 18, 1);
		box39.setPosition(-12F, 8F, 8F);

		box4 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box4.addBox(0F, 0F, 0F, 8, 7, 0);
		box4.setPosition(-31F, 0F, 5F);

		box40 = new CustomModelRenderer(this, 200, 152, 256, 256);
		box40.addBox(0F, 0F, 0F, 12, 18, 1);
		box40.setPosition(-12F, 8F, 9F);
		box40.rotateAngleY = -3.2812189937493397F;

		box41 = new CustomModelRenderer(this, 149, 122, 256, 256);
		box41.addBox(0F, -5F, 0F, 24, 5, 1);
		box41.setPosition(-12F, 6F, -11F);
		box41.rotateAngleX = -0.33161255787892263F;

		box42 = new CustomModelRenderer(this, 16, 96, 256, 256);
		box42.addBox(0F, -5F, 0F, 4, 5, 1);
		box42.setPosition(30F, 6F, -11F);
		box42.rotateAngleX = -0.33161255787892263F;

		box43 = new CustomModelRenderer(this, 110, 67, 256, 256);
		box43.addBox(0F, -3F, 0F, 1, 3, 8);
		box43.setPosition(-35F, 4F, -4F);
		box43.rotateAngleX = -6.283185307179586F;
		box43.rotateAngleZ = -5.6374134839416845F;

		box44 = new CustomModelRenderer(this, 217, 89, 256, 256);
		box44.addBox(0F, 0F, 0F, 1, 20, 18);
		box44.setPosition(-2F, 10F, -9F);

		box45 = new CustomModelRenderer(this, 158, 82, 256, 256);
		box45.addBox(0F, -2F, 0F, 6, 1, 14);
		box45.setPosition(-17F, 27F, 7F);
		box45.rotateAngleY = 3.141592653589793F;
		box45.rotateAngleZ = 0.06981317007977318F;

		box46 = new CustomModelRenderer(this, 187, 84, 256, 256);
		box46.addBox(0F, -4F, 0F, 1, 4, 14);
		box46.setPosition(-17F, 25F, 7F);
		box46.rotateAngleY = 3.141592653589793F;
		box46.rotateAngleZ = 0.22689280275926285F;

		box47 = new CustomModelRenderer(this, 181, 141, 256, 256);
		box47.addBox(2F, 0F, -1F, 5, 6, 1);
		box47.setPosition(-12F, 22F, -8F);
		box47.rotateAngleY = -3.001966313430247F;

		box48 = new CustomModelRenderer(this, 181, 133, 256, 256);
		box48.addBox(2F, 0F, 0F, 5, 6, 1);
		box48.setPosition(-12F, 22F, 8F);
		box48.rotateAngleY = -3.2812189937493397F;

		box49 = new CustomModelRenderer(this, 173, 104, 256, 256);
		box49.addBox(0F, 0F, 0F, 5, 1, 16);
		box49.setPosition(-14F, 21F, 8F);
		box49.rotateAngleY = 3.141592653589793F;
		box49.rotateAngleZ = 6.126105674500097F;

		box5 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(11F, 0F, -5F);

		box50 = new CustomModelRenderer(this, 142, 62, 256, 256);
		box50.addBox(0F, -2F, 0F, 21, 2, 16);
		box50.setPosition(-2F, 14F, 8F);
		box50.rotateAngleY = -3.141592653589793F;

		box51 = new CustomModelRenderer(this, 123, 3, 256, 256);
		box51.addBox(0F, 0F, 0F, 1, 9, 16);
		box51.setPosition(-17F, 14F, 8F);
		box51.rotateAngleY = -3.141592653589793F;

		box52 = new CustomModelRenderer(this, 158, 109, 256, 256);
		box52.addBox(0F, -2F, 0F, 7, 2, 8);
		box52.setPosition(-3F, 18F, 4F);
		box52.rotateAngleY = -3.141592653589793F;
		box52.rotateAngleZ = -6.19591884457987F;

		box53 = new CustomModelRenderer(this, 200, 103, 256, 256);
		box53.addBox(-2F, 0F, 0F, 2, 10, 6);
		box53.setPosition(-5F, 17F, 3F);
		box53.rotateAngleY = 3.141592653589793F;
		box53.rotateAngleZ = 6.161012259539984F;

		box54 = new CustomModelRenderer(this, 201, 122, 256, 256);
		box54.addBox(0F, -2F, 0F, 6, 2, 1);
		box54.setPosition(-3F, 22F, 4F);
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new CustomModelRenderer(this, 201, 122, 256, 256);
		box55.addBox(0F, -2F, 0F, 6, 2, 1);
		box55.setPosition(-3F, 22F, -3F);
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new CustomModelRenderer(this, 34, 38, 256, 256);
		box56.addBox(0F, -1F, 0F, 7, 1, 16);
		box56.setPosition(-4F, 32F, 8F);
		box56.rotateAngleY = 3.141592653589793F;
		box56.rotateAngleZ = 0.08726646259971647F;

		box57 = new CustomModelRenderer(this, 0, 48, 256, 256);
		box57.addBox(0F, -2F, 0F, 7, 1, 2);
		box57.setPosition(-4F, 32F, 8F);
		box57.rotateAngleY = 3.141592653589793F;
		box57.rotateAngleZ = 0.08726646259971647F;

		box58 = new CustomModelRenderer(this, 0, 52, 256, 256);
		box58.addBox(0F, -2F, 0F, 7, 1, 2);
		box58.setPosition(-4F, 32F, -6F);
		box58.rotateAngleY = 3.141592653589793F;
		box58.rotateAngleZ = 0.08726646259971647F;

		box59 = new CustomModelRenderer(this, 118, 29, 256, 256);
		box59.addBox(0F, 0F, 0F, 10, 2, 6);
		box59.setPosition(14F, 28F, -3F);

		box6 = new CustomModelRenderer(this, 143, 8, 256, 256);
		box6.addBox(0F, 0F, 0F, 16, 3, 1);
		box6.setPosition(-29F, 3F, 5F);

		box60 = new CustomModelRenderer(this, 104, 2, 256, 256);
		box60.addBox(0F, 0F, 0F, 12, 1, 2);
		box60.setPosition(25F, 38F, 1F);
		box60.rotateAngleY = 3.141592653589793F;
		box60.rotateAngleZ = 0.3490658503988659F;

		box61 = new CustomModelRenderer(this, 107, 6, 256, 256);
		box61.addBox(0F, 0F, 0F, 10, 1, 1);
		box61.setPosition(22F, 29F, 2F);
		box61.rotateAngleY = 3.141592653589793F;
		box61.rotateAngleZ = 5.742133239061344F;

		box62 = new CustomModelRenderer(this, 107, 6, 256, 256);
		box62.addBox(0F, 0F, 0F, 10, 1, 1);
		box62.setPosition(22F, 29F, -1F);
		box62.rotateAngleY = 3.141592653589793F;
		box62.rotateAngleZ = 5.742133239061344F;

		box63 = new CustomModelRenderer(this, 195, 4, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-19F, 0F, -5F);

		box64 = new CustomModelRenderer(this, 88, 2, 256, 256);
		box64.addBox(0F, 0F, 0F, 2, 1, 12);
		box64.setPosition(24F, 38F, -6F);

		box65 = new CustomModelRenderer(this, 199, 137, 256, 256);
		box65.addBox(0F, 0F, -1F, 3, 5, 1);
		box65.setPosition(-5F, 26F, 9F);
		box65.rotateAngleX = -0.19198621771937624F;

		box66 = new CustomModelRenderer(this, 242, 78, 256, 256);
		box66.addBox(0F, 0F, 0F, 2, 3, 4);
		box66.setPosition(-37F, 6F, -2F);

		box67 = new CustomModelRenderer(this, 219, 70, 256, 256);
		box67.addBox(0F, 0F, 0F, 3, 3, 8);
		box67.setPosition(1F, 29F, -6F);

		box68 = new CustomModelRenderer(this, 219, 70, 256, 256);
		box68.addBox(0F, 0F, 0F, 3, 3, 8);
		box68.setPosition(6F, 29F, -6F);

		box69 = new CustomModelRenderer(this, 0, 0, 256, 256);
		box69.addBox(0F, 0F, 0F, 35, 19, 18);
		box69.setPosition(-1F, 10F, -9F);

		box7 = new CustomModelRenderer(this, 0, 147, 256, 256);
		box7.addBox(0F, 0F, -2F, 37, 8, 2);
		box7.setPosition(-3F, 24F, 11F);
		box7.rotateAngleX = -0.22689280275926285F;

		box70 = new CustomModelRenderer(this, 201, 37, 256, 256);
		box70.addBox(0F, 0F, 0F, 7, 2, 6);
		box70.setPosition(25F, 29F, -1F);

		box71 = new CustomModelRenderer(this, 248, 86, 256, 256);
		box71.addBox(0F, 0F, 0F, 1, 16, 2);
		box71.setPosition(34F, 10F, -5F);

		box72 = new CustomModelRenderer(this, 248, 86, 256, 256);
		box72.addBox(0F, 0F, 0F, 1, 16, 2);
		box72.setPosition(34F, 10F, 3F);

		box73 = new CustomModelRenderer(this, 216, 85, 256, 256);
		box73.addBox(0F, 0F, 0F, 1, 2, 8);
		box73.setPosition(34F, 26F, -4F);

		box74 = new CustomModelRenderer(this, 63, 38, 256, 256);
		box74.addBox(0F, 0F, 0F, 55, 4, 18);
		box74.setPosition(-21F, 6F, -9F);

		box75 = new CustomModelRenderer(this, 212, 96, 256, 256);
		box75.addBox(0F, 0F, 0F, 2, 0, 8);
		box75.setPosition(34F, 9F, -4F);
		box75.rotateAngleZ = -6.213372137099813F;

		box76 = new CustomModelRenderer(this, 111, 132, 256, 256);
		box76.addBox(0F, 0F, 0F, 18, 4, 6);
		box76.setPosition(12F, 2F, -3F);

		box77 = new CustomModelRenderer(this, 111, 132, 256, 256);
		box77.addBox(0F, 0F, 0F, 18, 4, 6);
		box77.setPosition(-30F, 2F, -3F);

		box78 = new CustomModelRenderer(this, 242, 78, 256, 256);
		box78.addBox(0F, 0F, 0F, 2, 3, 4);
		box78.setPosition(34F, 6F, -2F);

		box79 = new CustomModelRenderer(this, 85, 42, 256, 256);
		box79.addBox(0F, 0F, 0F, 9, 3, 14);
		box79.setPosition(-30F, 6F, -7F);

		box8 = new CustomModelRenderer(this, 143, 8, 256, 256);
		box8.addBox(0F, 0F, 0F, 16, 3, 1);
		box8.setPosition(13F, 3F, 5F);

		box89 = new CustomModelRenderer(this, 0, 126, 256, 256);
		box89.addBox(0F, 0F, 0F, 46, 18, 2);
		box89.setPosition(-12F, 6F, 9F);

		box9 = new CustomModelRenderer(this, 21, 160, 256, 256);
		box9.addBox(0F, -5F, -1F, 4, 5, 1);
		box9.setPosition(30F, 6F, 11F);
		box9.rotateAngleX = -5.951572749300664F;
	}
	
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box89.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box36.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
