package train.client.render.models;

import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;
import train.common.core.handlers.ConfigHandler;

public class ModelTramNY extends ModelBase {

	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box100;
	public CustomModelRenderer box101;
	public CustomModelRenderer box102;
	public CustomModelRenderer box103;
	public CustomModelRenderer box104;
	public CustomModelRenderer box105;
	public CustomModelRenderer box106;
	public CustomModelRenderer box107;
	public CustomModelRenderer box108;
	public CustomModelRenderer box109;
	public CustomModelRenderer box11;
	public CustomModelRenderer box110;
	public CustomModelRenderer box111;
	public CustomModelRenderer box112;
	public CustomModelRenderer box113;
	public CustomModelRenderer box114;
	public CustomModelRenderer box115;
	public CustomModelRenderer box116;
	public CustomModelRenderer box117;
	public CustomModelRenderer box118;
	public CustomModelRenderer box12;
	public CustomModelRenderer box13;
	public CustomModelRenderer box14;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box64;
	public CustomModelRenderer box65;
	public CustomModelRenderer box66;
	public CustomModelRenderer box67;
	public CustomModelRenderer box68;
	public CustomModelRenderer box69;
	public CustomModelRenderer box7;
	public CustomModelRenderer box70;
	public CustomModelRenderer box71;
	public CustomModelRenderer box72;
	public CustomModelRenderer box73;
	public CustomModelRenderer box74;
	public CustomModelRenderer box75;
	public CustomModelRenderer box76;
	public CustomModelRenderer box77;
	public CustomModelRenderer box78;
	public CustomModelRenderer box79;
	public CustomModelRenderer box8;
	public CustomModelRenderer box80;
	public CustomModelRenderer box81;
	public CustomModelRenderer box82;
	public CustomModelRenderer box83;
	public CustomModelRenderer box84;
	public CustomModelRenderer box85;
	public CustomModelRenderer box86;
	public CustomModelRenderer box87;
	public CustomModelRenderer box88;
	public CustomModelRenderer box89;
	public CustomModelRenderer box9;
	public CustomModelRenderer box90;
	public CustomModelRenderer box91;
	public CustomModelRenderer box92;
	public CustomModelRenderer box93;
	public CustomModelRenderer box94;
	public CustomModelRenderer box95;
	public CustomModelRenderer box96;
	public CustomModelRenderer box97;
	public CustomModelRenderer box98;
	public CustomModelRenderer box99;


	public ModelTramNY() {
		box = new CustomModelRenderer(this, 59, 14, 256, 256);
		box.addBox(0F, 0F, 0F, 15, 4, 4);
		box.setPosition(-8F, 3F, 5F);

		box0 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box0.addBox(0F, 0F, 0F, 8, 7, 0);
		box0.setPosition(-31F, 0F, 5F);

		box1 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-17F, 0F, 5F);

		box10 = new CustomModelRenderer(this, 0, 38, 256, 256);
		box10.addBox(0F, -2F, 0F, 68, 2, 1);
		box10.setPosition(-34F, 32F, -4F);

		box100 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box100.addBox(0F, 0F, 0F, 0, 22, 6);
		box100.setPosition(-6F, 8F, -10F);

		box101 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box101.addBox(0F, 0F, 0F, 0, 22, 6);
		box101.setPosition(3F, 8F, -10F);

		box102 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box102.addBox(0F, 0F, 0F, 0, 22, 6);
		box102.setPosition(14F, 8F, -10F);

		box103 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box103.addBox(0F, 0F, 0F, 0, 22, 6);
		box103.setPosition(23F, 8F, -10F);

		box104 = new CustomModelRenderer(this, 0, 227, 256, 256);
		box104.addBox(0F, 0F, 0F, 0, 22, 6);
		box104.setPosition(-12F, 8F, 4F);

		box105 = new CustomModelRenderer(this, 0, 227, 256, 256);
		box105.addBox(0F, 0F, 0F, 0, 22, 6);
		box105.setPosition(-1F, 8F, 4F);

		box106 = new CustomModelRenderer(this, 0, 227, 256, 256);
		box106.addBox(0F, 0F, 0F, 0, 22, 6);
		box106.setPosition(8F, 8F, 4F);

		box107 = new CustomModelRenderer(this, 0, 227, 256, 256);
		box107.addBox(0F, 0F, 0F, 0, 22, 6);
		box107.setPosition(19F, 8F, 4F);

		box108 = new CustomModelRenderer(this, 159, 193, 256, 256);
		box108.addBox(0F, 0F, 0F, 0, 11, 5);
		box108.setPosition(-34F, 8F, 5F);
		box108.rotateAngleY = -0.17453292519943295F;

		box109 = new CustomModelRenderer(this, 173, 193, 256, 256);
		box109.addBox(0F, 0F, 0F, 0, 11, 5);
		box109.setPosition(-34F, 8F, -5F);
		box109.rotateAngleY = -2.9670597283903604F;

		box11 = new CustomModelRenderer(this, 20, 184, 256, 256);
		box11.addBox(0F, 0F, 0F, 2, 22, 1);
		box11.setPosition(-34F, 8F, 3F);

		box110 = new CustomModelRenderer(this, 173, 193, 256, 256);
		box110.addBox(0F, 0F, 0F, 0, 11, 5);
		box110.setPosition(34F, 8F, 5F);
		box110.rotateAngleY = -6.1086523819801535F;

		box111 = new CustomModelRenderer(this, 159, 193, 256, 256);
		box111.addBox(0F, 0F, 0F, 0, 11, 5);
		box111.setPosition(34F, 8F, -5F);
		box111.rotateAngleY = -3.3161255787892263F;

		box112 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box112.addBox(0F, 0F, 0F, 7, 9, 0);
		box112.setPosition(-18F, 17F, -10F);
		box112.rotateAngleX = -0.06981317007977318F;
		box112.rotateAngleY = -3.141592653589793F;

		box113 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box113.addBox(0F, 0F, 0F, 7, 9, 0);
		box113.setPosition(2F, 17F, -10F);
		box113.rotateAngleX = -0.06981317007977318F;
		box113.rotateAngleY = -3.141592653589793F;

		box114 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box114.addBox(0F, 0F, 0F, 7, 9, 0);
		box114.setPosition(22F, 17F, -10F);
		box114.rotateAngleX = -0.06981317007977318F;
		box114.rotateAngleY = -3.141592653589793F;

		box115 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box115.addBox(0F, -9F, 0F, 7, 9, 0);
		box115.setPosition(2F, 17F, -10F);
		box115.rotateAngleX = -6.178465552059927F;
		box115.rotateAngleY = -3.141592653589793F;

		box116 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box116.addBox(0F, -9F, 0F, 7, 9, 0);
		box116.setPosition(22F, 17F, -10F);
		box116.rotateAngleX = -6.178465552059927F;
		box116.rotateAngleY = -3.141592653589793F;

		box117 = new CustomModelRenderer(this, 45, 208, 256, 256);
		box117.addBox(0F, 0F, 0F, 1, 8, 1);
		box117.setPosition(-34F, 18F, -5F);

		box118 = new CustomModelRenderer(this, 20, 208, 256, 256);
		box118.addBox(0F, 0F, 0F, 1, 8, 1);
		box118.setPosition(-34F, 18F, 4F);

		box12 = new CustomModelRenderer(this, 3, 193, 256, 256);
		box12.addBox(0F, 0F, 0F, 1, 10, 6);
		box12.setPosition(-34F, 8F, 4F);

		box13 = new CustomModelRenderer(this, 54, 193, 256, 256);
		box13.addBox(0F, 0F, 0F, 1, 10, 6);
		box13.setPosition(-34F, 8F, -10F);

		box14 = new CustomModelRenderer(this, 45, 184, 256, 256);
		box14.addBox(0F, 0F, 0F, 2, 22, 1);
		box14.setPosition(-34F, 8F, -4F);

		box15 = new CustomModelRenderer(this, 3, 180, 256, 256);
		box15.addBox(0F, 0F, 0F, 1, 4, 6);
		box15.setPosition(-34F, 26F, 4F);

		box16 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box16.addBox(0F, 0F, 0F, 8, 7, 0);
		box16.setPosition(-31F, 0F, -5F);

		box17 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box17.addBox(0F, 0F, 0F, 2, 2, 12);
		box17.setPosition(-28F, 2F, -6F);

		box18 = new CustomModelRenderer(this, 55, 180, 256, 256);
		box18.addBox(0F, 0F, 0F, 1, 4, 6);
		box18.setPosition(-34F, 26F, -10F);

		box19 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box19.addBox(0F, 0F, 0F, 8, 7, 0);
		box19.setPosition(23F, 0F, -5F);

		box2 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 12);
		box2.setPosition(12F, 2F, -6F);

		box20 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 12);
		box20.setPosition(26F, 2F, -6F);

		box21 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box21.addBox(0F, 0F, 0F, 8, 7, 0);
		box21.setPosition(23F, 0F, 5F);

		box22 = new CustomModelRenderer(this, 127, 144, 256, 256);
		box22.addBox(0F, 0F, -1F, 13, 1, 1);
		box22.setPosition(-13F, 17F, 11F);
		box22.rotateAngleX = -0.06981317007977318F;

		box23 = new CustomModelRenderer(this, 150, 133, 256, 256);
		box23.addBox(0F, 1F, -1F, 3, 8, 1);
		box23.setPosition(-13F, 17F, 11F);
		box23.rotateAngleX = -0.06981317007977318F;

		box24 = new CustomModelRenderer(this, 33, 226, 256, 256);
		box24.addBox(0F, 0F, 0F, 1, 22, 7);
		box24.setPosition(-27F, 8F, 3F);

		box25 = new CustomModelRenderer(this, 0, 1, 256, 256);
		box25.addBox(0F, 0F, 0F, 6, 4, 14);
		box25.setPosition(-23F, 2F, -7F);

		box26 = new CustomModelRenderer(this, 50, 231, 256, 256);
		box26.addBox(0F, 0F, 0F, 5, 22, 0);
		box26.setPosition(-32F, 8F, 3F);

		box27 = new CustomModelRenderer(this, 140, 133, 256, 256);
		box27.addBox(0F, 1F, -1F, 3, 8, 1);
		box27.setPosition(-3F, 17F, 11F);
		box27.rotateAngleX = -0.06981317007977318F;

		box28 = new CustomModelRenderer(this, 70, 25, 256, 256);
		box28.addBox(0F, 0F, 0F, 10, 4, 7);
		box28.setPosition(-2F, 3F, -9F);

		box29 = new CustomModelRenderer(this, 150, 133, 256, 256);
		box29.addBox(0F, 1F, -1F, 3, 8, 1);
		box29.setPosition(7F, 17F, 11F);
		box29.rotateAngleX = -0.06981317007977318F;

		box3 = new CustomModelRenderer(this, 4, 169, 256, 256);
		box3.addBox(0F, 0F, 0F, 4, 4, 6);
		box3.setPosition(-33F, 27F, -3F);

		box30 = new CustomModelRenderer(this, 127, 144, 256, 256);
		box30.addBox(0F, 0F, -1F, 13, 1, 1);
		box30.setPosition(7F, 17F, 11F);
		box30.rotateAngleX = -0.06981317007977318F;

		box31 = new CustomModelRenderer(this, 140, 133, 256, 256);
		box31.addBox(0F, 1F, -1F, 3, 8, 1);
		box31.setPosition(17F, 17F, 11F);
		box31.rotateAngleX = -0.06981317007977318F;

		box32 = new CustomModelRenderer(this, 122, 133, 256, 256);
		box32.addBox(0F, 1F, -1F, 7, 8, 1);
		box32.setPosition(27F, 17F, 11F);
		box32.rotateAngleX = -0.06981317007977318F;

		box33 = new CustomModelRenderer(this, 0, 89, 256, 256);
		box33.addBox(0F, 0F, 0F, 2, 2, 10);
		box33.setPosition(33F, 7F, -5F);

		box34 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box34.addBox(0F, -9F, 0F, 7, 9, 0);
		box34.setPosition(20F, 17F, 10F);
		box34.rotateAngleX = -6.178465552059927F;

		box35 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(9F, 0F, 5F);

		box36 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box36.addBox(0F, 0F, 0F, 7, 9, 0);
		box36.setPosition(20F, 17F, 10F);
		box36.rotateAngleX = -0.06981317007977318F;

		box37 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box37.addBox(0F, 0F, 0F, 7, 9, 0);
		box37.setPosition(0F, 17F, 10F);
		box37.rotateAngleX = -0.06981317007977318F;

		box38 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box38.addBox(0F, -9F, 0F, 7, 9, 0);
		box38.setPosition(0F, 17F, 10F);
		box38.rotateAngleX = -6.178465552059927F;

		box39 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box39.addBox(0F, -9F, 0F, 7, 9, 0);
		box39.setPosition(-20F, 17F, 10F);
		box39.rotateAngleX = -6.178465552059927F;

		box4 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box4.addBox(0F, 0F, 0F, 2, 2, 12);
		box4.setPosition(-14F, 2F, -6F);

		box40 = new CustomModelRenderer(this, 34, 133, 256, 256);
		box40.addBox(0F, -9F, -1F, 13, 9, 1);
		box40.setPosition(-13F, 17F, 11F);
		box40.rotateAngleX = -6.178465552059927F;

		box41 = new CustomModelRenderer(this, 34, 133, 256, 256);
		box41.addBox(0F, -9F, -1F, 13, 9, 1);
		box41.setPosition(7F, 17F, 11F);
		box41.rotateAngleX = -6.178465552059927F;

		box42 = new CustomModelRenderer(this, 16, 133, 256, 256);
		box42.addBox(0F, -9F, -1F, 7, 9, 1);
		box42.setPosition(27F, 17F, 11F);
		box42.rotateAngleX = -6.178465552059927F;

		box43 = new CustomModelRenderer(this, 109, 144, 256, 256);
		box43.addBox(0F, 0F, -1F, 7, 1, 1);
		box43.setPosition(27F, 17F, 11F);
		box43.rotateAngleX = -0.06981317007977318F;

		box44 = new CustomModelRenderer(this, 48, 127, 256, 256);
		box44.addBox(0F, 9F, -1F, 68, 3, 1);
		box44.setPosition(-34F, 17F, 11F);
		box44.rotateAngleX = -0.06981317007977318F;

		box45 = new CustomModelRenderer(this, 180, 133, 256, 256);
		box45.addBox(0F, 1F, -1F, 2, 8, 1);
		box45.setPosition(-34F, 17F, 11F);
		box45.rotateAngleX = -0.06981317007977318F;

		box46 = new CustomModelRenderer(this, 160, 133, 256, 256);
		box46.addBox(0F, 1F, -1F, 8, 8, 1);
		box46.setPosition(-28F, 17F, 11F);
		box46.rotateAngleX = -0.06981317007977318F;

		box47 = new CustomModelRenderer(this, 81, 186, 256, 256);
		box47.addBox(0F, 0F, 0F, 7, 9, 0);
		box47.setPosition(-20F, 17F, 10F);
		box47.rotateAngleX = -0.06981317007977318F;

		box48 = new CustomModelRenderer(this, 121, 186, 256, 256);
		box48.addBox(0F, 0F, 0F, 2, 22, 1);
		box48.setPosition(32F, 8F, -4F);

		box49 = new CustomModelRenderer(this, 129, 186, 256, 256);
		box49.addBox(0F, 0F, 0F, 2, 22, 1);
		box49.setPosition(32F, 8F, 3F);

		box5 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(9F, 0F, -5F);

		box50 = new CustomModelRenderer(this, 29, 181, 256, 256);
		box50.addBox(0F, 0F, 0F, 0, 18, 6);
		box50.setPosition(32F, 9F, 3F);
		box50.rotateAngleY = -3.141592653589793F;

		box51 = new CustomModelRenderer(this, 119, 176, 256, 256);
		box51.addBox(0F, 0F, 0F, 2, 3, 6);
		box51.setPosition(32F, 27F, -3F);

		box52 = new CustomModelRenderer(this, 137, 181, 256, 256);
		box52.addBox(0F, 0F, 0F, 1, 22, 6);
		box52.setPosition(33F, 8F, 4F);

		box53 = new CustomModelRenderer(this, 105, 181, 256, 256);
		box53.addBox(0F, 0F, 0F, 1, 22, 6);
		box53.setPosition(33F, 8F, -10F);

		box54 = new CustomModelRenderer(this, 64, 145, 256, 256);
		box54.addBox(0F, -9F, -1F, 9, 9, 1);
		box54.setPosition(-25F, 17F, -11F);
		box54.rotateAngleX = -6.178465552059927F;
		box54.rotateAngleY = -3.141592653589793F;

		box55 = new CustomModelRenderer(this, 90, 164, 256, 256);
		box55.addBox(0F, 0F, -1F, 12, 1, 1);
		box55.setPosition(34F, 17F, -11F);
		box55.rotateAngleX = -0.06981317007977318F;
		box55.rotateAngleY = -3.141592653589793F;

		box56 = new CustomModelRenderer(this, 146, 164, 256, 256);
		box56.addBox(0F, 0F, -1F, 9, 1, 1);
		box56.setPosition(-25F, 17F, -11F);
		box56.rotateAngleX = -0.06981317007977318F;
		box56.rotateAngleY = -3.141592653589793F;

		box57 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box57.addBox(0F, -9F, 0F, 7, 9, 0);
		box57.setPosition(-18F, 17F, -10F);
		box57.rotateAngleX = -6.178465552059927F;
		box57.rotateAngleY = -3.141592653589793F;

		box58 = new CustomModelRenderer(this, 48, 168, 256, 256);
		box58.addBox(0F, 9F, -1F, 68, 3, 1);
		box58.setPosition(34F, 17F, -11F);
		box58.rotateAngleX = -0.06981317007977318F;
		box58.rotateAngleY = -3.141592653589793F;

		box59 = new CustomModelRenderer(this, 134, 152, 256, 256);
		box59.addBox(0F, 1F, -1F, 2, 8, 1);
		box59.setPosition(-32F, 17F, -11F);
		box59.rotateAngleX = -0.06981317007977318F;
		box59.rotateAngleY = -3.141592653589793F;

		box6 = new CustomModelRenderer(this, 3, 27, 256, 256);
		box6.addBox(0F, 0F, 0F, 18, 4, 6);
		box6.setPosition(-29F, 3F, -3F);

		box60 = new CustomModelRenderer(this, 124, 152, 256, 256);
		box60.addBox(0F, 1F, -1F, 3, 8, 1);
		box60.setPosition(-25F, 17F, -11F);
		box60.rotateAngleX = -0.06981317007977318F;
		box60.rotateAngleY = -3.141592653589793F;

		box61 = new CustomModelRenderer(this, 34, 145, 256, 256);
		box61.addBox(0F, -9F, -1F, 13, 9, 1);
		box61.setPosition(-5F, 17F, -11F);
		box61.rotateAngleX = -6.178465552059927F;
		box61.rotateAngleY = -3.141592653589793F;

		box62 = new CustomModelRenderer(this, 0, 1, 256, 256);
		box62.addBox(0F, 0F, 0F, 6, 4, 14);
		box62.setPosition(17F, 2F, -7F);

		box63 = new CustomModelRenderer(this, 188, 11, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-17F, 0F, -5F);

		box64 = new CustomModelRenderer(this, 29, 181, 256, 256);
		box64.addBox(0F, 0F, 0F, 0, 18, 6);
		box64.setPosition(-32F, 9F, -3F);

		box65 = new CustomModelRenderer(this, 0, 89, 256, 256);
		box65.addBox(0F, 0F, 0F, 2, 2, 10);
		box65.setPosition(-35F, 7F, -5F);

		box66 = new CustomModelRenderer(this, 65, 247, 256, 256);
		box66.addBox(0F, 0F, 0F, 72, 3, 4);
		box66.setPosition(-36F, 4F, -2F);

		box67 = new CustomModelRenderer(this, 34, 145, 256, 256);
		box67.addBox(0F, -9F, -1F, 13, 9, 1);
		box67.setPosition(15F, 17F, -11F);
		box67.rotateAngleX = -6.178465552059927F;
		box67.rotateAngleY = -3.141592653589793F;

		box68 = new CustomModelRenderer(this, 5, 145, 256, 256);
		box68.addBox(0F, -9F, -1F, 12, 9, 1);
		box68.setPosition(34F, 17F, -11F);
		box68.rotateAngleX = -6.178465552059927F;
		box68.rotateAngleY = -3.141592653589793F;

		box69 = new CustomModelRenderer(this, 0, 46, 256, 256);
		box69.addBox(0F, -2F, 0F, 63, 2, 6);
		box69.setPosition(-29F, 32F, -3F);

		box7 = new CustomModelRenderer(this, 157, 144, 256, 256);
		box7.addBox(0F, 0F, -1F, 14, 1, 1);
		box7.setPosition(-34F, 17F, 11F);
		box7.rotateAngleX = -0.06981317007977318F;

		box70 = new CustomModelRenderer(this, 117, 164, 256, 256);
		box70.addBox(0F, 0F, -1F, 13, 1, 1);
		box70.setPosition(15F, 17F, -11F);
		box70.rotateAngleX = -0.06981317007977318F;
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new CustomModelRenderer(this, 117, 164, 256, 256);
		box71.addBox(0F, 0F, -1F, 13, 1, 1);
		box71.setPosition(-5F, 17F, -11F);
		box71.rotateAngleX = -0.06981317007977318F;
		box71.rotateAngleY = -3.141592653589793F;

		box72 = new CustomModelRenderer(this, 1, 55, 256, 256);
		box72.addBox(0F, -2F, 0F, 68, 2, 7);
		box72.setPosition(-34F, 32F, 4F);
		box72.rotateAngleX = -5.82939970166106F;

		box73 = new CustomModelRenderer(this, 114, 152, 256, 256);
		box73.addBox(0F, 1F, -1F, 3, 8, 1);
		box73.setPosition(-15F, 17F, -11F);
		box73.rotateAngleX = -0.06981317007977318F;
		box73.rotateAngleY = -3.141592653589793F;

		box74 = new CustomModelRenderer(this, 0, 65, 256, 256);
		box74.addBox(0F, 0F, 0F, 66, 2, 20);
		box74.setPosition(-33F, 7F, -10F);

		box75 = new CustomModelRenderer(this, 124, 152, 256, 256);
		box75.addBox(0F, 1F, -1F, 3, 8, 1);
		box75.setPosition(-5F, 17F, -11F);
		box75.rotateAngleX = -0.06981317007977318F;
		box75.rotateAngleY = -3.141592653589793F;

		box76 = new CustomModelRenderer(this, 114, 152, 256, 256);
		box76.addBox(0F, 1F, -1F, 3, 8, 1);
		box76.setPosition(5F, 17F, -11F);
		box76.rotateAngleX = -0.06981317007977318F;
		box76.rotateAngleY = -3.141592653589793F;

		box77 = new CustomModelRenderer(this, 124, 152, 256, 256);
		box77.addBox(0F, 1F, -1F, 3, 8, 1);
		box77.setPosition(15F, 17F, -11F);
		box77.rotateAngleX = -0.06981317007977318F;
		box77.rotateAngleY = -3.141592653589793F;

		box78 = new CustomModelRenderer(this, 3, 27, 256, 256);
		box78.addBox(0F, 0F, 0F, 18, 4, 6);
		box78.setPosition(11F, 3F, -3F);

		box79 = new CustomModelRenderer(this, 90, 152, 256, 256);
		box79.addBox(0F, 1F, -1F, 2, 8, 1);
		box79.setPosition(34F, 17F, -11F);
		box79.rotateAngleX = -0.06981317007977318F;
		box79.rotateAngleY = -3.141592653589793F;

		box8 = new CustomModelRenderer(this, 1, 55, 256, 256);
		box8.addBox(0F, -2F, 0F, 68, 2, 7);
		box8.setPosition(34F, 32F, -4F);
		box8.rotateAngleX = -5.846852994181004F;
		box8.rotateAngleY = -3.141592653589793F;

		box80 = new CustomModelRenderer(this, 98, 152, 256, 256);
		box80.addBox(0F, 1F, -1F, 6, 8, 1);
		box80.setPosition(28F, 17F, -11F);
		box80.rotateAngleX = -0.06981317007977318F;
		box80.rotateAngleY = -3.141592653589793F;

		box81 = new CustomModelRenderer(this, 84, 223, 256, 256);
		box81.addBox(0F, 0F, -5F, 11, 2, 5);
		box81.setPosition(-6F, 11F, -10F);
		box81.rotateAngleX = -6.213372137099813F;
		box81.rotateAngleY = -3.141592653589793F;

		box82 = new CustomModelRenderer(this, 84, 216, 256, 256);
		box82.addBox(0F, 3F, 1F, 11, 5, 1);
		box82.setPosition(-6F, 10F, -7F);
		box82.rotateAngleX = -6.09119908946021F;
		box82.rotateAngleY = -3.141592653589793F;

		box83 = new CustomModelRenderer(this, 84, 223, 256, 256);
		box83.addBox(0F, 0F, -5F, 11, 2, 5);
		box83.setPosition(8F, 11F, 10F);
		box83.rotateAngleX = -6.213372137099813F;

		box84 = new CustomModelRenderer(this, 84, 216, 256, 256);
		box84.addBox(0F, 3F, 1F, 11, 5, 1);
		box84.setPosition(14F, 10F, -7F);
		box84.rotateAngleX = -6.09119908946021F;
		box84.rotateAngleY = -3.141592653589793F;

		box85 = new CustomModelRenderer(this, 118, 216, 256, 256);
		box85.addBox(0F, 3F, 1F, 6, 5, 1);
		box85.setPosition(-26F, 10F, -7F);
		box85.rotateAngleX = -6.09119908946021F;
		box85.rotateAngleY = -3.141592653589793F;

		box86 = new CustomModelRenderer(this, 118, 223, 256, 256);
		box86.addBox(0F, 0F, -5F, 6, 2, 5);
		box86.setPosition(-26F, 11F, -10F);
		box86.rotateAngleX = -6.213372137099813F;
		box86.rotateAngleY = -3.141592653589793F;

		box87 = new CustomModelRenderer(this, 142, 223, 256, 256);
		box87.addBox(0F, 0F, -5F, 5, 2, 5);
		box87.setPosition(28F, 11F, -10F);
		box87.rotateAngleX = -6.213372137099813F;
		box87.rotateAngleY = -3.141592653589793F;

		box88 = new CustomModelRenderer(this, 143, 216, 256, 256);
		box88.addBox(0F, 3F, 1F, 5, 5, 1);
		box88.setPosition(28F, 10F, -7F);
		box88.rotateAngleX = -6.09119908946021F;
		box88.rotateAngleY = -3.141592653589793F;

		box89 = new CustomModelRenderer(this, 84, 216, 256, 256);
		box89.addBox(0F, 3F, 1F, 11, 5, 1);
		box89.setPosition(8F, 10F, 7F);
		box89.rotateAngleX = -6.09119908946021F;

		box9 = new CustomModelRenderer(this, 0, 42, 256, 256);
		box9.addBox(0F, -2F, 0F, 68, 2, 1);
		box9.setPosition(-34F, 32F, 3F);

		box90 = new CustomModelRenderer(this, 64, 133, 256, 256);
		box90.addBox(0F, -9F, -1F, 14, 9, 1);
		box90.setPosition(-34F, 17F, 11F);
		box90.rotateAngleX = -6.178465552059927F;

		box91 = new CustomModelRenderer(this, 84, 223, 256, 256);
		box91.addBox(0F, 0F, -5F, 11, 2, 5);
		box91.setPosition(14F, 11F, -10F);
		box91.rotateAngleX = -6.213372137099813F;
		box91.rotateAngleY = -3.141592653589793F;

		box92 = new CustomModelRenderer(this, 84, 223, 256, 256);
		box92.addBox(0F, 0F, -5F, 11, 2, 5);
		box92.setPosition(-12F, 11F, 10F);
		box92.rotateAngleX = -6.213372137099813F;

		box93 = new CustomModelRenderer(this, 84, 216, 256, 256);
		box93.addBox(0F, 3F, 1F, 11, 5, 1);
		box93.setPosition(-12F, 10F, 7F);
		box93.rotateAngleX = -6.09119908946021F;

		box94 = new CustomModelRenderer(this, 143, 216, 256, 256);
		box94.addBox(0F, 3F, 1F, 5, 5, 1);
		box94.setPosition(-26F, 10F, 7F);
		box94.rotateAngleX = -6.09119908946021F;

		box95 = new CustomModelRenderer(this, 142, 223, 256, 256);
		box95.addBox(0F, 0F, -5F, 5, 2, 5);
		box95.setPosition(-26F, 11F, 10F);
		box95.rotateAngleX = -6.213372137099813F;

		box96 = new CustomModelRenderer(this, 64, 233, 256, 256);
		box96.addBox(0F, 0F, 0F, 2, 2, 6);
		box96.setPosition(-33F, 15F, 4F);

		box97 = new CustomModelRenderer(this, 0, 227, 256, 256);
		box97.addBox(0F, 0F, 0F, 0, 22, 6);
		box97.setPosition(-21F, 8F, 4F);

		box98 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box98.addBox(0F, 0F, 0F, 0, 22, 6);
		box98.setPosition(-26F, 8F, -10F);

		box99 = new CustomModelRenderer(this, 17, 227, 256, 256);
		box99.addBox(0F, 0F, 0F, 0, 22, 6);
		box99.setPosition(-17F, 8F, -10F);

	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		if (ConfigHandler.FLICKERING) {
			super.render(entity, f, f1, f2, f3, f4, f5);
		}
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box100.render(f5);
		box101.render(f5);
		box102.render(f5);
		box103.render(f5);
		box104.render(f5);
		box105.render(f5);
		box106.render(f5);
		box107.render(f5);
		box108.render(f5);
		box109.render(f5);
		box11.render(f5);
		box110.render(f5);
		box111.render(f5);
		box112.render(f5);
		box113.render(f5);
		box114.render(f5);
		box115.render(f5);
		box116.render(f5);
		box117.render(f5);
		box118.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box71.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box80.render(f5);
		box81.render(f5);
		box82.render(f5);
		box83.render(f5);
		box84.render(f5);
		box85.render(f5);
		box86.render(f5);
		box87.render(f5);
		box88.render(f5);
		box89.render(f5);
		box9.render(f5);
		box90.render(f5);
		box91.render(f5);
		box92.render(f5);
		box93.render(f5);
		box94.render(f5);
		box95.render(f5);
		box96.render(f5);
		box97.render(f5);
		box98.render(f5);
		box99.render(f5);

	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}
