package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;
import train.common.core.handlers.ConfigHandler;

public class ModelSD70 extends ModelBase {
	
	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box100;
	public CustomModelRenderer box101;
	public CustomModelRenderer box102;
	public CustomModelRenderer box103;
	public CustomModelRenderer box104;
	public CustomModelRenderer box105;
	public CustomModelRenderer box106;
	public CustomModelRenderer box107;
	public CustomModelRenderer box108;
	public CustomModelRenderer box109;
	public CustomModelRenderer box11;
	public CustomModelRenderer box110;
	public CustomModelRenderer box111;
	public CustomModelRenderer box112;
	public CustomModelRenderer box113;
	public CustomModelRenderer box114;
	public CustomModelRenderer box115;
	public CustomModelRenderer box116;
	public CustomModelRenderer box117;
	public CustomModelRenderer box118;
	public CustomModelRenderer box119;
	public CustomModelRenderer box12;
	public CustomModelRenderer box120;
	public CustomModelRenderer box121;
	public CustomModelRenderer box122;
	public CustomModelRenderer box123;
	public CustomModelRenderer box124;
	public CustomModelRenderer box125;
	public CustomModelRenderer box126;
	public CustomModelRenderer box128;
	public CustomModelRenderer box13;
	public CustomModelRenderer box131;
	public CustomModelRenderer box132;
	public CustomModelRenderer box134;
	public CustomModelRenderer box14;
	public CustomModelRenderer box143;
	public CustomModelRenderer box148;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box68;
	public CustomModelRenderer box69;
	public CustomModelRenderer box7;
	public CustomModelRenderer box70;
	public CustomModelRenderer box72;
	public CustomModelRenderer box73;
	public CustomModelRenderer box74;
	public CustomModelRenderer box75;
	public CustomModelRenderer box76;
	public CustomModelRenderer box77;
	public CustomModelRenderer box78;
	public CustomModelRenderer box79;
	public CustomModelRenderer box8;
	public CustomModelRenderer box80;
	public CustomModelRenderer box81;
	public CustomModelRenderer box82;
	public CustomModelRenderer box83;
	public CustomModelRenderer box84;
	public CustomModelRenderer box85;
	public CustomModelRenderer box87;
	public CustomModelRenderer box88;
	public CustomModelRenderer box89;
	public CustomModelRenderer box9;
	public CustomModelRenderer box90;
	public CustomModelRenderer box91;
	public CustomModelRenderer box92;
	public CustomModelRenderer box93;
	public CustomModelRenderer box94;
	public CustomModelRenderer box95;
	public CustomModelRenderer box96;
	public CustomModelRenderer box97;
	public CustomModelRenderer box98;
	public CustomModelRenderer box99;

	public ModelSD70() {
		box = new CustomModelRenderer(this, 0, 2, 256, 256);
		box.addBox(0F, 0F, 0F, 1, 6, 20);
		box.setPosition(5F, 0F, -30F);

		box0 = new CustomModelRenderer(this, 45, 2, 256, 256);
		box0.addBox(0F, 0F, 0F, 1, 4, 22);
		box0.setPosition(6F, 2F, -31F);

		box1 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box1.addBox(0F, 0F, 0F, 16, 2, 2);
		box1.setPosition(-8F, 2F, -28F);

		box10 = new CustomModelRenderer(this, 0, 2, 256, 256);
		box10.addBox(0F, 0F, 0F, 1, 6, 20);
		box10.setPosition(5F, 0F, 10F);

		box100 = new CustomModelRenderer(this, 211, 42, 256, 256);
		box100.addBox(0F, 0F, 0F, 5, 1, 12);
		box100.setPosition(-5F, 32F, -25F);
		box100.rotateAngleZ = -2.6878070480712677F;

		box101 = new CustomModelRenderer(this, 203, 44, 256, 256);
		box101.addBox(0F, 0F, 0F, 5, 1, 1);
		box101.setPosition(-5F, 32F, -26F);
		box101.rotateAngleX = -6.213372137099813F;
		box101.rotateAngleY = 6.09119908946021F;
		box101.rotateAngleZ = -2.6878070480712677F;

		box102 = new CustomModelRenderer(this, 111, 82, 256, 256);
		box102.addBox(2F, 0F, 0F, 6, 1, 1);
		box102.setPosition(-9F, 30F, -25F);
		box102.rotateAngleY = -6.161012259539984F;

		box103 = new CustomModelRenderer(this, 111, 86, 256, 256);
		box103.addBox(2F, 0F, 0F, 6, 1, 1);
		box103.setPosition(9F, 31F, -25F);
		box103.rotateAngleY = 0.12217304763960307F;
		box103.rotateAngleZ = 3.141592653589793F;

		box104 = new CustomModelRenderer(this, 68, 62, 256, 256);
		box104.addBox(0F, 0F, 0F, 2, 3, 1);
		box104.setPosition(-1F, 26F, 34F);

		box105 = new CustomModelRenderer(this, 64, 67, 256, 256);
		box105.addBox(0F, 0F, 0F, 4, 2, 1);
		box105.setPosition(-2F, 29F, -27F);

		box106 = new CustomModelRenderer(this, 66, 72, 256, 256);
		box106.addBox(0F, 0F, 0F, 5, 2, 0);
		box106.setPosition(-7F, 29F, -26F);
		box106.rotateAngleY = -6.09119908946021F;

		box107 = new CustomModelRenderer(this, 66, 75, 256, 256);
		box107.addBox(0F, 0F, 0F, 5, 2, 0);
		box107.setPosition(2F, 29F, -27F);
		box107.rotateAngleY = -0.19198621771937624F;

		box108 = new CustomModelRenderer(this, 184, 63, 256, 256);
		box108.addBox(0F, 0F, 0F, 16, 2, 1);
		box108.setPosition(-8F, 28F, -14F);

		box109 = new CustomModelRenderer(this, 185, 67, 256, 256);
		box109.addBox(0F, 0F, 0F, 14, 1, 1);
		box109.setPosition(-7F, 30F, -14F);

		box11 = new CustomModelRenderer(this, 1, 29, 256, 256);
		box11.addBox(0F, 0F, 0F, 12, 2, 1);
		box11.setPosition(-6F, 3F, 9F);

		box110 = new CustomModelRenderer(this, 110, 56, 256, 256);
		box110.addBox(0F, 0F, 0F, 16, 14, 1);
		box110.setPosition(-8F, 10F, -14F);

		box111 = new CustomModelRenderer(this, 172, 2, 256, 256);
		box111.addBox(0F, 0F, 0F, 12, 4, 1);
		box111.setPosition(-6F, 24F, -14F);

		box112 = new CustomModelRenderer(this, 238, 75, 256, 256);
		box112.addBox(0F, 0F, 0F, 5, 21, 1);
		box112.setPosition(5F, 10F, 31F);
		box112.rotateAngleY = -2.4958208303518914F;

		box113 = new CustomModelRenderer(this, 224, 75, 256, 256);
		box113.addBox(0F, 0F, 0F, 5, 21, 1);
		box113.setPosition(-5F, 31F, 31F);
		box113.rotateAngleX = -3.141592653589793F;
		box113.rotateAngleY = -0.6457718232379019F;

		box114 = new CustomModelRenderer(this, 215, 75, 256, 256);
		box114.addBox(0F, 0F, 0F, 2, 21, 1);
		box114.setPosition(-1F, 10F, 33F);

		box115 = new CustomModelRenderer(this, 200, 77, 256, 256);
		box115.addBox(0F, 0F, 0F, 6, 1, 1);
		box115.setPosition(-3F, 30F, 31F);

		box116 = new CustomModelRenderer(this, 202, 80, 256, 256);
		box116.addBox(0F, 0F, 0F, 4, 1, 1);
		box116.setPosition(-2F, 30F, 32F);

		box117 = new CustomModelRenderer(this, 171, 100, 256, 256);
		box117.addBox(0F, 0F, 0F, 10, 20, 29);
		box117.setPosition(-5F, 10F, 1F);

		box118 = new CustomModelRenderer(this, 176, 74, 256, 256);
		box118.addBox(0F, 0F, 0F, 10, 21, 1);
		box118.setPosition(-5F, 10F, 30F);

		box119 = new CustomModelRenderer(this, 108, 130, 256, 256);
		box119.addBox(0F, 0F, 0F, 14, 1, 14);
		box119.setPosition(-7F, 30F, 16F);

		box12 = new CustomModelRenderer(this, 1, 29, 256, 256);
		box12.addBox(0F, 0F, 0F, 12, 2, 1);
		box12.setPosition(-6F, 3F, 30F);

		box120 = new CustomModelRenderer(this, 172, 151, 256, 256);
		box120.addBox(0F, 0F, 0F, 2, 6, 14);
		box120.setPosition(7F, 30F, 16F);
		box120.rotateAngleZ = -3.473205211468716F;

		box121 = new CustomModelRenderer(this, 207, 151, 256, 256);
		box121.addBox(0F, 0F, 0F, 2, 6, 14);
		box121.setPosition(-7F, 30F, 30F);
		box121.rotateAngleX = -3.141592653589793F;
		box121.rotateAngleZ = -5.969026041820607F;

		box122 = new CustomModelRenderer(this, 103, 152, 256, 256);
		box122.addBox(0F, 0F, 0F, 6, 1, 6);
		box122.setPosition(-3F, 31F, 17F);

		box123 = new CustomModelRenderer(this, 128, 152, 256, 256);
		box123.addBox(0F, 0F, 0F, 6, 1, 6);
		box123.setPosition(-3F, 31F, 24F);

		box124 = new CustomModelRenderer(this, 2, 64, 256, 256);
		box124.addBox(0F, 0F, 0F, 4, 1, 1);
		box124.setPosition(-2F, 30F, 7F);

		box125 = new CustomModelRenderer(this, 2, 67, 256, 256);
		box125.addBox(0F, 0F, 0F, 1, 1, 4);
		box125.setPosition(1F, 31F, 6F);

		box126 = new CustomModelRenderer(this, 2, 73, 256, 256);
		box126.addBox(0F, 0F, 0F, 1, 1, 4);
		box126.setPosition(-2F, 31F, 5F);

		box128 = new CustomModelRenderer(this, 155, 101, 256, 256);
		box128.addBox(0F, 0F, 0F, 18, 6, 4);
		box128.setPosition(-9F, 10F, -13F);

		box13 = new CustomModelRenderer(this, 45, 2, 256, 256);
		box13.addBox(0F, 0F, 0F, 1, 4, 22);
		box13.setPosition(6F, 2F, 9F);

		box131 = new CustomModelRenderer(this, 42, 199, 256, 256);
		box131.addBox(0F, 0F, 0F, 0, 9, 41);
		box131.setPosition(-9F, 10F, -9F);

		box132 = new CustomModelRenderer(this, 78, 192, 256, 256);
		box132.addBox(0F, 0F, 0F, 18, 1, 5);
		box132.setPosition(9F, 23F, -11F);
		box132.rotateAngleX = -4.153883619746504F;
		box132.rotateAngleY = -3.141592653589793F;

		box134 = new CustomModelRenderer(this, 81, 199, 256, 256);
		box134.addBox(0F, 0F, 0F, 18, 1, 2);
		box134.setPosition(-9F, 22F, -13F);

		box14 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box14.addBox(0F, 0F, 0F, 16, 2, 2);
		box14.setPosition(-8F, 2F, 19F);

		box143 = new CustomModelRenderer(this, 4, 129, 256, 256);
		box143.addBox(0F, 0F, 0F, 7, 1, 0);
		box143.setPosition(-6F, 19F, -35F);
		box143.rotateAngleZ = -2.0245819323134224F;

		box148 = new CustomModelRenderer(this, 4, 129, 256, 256);
		box148.addBox(0F, 0F, 0F, 7, 1, 0);
		box148.setPosition(6F, 19F, 35F);
		box148.rotateAngleX = -3.141592653589793F;
		box148.rotateAngleZ = -1.117010721276371F;

		box15 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box15.addBox(0F, 0F, 0F, 16, 2, 2);
		box15.setPosition(-8F, 2F, 26F);

		box16 = new CustomModelRenderer(this, 45, 2, 256, 256);
		box16.addBox(0F, 0F, 0F, 1, 4, 22);
		box16.setPosition(-7F, 2F, 9F);

		box17 = new CustomModelRenderer(this, 0, 33, 256, 256);
		box17.addBox(0F, 0F, 0F, 8, 3, 18);
		box17.setPosition(-4F, 4F, -29F);

		box18 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box18.addBox(0F, 0F, 0F, 2, 2, 2);
		box18.setPosition(6F, 5F, -26F);

		box19 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box19.addBox(0F, 0F, 0F, 2, 2, 2);
		box19.setPosition(6F, 5F, -19F);

		box2 = new CustomModelRenderer(this, 0, 2, 256, 256);
		box2.addBox(0F, 0F, 0F, 1, 6, 20);
		box2.setPosition(-6F, 0F, -30F);

		box20 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box20.addBox(0F, 0F, 0F, 2, 2, 2);
		box20.setPosition(6F, 5F, 24F);

		box21 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box21.addBox(0F, 0F, 0F, 2, 2, 2);
		box21.setPosition(6F, 5F, 17F);

		box22 = new CustomModelRenderer(this, 0, 33, 256, 256);
		box22.addBox(0F, 0F, 0F, 8, 3, 18);
		box22.setPosition(-4F, 4F, 11F);

		box23 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box23.addBox(0F, 0F, 0F, 2, 2, 2);
		box23.setPosition(-8F, 5F, 17F);

		box24 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box24.addBox(0F, 0F, 0F, 2, 2, 2);
		box24.setPosition(-8F, 5F, 24F);

		box25 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box25.addBox(0F, 0F, 0F, 2, 2, 2);
		box25.setPosition(-8F, 5F, -19F);

		box26 = new CustomModelRenderer(this, 1, 33, 256, 256);
		box26.addBox(0F, 0F, 0F, 2, 2, 2);
		box26.setPosition(-8F, 5F, -26F);

		box27 = new CustomModelRenderer(this, 0, 66, 256, 256);
		box27.addBox(0F, 0F, 0F, 18, 3, 16);
		box27.setPosition(-9F, 5F, -8F);

		box28 = new CustomModelRenderer(this, 67, 70, 256, 256);
		box28.addBox(0F, 0F, 0F, 1, 5, 16);
		box28.setPosition(-9F, 5F, 8F);
		box28.rotateAngleX = -3.141592653589793F;
		box28.rotateAngleZ = -5.6374134839416845F;

		box29 = new CustomModelRenderer(this, 2, 88, 256, 256);
		box29.addBox(0F, 0F, 0F, 12, 1, 16);
		box29.setPosition(-6F, 1F, -8F);

		box3 = new CustomModelRenderer(this, 45, 2, 256, 256);
		box3.addBox(0F, 0F, 0F, 1, 4, 22);
		box3.setPosition(-7F, 2F, -31F);

		box30 = new CustomModelRenderer(this, 67, 70, 256, 256);
		box30.addBox(0F, 0F, 0F, 1, 5, 16);
		box30.setPosition(9F, 5F, -8F);
		box30.rotateAngleZ = -3.7873644768276953F;

		box31 = new CustomModelRenderer(this, 110, 73, 256, 256);
		box31.addBox(-1F, 0F, 0F, 8, 2, 1);
		box31.setPosition(-8F, 28F, -25F);
		box31.rotateAngleY = -6.14355896702004F;

		box32 = new CustomModelRenderer(this, 75, 62, 256, 256);
		box32.addBox(0F, 0F, 0F, 2, 3, 1);
		box32.setPosition(3F, 10F, -36F);

		box33 = new CustomModelRenderer(this, 75, 62, 256, 256);
		box33.addBox(0F, 0F, 0F, 2, 3, 1);
		box33.setPosition(-5F, 10F, -36F);

		box34 = new CustomModelRenderer(this, 2, 219, 256, 256);
		box34.addBox(0F, 0F, 0F, 12, 1, 16);
		box34.setPosition(-6F, 2F, -8F);

		box35 = new CustomModelRenderer(this, 1, 202, 256, 256);
		box35.addBox(0F, 0F, 0F, 14, 1, 16);
		box35.setPosition(-7F, 3F, -8F);

		box36 = new CustomModelRenderer(this, 1, 184, 256, 256);
		box36.addBox(0F, 0F, 0F, 16, 1, 16);
		box36.setPosition(-8F, 4F, -8F);

		box37 = new CustomModelRenderer(this, 48, 38, 256, 256);
		box37.addBox(0F, 0F, 0F, 18, 2, 1);
		box37.setPosition(-9F, 7F, 8F);

		box38 = new CustomModelRenderer(this, 48, 38, 256, 256);
		box38.addBox(0F, 0F, 0F, 18, 1, 1);
		box38.setPosition(-9F, 8F, -7F);

		box39 = new CustomModelRenderer(this, 48, 38, 256, 256);
		box39.addBox(0F, 0F, 0F, 18, 2, 1);
		box39.setPosition(-9F, 7F, -23F);

		box4 = new CustomModelRenderer(this, 1, 29, 256, 256);
		box4.addBox(0F, 0F, 0F, 12, 2, 1);
		box4.setPosition(-6F, 3F, -31F);

		box40 = new CustomModelRenderer(this, 48, 38, 256, 256);
		box40.addBox(0F, 0F, 0F, 18, 2, 1);
		box40.setPosition(-9F, 7F, 22F);

		box41 = new CustomModelRenderer(this, 1, 104, 256, 256);
		box41.addBox(0F, 0F, 0F, 18, 1, 64);
		box41.setPosition(-9F, 9F, -32F);

		box42 = new CustomModelRenderer(this, 57, 184, 256, 256);
		box42.addBox(0F, 0F, 0F, 10, 2, 70);
		box42.setPosition(-5F, 7F, -35F);

		box43 = new CustomModelRenderer(this, 78, 173, 256, 256);
		box43.addBox(0F, 0F, 0F, 4, 2, 78);
		box43.setPosition(-2F, 6F, -39F);

		box44 = new CustomModelRenderer(this, 37, 109, 256, 256);
		box44.addBox(0F, 0F, 0F, 10, 1, 3);
		box44.setPosition(-5F, 9F, 32F);

		box45 = new CustomModelRenderer(this, 105, 211, 256, 256);
		box45.addBox(0F, 0F, 0F, 8, 6, 2);
		box45.setPosition(-4F, 19F, -26F);

		box46 = new CustomModelRenderer(this, 21, 109, 256, 256);
		box46.addBox(0F, 0F, 0F, 6, 1, 1);
		box46.setPosition(-1F, 9F, 37F);
		box46.rotateAngleX = -3.141592653589793F;
		box46.rotateAngleY = 0.15707963267948966F;
		box46.rotateAngleZ = -3.141592653589793F;

		box47 = new CustomModelRenderer(this, 4, 129, 256, 256);
		box47.addBox(0F, 0F, 0F, 7, 1, 0);
		box47.setPosition(-6F, 19F, 35F);
		box47.rotateAngleZ = -2.0245819323134224F;

		box48 = new CustomModelRenderer(this, 21, 109, 256, 256);
		box48.addBox(0F, 0F, 0F, 6, 1, 1);
		box48.setPosition(1F, 10F, 37F);
		box48.rotateAngleX = -3.141592653589793F;
		box48.rotateAngleY = -6.126105674500097F;

		box49 = new CustomModelRenderer(this, 65, 218, 256, 256);
		box49.addBox(0F, 0F, 0F, 18, 19, 0);
		box49.setPosition(-9F, 0F, -35F);

		box5 = new CustomModelRenderer(this, 1, 29, 256, 256);
		box5.addBox(0F, 0F, 0F, 12, 2, 1);
		box5.setPosition(-6F, 3F, -10F);

		box50 = new CustomModelRenderer(this, 5, 112, 256, 256);
		box50.addBox(0F, 0F, 0F, 14, 1, 1);
		box50.setPosition(-7F, 9F, 35F);

		box51 = new CustomModelRenderer(this, 65, 218, 256, 256);
		box51.addBox(0F, 0F, 0F, 18, 19, 0);
		box51.setPosition(-9F, 0F, 35F);

		box52 = new CustomModelRenderer(this, 37, 109, 256, 256);
		box52.addBox(0F, 0F, 0F, 10, 1, 3);
		box52.setPosition(-5F, 9F, -35F);

		box53 = new CustomModelRenderer(this, 5, 112, 256, 256);
		box53.addBox(0F, 0F, 0F, 14, 1, 1);
		box53.setPosition(-7F, 9F, -36F);

		box54 = new CustomModelRenderer(this, 90, 176, 256, 256);
		box54.addBox(0F, 0F, 0F, 2, 1, 74);
		box54.setPosition(-1F, 9F, -37F);

		box55 = new CustomModelRenderer(this, 21, 109, 256, 256);
		box55.addBox(0F, 0F, 0F, 6, 1, 1);
		box55.setPosition(1F, 9F, -37F);
		box55.rotateAngleY = -0.13962634015954636F;

		box56 = new CustomModelRenderer(this, 21, 109, 256, 256);
		box56.addBox(0F, 0F, 0F, 6, 1, 1);
		box56.setPosition(-1F, 10F, -37F);
		box56.rotateAngleX = -3.141592653589793F;
		box56.rotateAngleY = -2.9845130209103035F;

		box57 = new CustomModelRenderer(this, 4, 119, 256, 256);
		box57.addBox(0F, 0F, 0F, 18, 7, 1);
		box57.setPosition(-9F, 2F, 31F);

		box58 = new CustomModelRenderer(this, 131, 179, 256, 256);
		box58.addBox(0F, 0F, 0F, 16, 0, 70);
		box58.setPosition(-8F, 2F, -35F);

		box59 = new CustomModelRenderer(this, 4, 119, 256, 256);
		box59.addBox(0F, 0F, 0F, 18, 7, 1);
		box59.setPosition(-9F, 2F, -32F);

		box6 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box6.addBox(0F, 0F, 0F, 16, 2, 2);
		box6.setPosition(-8F, 2F, -21F);

		box60 = new CustomModelRenderer(this, 99, 179, 256, 256);
		box60.addBox(0F, 0F, 0F, 16, 0, 70);
		box60.setPosition(-8F, 6F, -35F);

		box61 = new CustomModelRenderer(this, 42, 199, 256, 256);
		box61.addBox(0F, 0F, 0F, 0, 9, 41);
		box61.setPosition(9F, 10F, -9F);

		box62 = new CustomModelRenderer(this, 4, 129, 256, 256);
		box62.addBox(0F, 0F, 0F, 7, 1, 0);
		box62.setPosition(6F, 19F, -35F);
		box62.rotateAngleX = -3.141592653589793F;
		box62.rotateAngleZ = -1.117010721276371F;

		box63 = new CustomModelRenderer(this, 39, 138, 256, 256);
		box63.addBox(0F, 0F, 0F, 4, 1, 2);
		box63.setPosition(-2F, 30F, 12F);

		box68 = new CustomModelRenderer(this, 77, 171, 256, 256);
		box68.addBox(0F, 0F, 0F, 18, 13, 6);
		box68.setPosition(-9F, 10F, -31F);

		box69 = new CustomModelRenderer(this, 122, 18, 256, 256);
		box69.addBox(0F, 0F, 0F, 6, 1, 5);
		box69.setPosition(-3.2F, 25F, -26.2F);
		box69.rotateAngleX = 5.8817595792208905F;
		box69.rotateAngleY = -4.9505895925855405F;
		box69.rotateAngleZ = 3.141592653589793F;


		box7 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box7.addBox(0F, 0F, 0F, 16, 2, 2);
		box7.setPosition(-8F, 2F, -14F);

		box70 = new CustomModelRenderer(this, 103, 22, 256, 256);
		box70.addBox(0F, 0F, 0F, 8, 13, 1);
		box70.setPosition(-9F, 10F, -31F);
		box70.rotateAngleY = -6.03883921190038F;

		box72 = new CustomModelRenderer(this, 121, 25, 256, 256);
		box72.addBox(0F, 0F, 0F, 5, 1, 6);
		box72.setPosition(9F, 23F, -31F);
		box72.rotateAngleX = 3.141592653589793F;
		box72.rotateAngleY = -3.385938748868999F;
		box72.rotateAngleZ = 5.8817595792208905F;

		box73 = new CustomModelRenderer(this, 103, 8, 256, 256);
		box73.addBox(0F, 0F, 0F, 8, 13, 1);
		box73.setPosition(9F, 23F, -31F);
		box73.rotateAngleY = 0.22689280275926285F;
		box73.rotateAngleZ = 3.141592653589793F;

		box74 = new CustomModelRenderer(this, 98, 1, 256, 256);
		box74.addBox(0F, 0F, 0F, 8, 1, 6);
		box74.setPosition(-4F, 24F, -32F);

		box75 = new CustomModelRenderer(this, 128, 1, 256, 256);
		box75.addBox(0F, 0F, 0F, 4, 15, 1);
		box75.setPosition(-2F, 10F, -33F);

		box76 = new CustomModelRenderer(this, 131, 33, 256, 256);
		box76.addBox(0F, 0F, 0F, 3, 1, 1);
		box76.setPosition(2F, 24F, -33F);
		box76.rotateAngleY = -0.3141592653589793F;
		box76.rotateAngleZ = 0.03490658503988659F;

		box77 = new CustomModelRenderer(this, 131, 35, 256, 256);
		box77.addBox(0F, 0F, 0F, 3, 1, 1);
		box77.setPosition(-2F, 25F, -33F);
		box77.rotateAngleX = -3.141592653589793F;
		box77.rotateAngleY = -2.827433388230814F;
		box77.rotateAngleZ = -0.03490658503988659F;

		box78 = new CustomModelRenderer(this, 131, 37, 256, 256);
		box78.addBox(0F, 0F, 0F, 5, 1, 1);
		box78.setPosition(-2F, 24F, -33F);
		box78.rotateAngleX = -3.141592653589793F;
		box78.rotateAngleY = -2.827433388230814F;
		box78.rotateAngleZ = -0.017453292519943295F;

		box79 = new CustomModelRenderer(this, 131, 39, 256, 256);
		box79.addBox(0F, 0F, 0F, 5, 1, 1);
		box79.setPosition(2F, 23F, -33F);
		box79.rotateAngleY = -0.33161255787892263F;
		box79.rotateAngleZ = 0.03490658503988659F;

		box8 = new CustomModelRenderer(this, 49, 31, 256, 256);
		box8.addBox(0F, 0F, 0F, 16, 2, 2);
		box8.setPosition(-8F, 2F, 12F);

		box80 = new CustomModelRenderer(this, 146, 0, 256, 256);
		box80.addBox(0F, 0F, 0F, 1, 14, 12);
		box80.setPosition(-9F, 10F, -25F);//8

		box81 = new CustomModelRenderer(this, 146, 25, 256, 256);
		box81.addBox(0F, 0F, 0F, 1, 14, 12);
		box81.setPosition(8F, 10F, -25F);

		box82 = new CustomModelRenderer(this, 149, 52, 256, 256);
		box82.addBox(0F, 0F, 0F, 1, 5, 1);
		box82.setPosition(-9F, 23F, -26F);
		box82.rotateAngleX = -6.09119908946021F;

		box83 = new CustomModelRenderer(this, 154, 52, 256, 256);
		box83.addBox(0F, 0F, 0F, 1, 5, 1);
		box83.setPosition(8F, 23F, -26F);
		box83.rotateAngleX = -6.09119908946021F;

		box84 = new CustomModelRenderer(this, 107, 92, 256, 256);
		box84.addBox(0F, 0F, 0F, 10, 22, 14);
		box84.setPosition(-5F, 10F, -13F);

		box85 = new CustomModelRenderer(this, 159, 52, 256, 256);
		box85.addBox(0F, 0F, 0F, 2, 4, 1);
		box85.setPosition(-1F, 25F, -27F);
		box85.rotateAngleX = -5.98647933434055F;

		box87 = new CustomModelRenderer(this, 110, 77, 256, 256);
		box87.addBox(0F, 0F, 0F, 8, 2, 1);
		box87.setPosition(9F, 30F, -25F);
		box87.rotateAngleY = 0.12217304763960307F;
		box87.rotateAngleZ = 3.141592653589793F;

		box88 = new CustomModelRenderer(this, 132, 72, 256, 256);
		box88.addBox(0F, 0F, 0F, 4, 3, 1);
		box88.setPosition(-2F, 28F, -26F);

		box89 = new CustomModelRenderer(this, 149, 61, 256, 256);
		box89.addBox(0F, 0F, 0F, 1, 5, 1);
		box89.setPosition(8F, 24F, -25F);

		box9 = new CustomModelRenderer(this, 0, 2, 256, 256);
		box9.addBox(0F, 0F, 0F, 1, 6, 20);
		box9.setPosition(-6F, 0F, 10F);

		box90 = new CustomModelRenderer(this, 154, 61, 256, 256);
		box90.addBox(0F, 0F, 0F, 1, 5, 1);
		box90.setPosition(-9F, 24F, -25F);

		box91 = new CustomModelRenderer(this, 167, 42, 256, 256);
		box91.addBox(0F, 0F, 0F, 1, 2, 11);
		box91.setPosition(8F, 28F, -24F);

		box92 = new CustomModelRenderer(this, 173, 27, 256, 256);
		box92.addBox(0F, 0F, 0F, 1, 2, 11);
		box92.setPosition(-9F, 28F, -24F);

		box93 = new CustomModelRenderer(this, 176, 61, 256, 256);
		box93.addBox(0F, 0F, 0F, 1, 4, 2);
		box93.setPosition(8F, 24F, -15F);

		box94 = new CustomModelRenderer(this, 164, 62, 256, 256);
		box94.addBox(0F, 0F, 0F, 1, 4, 1);
		box94.setPosition(8F, 24F, -20F);

		box95 = new CustomModelRenderer(this, 169, 61, 256, 256);
		box95.addBox(0F, 0F, 0F, 1, 4, 2);
		box95.setPosition(-9F, 24F, -15F);

		box96 = new CustomModelRenderer(this, 159, 62, 256, 256);
		box96.addBox(0F, 0F, 0F, 1, 4, 1);
		box96.setPosition(-9F, 24F, -20F);

		box97 = new CustomModelRenderer(this, 201, 2, 256, 256);
		box97.addBox(0F, 0F, 0F, 10, 1, 13);
		box97.setPosition(-5F, 31F, -26F);

		box98 = new CustomModelRenderer(this, 204, 23, 256, 256);
		box98.addBox(0F, 0F, 0F, 5, 1, 12);
		box98.setPosition(5F, 32F, -13F);
		box98.rotateAngleX = -3.141592653589793F;
		box98.rotateAngleZ = -0.4537856055185257F;

		box99 = new CustomModelRenderer(this, 204, 41, 256, 256);
		box99.addBox(0F, 0F, 0F, 5, 1, 1);
		box99.setPosition(5F, 32F, -25F);
		box99.rotateAngleX = -3.1764992386296798F;
		box99.rotateAngleY = -0.19198621771937624F;
		box99.rotateAngleZ = -0.4537856055185257F;

	}
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		if (ConfigHandler.FLICKERING) {
			super.render(entity, f, f1, f2, f3, f4, f5);
		}

		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box100.render(f5);
		box101.render(f5);
		box102.render(f5);
		box103.render(f5);
		box108.render(f5);
		box109.render(f5);
		box11.render(f5);
		box110.render(f5);
		box111.render(f5);
		box112.render(f5);
		box113.render(f5);
		box114.render(f5);
		box115.render(f5);
		box116.render(f5);
		box117.render(f5);
		box118.render(f5);
		box119.render(f5);
		box12.render(f5);
		box120.render(f5);
		box121.render(f5);
		box122.render(f5);
		box123.render(f5);
		box124.render(f5);
		box125.render(f5);
		box126.render(f5);
		box128.render(f5);
		box13.render(f5);
		box131.render(f5);
		box132.render(f5);
		box134.render(f5);
		box14.render(f5);
		box143.render(f5);
		box148.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box44.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box78.render(f5);
		box79.render(f5);
		box8.render(f5);
		box84.render(f5);
		box85.render(f5);
		box87.render(f5);
		box88.render(f5);
		box9.render(f5);
		box97.render(f5);
		box98.render(f5);
		box99.render(f5);

		//Doors left
		box80.render(f5);
		box82.render(f5);
		box90.render(f5);
		box92.render(f5);
		box95.render(f5);
		box96.render(f5);

		//Doors right
		box81.render(f5);
		box83.render(f5);
		box89.render(f5);
		box91.render(f5);
		box93.render(f5);
		box94.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box32.render(f5);
		box33.render(f5);
		box104.render(f5);
		box105.render(f5);
		box106.render(f5);
		box107.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}