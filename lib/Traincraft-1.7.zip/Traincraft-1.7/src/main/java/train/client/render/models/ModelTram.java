package train.client.render.models;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import tmt.ModelBase;
import train.client.render.CustomModelRenderer;

public class ModelTram extends ModelBase {

	public CustomModelRenderer box;
	public CustomModelRenderer box0;
	public CustomModelRenderer box1;
	public CustomModelRenderer box10;
	public CustomModelRenderer box11;
	public CustomModelRenderer box12;
	public CustomModelRenderer box13;
	public CustomModelRenderer box14;
	public CustomModelRenderer box15;
	public CustomModelRenderer box16;
	public CustomModelRenderer box17;
	public CustomModelRenderer box18;
	public CustomModelRenderer box19;
	public CustomModelRenderer box2;
	public CustomModelRenderer box20;
	public CustomModelRenderer box21;
	public CustomModelRenderer box22;
	public CustomModelRenderer box23;
	public CustomModelRenderer box24;
	public CustomModelRenderer box25;
	public CustomModelRenderer box26;
	public CustomModelRenderer box27;
	public CustomModelRenderer box28;
	public CustomModelRenderer box29;
	public CustomModelRenderer box3;
	public CustomModelRenderer box30;
	public CustomModelRenderer box31;
	public CustomModelRenderer box32;
	public CustomModelRenderer box33;
	public CustomModelRenderer box34;
	public CustomModelRenderer box35;
	public CustomModelRenderer box36;
	public CustomModelRenderer box37;
	public CustomModelRenderer box38;
	public CustomModelRenderer box39;
	public CustomModelRenderer box4;
	public CustomModelRenderer box40;
	public CustomModelRenderer box41;
	public CustomModelRenderer box42;
	public CustomModelRenderer box43;
	public CustomModelRenderer box44;
	public CustomModelRenderer box45;
	public CustomModelRenderer box46;
	public CustomModelRenderer box47;
	public CustomModelRenderer box48;
	public CustomModelRenderer box49;
	public CustomModelRenderer box5;
	public CustomModelRenderer box50;
	public CustomModelRenderer box51;
	public CustomModelRenderer box52;
	public CustomModelRenderer box53;
	public CustomModelRenderer box54;
	public CustomModelRenderer box55;
	public CustomModelRenderer box56;
	public CustomModelRenderer box57;
	public CustomModelRenderer box58;
	public CustomModelRenderer box59;
	public CustomModelRenderer box6;
	public CustomModelRenderer box60;
	public CustomModelRenderer box61;
	public CustomModelRenderer box62;
	public CustomModelRenderer box63;
	public CustomModelRenderer box64;
	public CustomModelRenderer box65;
	public CustomModelRenderer box66;
	public CustomModelRenderer box67;
	public CustomModelRenderer box68;
	public CustomModelRenderer box69;
	public CustomModelRenderer box7;
	public CustomModelRenderer box70;
	public CustomModelRenderer box71;
	public CustomModelRenderer box72;
	public CustomModelRenderer box73;
	public CustomModelRenderer box74;
	public CustomModelRenderer box75;
	public CustomModelRenderer box76;
	public CustomModelRenderer box77;
	public CustomModelRenderer box78;
	public CustomModelRenderer box79;
	public CustomModelRenderer box8;
	public CustomModelRenderer box80;
	public CustomModelRenderer box81;
	public CustomModelRenderer box9;

	public ModelTram() {
		box = new CustomModelRenderer(this, 64, 0, 256, 256);
		box.addBox(0F, 0F, 0F, 8, 3, 8);
		box.setPosition(-4F, 1F, -4F);

		box0 = new CustomModelRenderer(this, 1, 2, 256, 256);
		box0.addBox(0F, 0F, 0F, 30, 2, 1);
		box0.setPosition(-15F, 1F, -7F);

		box1 = new CustomModelRenderer(this, 38, 237, 256, 256);
		box1.addBox(0F, 0F, 0F, 8, 7, 0);
		box1.setPosition(-16F, 0F, 5F);

		box10 = new CustomModelRenderer(this, 25, 106, 256, 256);
		box10.addBox(0F, 0F, 0F, 1, 20, 1);
		box10.setPosition(23F, 6F, -11F);

		box11 = new CustomModelRenderer(this, 9, 235, 256, 256);
		box11.addBox(0F, 0F, 0F, 10, 5, 1);
		box11.setPosition(-17F, 1F, 5F);

		box12 = new CustomModelRenderer(this, 243, 0, 256, 256);
		box12.addBox(0F, 0F, 0F, 1, 18, 4);
		box12.setPosition(14F, 8F, 6F);

		box13 = new CustomModelRenderer(this, 133, 141, 256, 256);
		box13.addBox(0F, 0F, 0F, 46, 1, 1);
		box13.setPosition(-23F, 25F, -11F);

		box14 = new CustomModelRenderer(this, 230, 0, 256, 256);
		box14.addBox(0F, 0F, 0F, 1, 18, 4);
		box14.setPosition(-15F, 8F, 6F);

		box15 = new CustomModelRenderer(this, 230, 0, 256, 256);
		box15.addBox(0F, 0F, 0F, 1, 18, 4);
		box15.setPosition(-15F, 8F, -10F);

		box16 = new CustomModelRenderer(this, 31, 60, 256, 256);
		box16.addBox(-10F, -2F, 0F, 10, 2, 6);
		box16.setPosition(17F, 30F, -6F);
		box16.rotateAngleX = -5.724679946541401F;
		box16.rotateAngleY = -3.141592653589793F;
		box16.rotateAngleZ = 5.98647933434055F;

		box17 = new CustomModelRenderer(this, 8, 35, 256, 256);
		box17.addBox(0F, 0F, 0F, 34, 2, 12);
		box17.setPosition(-17F, 30F, -6F);

		box18 = new CustomModelRenderer(this, 4, 131, 256, 256);
		box18.addBox(0F, 0F, 0F, 4, 1, 7);
		box18.setPosition(28F, 26F, -5F);
		box18.rotateAngleY = -2.5830872929516078F;

		box19 = new CustomModelRenderer(this, 14, 27, 256, 256);
		box19.addBox(0F, -1F, 0F, 34, 1, 6);
		box19.setPosition(17F, 30F, -6F);
		box19.rotateAngleX = -5.742133239061344F;
		box19.rotateAngleY = -3.141592653589793F;

		box2 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box2.addBox(0F, 0F, 0F, 2, 2, 16);
		box2.setPosition(11F, 2F, -8F);

		box20 = new CustomModelRenderer(this, 2, 12, 256, 256);
		box20.addBox(0F, -2F, 0F, 11, 2, 12);
		box20.setPosition(-17F, 32F, 6F);
		box20.rotateAngleY = 3.141592653589793F;
		box20.rotateAngleZ = 0.47123889803846897F;

		box21 = new CustomModelRenderer(this, 90, 127, 256, 256);
		box21.addBox(0F, 0F, 0F, 4, 1, 10);
		box21.setPosition(24F, 26F, -5F);

		box22 = new CustomModelRenderer(this, 76, 146, 256, 256);
		box22.addBox(0F, 0F, 0F, 1, 20, 7);
		box22.setPosition(28F, 6F, -5F);
		box22.rotateAngleY = -2.5830872929516078F;

		box23 = new CustomModelRenderer(this, 120, 113, 256, 256);
		box23.addBox(0F, 0F, 0F, 32, 19, 1);
		box23.setPosition(-16F, 6F, 10F);

		box24 = new CustomModelRenderer(this, 2, 210, 256, 256);
		box24.addBox(0F, 0F, 0F, 32, 3, 20);
		box24.setPosition(-16F, 5F, -10F);

		box25 = new CustomModelRenderer(this, 0, 65, 256, 256);
		box25.addBox(0F, 0F, 0F, 3, 4, 20);
		box25.setPosition(23F, 4F, -10F);

		box26 = new CustomModelRenderer(this, 31, 106, 256, 256);
		box26.addBox(0F, 0F, 0F, 1, 20, 1);
		box26.setPosition(-24F, 6F, 10F);

		box27 = new CustomModelRenderer(this, 176, 222, 256, 256);
		box27.addBox(0F, 0F, -4F, 4, 4, 4);
		box27.setPosition(29F, 4F, 7F);
		box27.rotateAngleY = -3.9269908169872414F;

		box28 = new CustomModelRenderer(this, 141, 222, 256, 256);
		box28.addBox(0F, 0F, -4F, 4, 4, 4);
		box28.setPosition(29F, 4F, -7F);
		box28.rotateAngleY = -3.9269908169872414F;

		box29 = new CustomModelRenderer(this, 24, 142, 256, 256);
		box29.addBox(0F, 0F, 0F, 1, 20, 10);
		box29.setPosition(27F, 6F, -5F);

		box3 = new CustomModelRenderer(this, 96, 1, 256, 256);
		box3.addBox(0F, 0F, 0F, 2, 2, 16);
		box3.setPosition(-13F, 2F, -8F);

		box30 = new CustomModelRenderer(this, 50, 61, 256, 256);
		box30.addBox(0F, 0F, 0F, 48, 1, 22);
		box30.setPosition(-24F, 26F, -11F);

		box31 = new CustomModelRenderer(this, 116, 146, 256, 256);
		box31.addBox(-1F, 0F, 0F, 1, 20, 7);
		box31.setPosition(-28F, 6F, -5F);
		box31.rotateAngleY = -3.7000980142279785F;

		box32 = new CustomModelRenderer(this, 2, 12, 256, 256);
		box32.addBox(0F, -2F, 0F, 11, 2, 12);
		box32.setPosition(17F, 32F, -6F);
		box32.rotateAngleZ = -0.47123889803846897F;

		//ok
		box33 = new CustomModelRenderer(this, 31, 60, 256, 256);
		box33.addBox(-10F, -2F, 0F, 10, 2, 6);
		box33.setPosition(-17F, 30F, 6F);
		box33.mirror = true;
		box33.rotateAngleX = -5.724679946541401F;
		box33.rotateAngleZ = -5.98647933434055F;

		box34 = new CustomModelRenderer(this, 14, 27, 256, 256);
		box34.addBox(0F, -1F, 0F, 34, 1, 6);
		box34.setPosition(-17F, 30F, 6F);
		box34.rotateAngleX = -5.742133239061344F;

		box35 = new CustomModelRenderer(this, 38, 237, 256, 256);
		box35.addBox(0F, 0F, 0F, 8, 7, 0);
		box35.setPosition(8F, 0F, 5F);

		box36 = new CustomModelRenderer(this, 133, 137, 256, 256);
		box36.addBox(0F, 0F, 0F, 46, 1, 1);
		box36.setPosition(-23F, 25F, 10F);

		box37 = new CustomModelRenderer(this, 243, 0, 256, 256);
		box37.addBox(0F, 0F, 0F, 1, 18, 4);
		box37.setPosition(14F, 8F, -10F);

		box38 = new CustomModelRenderer(this, 130, 51, 256, 256);
		box38.addBox(-1F, 0F, 0F, 8, 1, 3);
		box38.setPosition(16F, 1F, -11F);

		box39 = new CustomModelRenderer(this, 4, 131, 256, 256);
		box39.addBox(0F, 0F, -7F, 4, 1, 7);
		box39.setPosition(28F, 26F, 5F);
		box39.rotateAngleY = -3.7000980142279785F;

		box4 = new CustomModelRenderer(this, 1, 6, 256, 256);
		box4.addBox(0F, 0F, 0F, 30, 2, 1);
		box4.setPosition(-15F, 1F, 6F);

		box40 = new CustomModelRenderer(this, 6, 145, 256, 256);
		box40.addBox(0F, 0F, -7F, 1, 20, 7);
		box40.setPosition(28F, 6F, 5F);
		box40.rotateAngleY = -3.7000980142279785F;

		box41 = new CustomModelRenderer(this, 120, 92, 256, 256);
		box41.addBox(0F, 0F, 0F, 32, 19, 1);
		box41.setPosition(-16F, 6F, -11F);

		box42 = new CustomModelRenderer(this, 109, 50, 256, 256);
		box42.addBox(-1F, 0F, 0F, 8, 3, 0);
		box42.setPosition(16F, 1F, -8F);

		box43 = new CustomModelRenderer(this, 130, 51, 256, 256);
		box43.addBox(0F, 0F, 0F, 8, 1, 3);
		box43.setPosition(-23F, 1F, -11F);

		box44 = new CustomModelRenderer(this, 40, 175, 256, 256);
		box44.addBox(-1F, 0F, 0F, 1, 4, 4);
		box44.setPosition(-28F, 9F, -2F);

		box45 = new CustomModelRenderer(this, 89, 215, 256, 256);
		box45.addBox(0F, 0F, 0F, 8, 1, 20);
		box45.setPosition(-23F, 4F, -10F);

		//ok
		box46 = new CustomModelRenderer(this, 31, 52, 256, 256);
		box46.addBox(0F, -2F, 0F, 10, 2, 6);
		box46.setPosition(-17F, 30F, -6F);
		box46.rotateAngleX = -5.724679946541401F;
		box46.rotateAngleY = -3.141592653589793F;
		box46.rotateAngleZ = 0.29670597283903605F;

		box47 = new CustomModelRenderer(this, 130, 51, 256, 256);
		box47.addBox(0F, 0F, 0F, 8, 1, 3);
		box47.setPosition(-23F, 1F, 8F);

		//ok
		box48 = new CustomModelRenderer(this, 31, 52, 256, 256);
		box48.addBox(0F, -2F, 0F, 10, 2, 6);
		box48.setPosition(17F, 30F, 6F);
		box48.rotateAngleX = -5.724679946541401F;
		box48.rotateAngleZ = -0.29670597283903605F;

		box49 = new CustomModelRenderer(this, 90, 127, 256, 256);
		box49.addBox(0F, 0F, 0F, 4, 1, 10);
		box49.setPosition(-28F, 26F, -5F);

		box5 = new CustomModelRenderer(this, 38, 237, 256, 256);
		box5.addBox(0F, 0F, 0F, 8, 7, 0);
		box5.setPosition(8F, 0F, -5F);

		box50 = new CustomModelRenderer(this, 89, 215, 256, 256);
		box50.addBox(-1F, 0F, 0F, 8, 1, 20);
		box50.setPosition(16F, 4F, -10F);

		box51 = new CustomModelRenderer(this, 48, 145, 256, 256);
		box51.addBox(-1F, 0F, -7F, 1, 20, 7);
		box51.setPosition(-28F, 6F, 5F);
		box51.rotateAngleY = -2.5830872929516078F;

		box52 = new CustomModelRenderer(this, 28, 131, 256, 256);
		box52.addBox(-4F, 0F, -7F, 4, 1, 7);
		box52.setPosition(-28F, 26F, 5F);
		box52.rotateAngleY = -2.5830872929516078F;

		box53 = new CustomModelRenderer(this, 28, 131, 256, 256);
		box53.addBox(-4F, -1F, 0F, 4, 1, 7);
		box53.setPosition(-28F, 27F, -5F);
		box53.rotateAngleY = -3.7000980142279785F;

		box54 = new CustomModelRenderer(this, 93, 143, 256, 256);
		box54.addBox(0F, 0F, 0F, 1, 20, 10);
		box54.setPosition(-28F, 6F, -5F);

		box55 = new CustomModelRenderer(this, 36, 103, 256, 256);
		box55.addBox(0F, 0F, 0F, 3, 4, 20);
		box55.setPosition(-26F, 4F, -10F);

		box56 = new CustomModelRenderer(this, 13, 106, 256, 256);
		box56.addBox(0F, 0F, 0F, 1, 20, 1);
		box56.setPosition(23F, 6F, 10F);

		box57 = new CustomModelRenderer(this, 19, 106, 256, 256);
		box57.addBox(0F, 0F, 0F, 1, 20, 1);
		box57.setPosition(-24F, 6F, -11F);

		box58 = new CustomModelRenderer(this, 141, 222, 256, 256);
		box58.addBox(0F, 0F, -4F, 4, 4, 4);
		box58.setPosition(-29F, 4F, 7F);
		box58.rotateAngleY = -0.7853981633974483F;

		box59 = new CustomModelRenderer(this, 193, 222, 256, 256);
		box59.addBox(0F, 0F, 0F, 4, 4, 4);
		box59.setPosition(-29F, 4F, -7F);
		box59.rotateAngleY = -5.497787143782138F;

		box6 = new CustomModelRenderer(this, 9, 241, 256, 256);
		box6.addBox(0F, 0F, 0F, 10, 5, 1);
		box6.setPosition(-17F, 1F, -6F);

		box60 = new CustomModelRenderer(this, 130, 51, 256, 256);
		box60.addBox(0F, 0F, 0F, 8, 1, 3);
		box60.setPosition(15F, 1F, 8F);

		box61 = new CustomModelRenderer(this, 109, 50, 256, 256);
		box61.addBox(-1F, 0F, 0F, 8, 3, 0);
		box61.setPosition(16F, 1F, 8F);

		box62 = new CustomModelRenderer(this, 109, 50, 256, 256);
		box62.addBox(-1F, 0F, 0F, 8, 3, 0);
		box62.setPosition(-22F, 1F, 8F);

		box63 = new CustomModelRenderer(this, 38, 237, 256, 256);
		box63.addBox(0F, 0F, 0F, 8, 7, 0);
		box63.setPosition(-16F, 0F, -5F);

		box64 = new CustomModelRenderer(this, 109, 50, 256, 256);
		box64.addBox(-1F, 0F, 0F, 8, 3, 0);
		box64.setPosition(-22F, 1F, -8F);

		box65 = new CustomModelRenderer(this, 170, 172, 256, 256);
		box65.addBox(0F, 0F, 0F, 28, 2, 4);
		box65.setPosition(-14F, 8F, 6F);

		box66 = new CustomModelRenderer(this, 170, 172, 256, 256);
		box66.addBox(0F, 0F, 0F, 28, 2, 4);
		box66.setPosition(-14F, 8F, -10F);

		box67 = new CustomModelRenderer(this, 169, 161, 256, 256);
		box67.addBox(0F, 0F, 0F, 28, 1, 5);
		box67.setPosition(-14F, 10F, -9F);
		box67.rotateAngleX = -0.06981317007977318F;

		box68 = new CustomModelRenderer(this, 173, 152, 256, 256);
		box68.addBox(0F, 0F, 0F, 28, 5, 1);
		box68.setPosition(-14F, 11F, -9F);
		box68.rotateAngleX = -0.17453292519943295F;

		box69 = new CustomModelRenderer(this, 169, 161, 256, 256);
		box69.addBox(0F, 0F, 0F, 28, 1, 5);
		box69.setPosition(14F, 10F, 9F);
		box69.rotateAngleX = -0.06981317007977318F;
		box69.rotateAngleY = -3.141592653589793F;

		box7 = new CustomModelRenderer(this, 9, 241, 256, 256);
		box7.addBox(0F, 0F, 0F, 10, 5, 1);
		box7.setPosition(7F, 1F, -6F);

		box70 = new CustomModelRenderer(this, 173, 152, 256, 256);
		box70.addBox(0F, 0F, 0F, 28, 5, 1);
		box70.setPosition(14F, 11F, 9F);
		box70.rotateAngleX = -0.17453292519943295F;
		box70.rotateAngleY = -3.141592653589793F;

		box71 = new CustomModelRenderer(this, 51, 175, 256, 256);
		box71.addBox(-1F, 0F, 0F, 1, 4, 4);
		box71.setPosition(29F, 9F, -2F);

		box72 = new CustomModelRenderer(this, 22, 175, 256, 256);
		box72.addBox(0F, 0F, 0F, 3, 7, 4);
		box72.setPosition(24F, 8F, -5F);

		box73 = new CustomModelRenderer(this, 144, 174, 256, 256);
		box73.addBox(0F, 0F, 0F, 7, 20, 0);
		box73.setPosition(-23F, 5F, -10F);

		box74 = new CustomModelRenderer(this, 144, 174, 256, 256);
		box74.addBox(0F, 0F, 0F, 7, 20, 0);
		box74.setPosition(16F, 5F, -10F);

		box75 = new CustomModelRenderer(this, 144, 151, 256, 256);
		box75.addBox(0F, 0F, 0F, 7, 20, 0);
		box75.setPosition(16F, 5F, 10F);

		box76 = new CustomModelRenderer(this, 144, 151, 256, 256);
		box76.addBox(0F, 0F, 0F, 7, 20, 0);
		box76.setPosition(-23F, 5F, 10F);

		box77 = new CustomModelRenderer(this, 37, 13, 256, 256);
		box77.addBox(0F, 0F, 0F, 10, 2, 6);
		box77.setPosition(-5F, 32F, -3F);

		box78 = new CustomModelRenderer(this, 91, 35, 256, 256);
		box78.addBox(0F, 0F, 0F, 2, 5, 4);
		box78.setPosition(-25F, 28F, -2F);

		box79 = new CustomModelRenderer(this, 2, 36, 256, 256);
		box79.addBox(0F, 0F, 0F, 2, 5, 4);
		box79.setPosition(23F, 28F, -2F);

		box8 = new CustomModelRenderer(this, 9, 235, 256, 256);
		box8.addBox(0F, 0F, 0F, 10, 5, 1);
		box8.setPosition(7F, 1F, 5F);

		box80 = new CustomModelRenderer(this, 68, 23, 256, 256);
		box80.addBox(-20F, 0F, 0F, 20, 1, 1);
		box80.setPosition(1F, 32.8F, -1F);

		box81 = new CustomModelRenderer(this, 0, 252, 256, 256);
		box81.addBox(0F, 0F, 0F, 60, 2, 2);
		box81.setPosition(-30F, 2F, -1F);

		box9 = new CustomModelRenderer(this, 1, 191, 256, 256);
		box9.addBox(0F, 0F, 0F, 58, 4, 14);
		box9.setPosition(-29F, 4F, -7F);
	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		
		box8.render(f5);
		box80.rotateAngleZ = -0.29670597283903605F;
		box80.render(f5);
		box81.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box78.render(f5);
		box79.render(f5);
		box71.render(f5);
		box44.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void render2(float f5) {
		box.render(f5);
		box0.render(f5);
		box1.render(f5);
		box10.render(f5);
		box11.render(f5);
		box12.render(f5);
		box13.render(f5);
		box14.render(f5);
		box15.render(f5);
		box16.render(f5);
		box17.render(f5);
		box18.render(f5);
		box19.render(f5);
		box2.render(f5);
		box20.render(f5);
		box21.render(f5);
		box22.render(f5);
		box23.render(f5);
		box24.render(f5);
		box25.render(f5);
		box26.render(f5);
		box27.render(f5);
		box28.render(f5);
		box29.render(f5);
		box3.render(f5);
		box30.render(f5);
		box31.render(f5);
		box32.render(f5);
		box33.render(f5);
		box34.render(f5);
		box35.render(f5);
		box36.render(f5);
		box37.render(f5);
		box38.render(f5);
		box39.render(f5);
		box4.render(f5);
		box40.render(f5);
		box41.render(f5);
		box42.render(f5);
		box43.render(f5);
		box45.render(f5);
		box46.render(f5);
		box47.render(f5);
		box48.render(f5);
		box49.render(f5);
		box5.render(f5);
		box50.render(f5);
		box51.render(f5);
		box52.render(f5);
		box53.render(f5);
		box54.render(f5);
		box55.render(f5);
		box56.render(f5);
		box57.render(f5);
		box58.render(f5);
		box59.render(f5);
		box6.render(f5);
		box60.render(f5);
		box61.render(f5);
		box62.render(f5);
		box63.render(f5);
		box64.render(f5);
		box65.render(f5);
		box66.render(f5);
		box67.render(f5);
		box68.render(f5);
		box69.render(f5);
		box7.render(f5);
		box70.render(f5);
		box72.render(f5);
		box73.render(f5);
		box74.render(f5);
		box75.render(f5);
		box76.render(f5);
		box77.render(f5);
		box8.render(f5);
		box80.rotateAngleZ = 0;
		box80.render(f5);
		box81.render(f5);
		box9.render(f5);
		
		Minecraft.getMinecraft().entityRenderer.disableLightmap(1D);
		box78.render(f5);
		box79.render(f5);
		box71.render(f5);
		box44.render(f5);
		Minecraft.getMinecraft().entityRenderer.enableLightmap(1D);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {}
}