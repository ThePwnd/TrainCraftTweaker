/*
 * ******************************************************************************
 *  Copyright 2011-2015 CovertJaguar
 *
 *  This work (the API) is licensed under the "MIT" License, see LICENSE.md for details.
 * ***************************************************************************
 */
@API(apiVersion="2.3.0", owner="RailcraftAPI|core", provides="RailcraftAPI|signals")
package mods.railcraft.api.signals;
import cpw.mods.fml.common.API;
