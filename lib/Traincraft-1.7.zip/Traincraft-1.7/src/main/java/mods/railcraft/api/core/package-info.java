/*
 * ******************************************************************************
 *  Copyright 2011-2015 CovertJaguar
 *
 *  This work (the API) is licensed under the "MIT" License, see LICENSE.md for details.
 * ***************************************************************************
 */
@API(apiVersion="1.5.0", owner="Railcraft", provides="RailcraftAPI|core")
package mods.railcraft.api.core;
import cpw.mods.fml.common.API;
