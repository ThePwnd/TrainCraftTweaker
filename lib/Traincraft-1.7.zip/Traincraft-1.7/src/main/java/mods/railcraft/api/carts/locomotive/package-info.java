/*
 * ******************************************************************************
 *  Copyright 2011-2015 CovertJaguar
 *
 *  This work (the API) is licensed under the "MIT" License, see LICENSE.md for details.
 * ***************************************************************************
 */
@API(apiVersion="1.1.0", owner="RailcraftAPI|carts", provides="RailcraftAPI|locomotive")
package mods.railcraft.api.carts.locomotive;
import cpw.mods.fml.common.API;
