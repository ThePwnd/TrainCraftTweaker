/*
 * ******************************************************************************
 *  Copyright 2011-2015 CovertJaguar
 *
 *  This work (the API) is licensed under the "MIT" License, see LICENSE.md for details.
 * ***************************************************************************
 */
@API(apiVersion="1.6.0", owner="RailcraftAPI|core", provides="RailcraftAPI|carts")
package mods.railcraft.api.carts;
import cpw.mods.fml.common.API;
