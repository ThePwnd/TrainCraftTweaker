package net.minecraft.entity;

public class TraincraftEntityHelper {
	public static boolean getIsJumping(EntityLivingBase entity) {
		return false;
	}
}